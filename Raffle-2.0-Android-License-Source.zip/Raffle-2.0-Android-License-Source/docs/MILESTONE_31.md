# Milestone 31 · Release Candidate

## Objetivo
Preparar una entrega reproducible y auditable sin confundir el estado de desarrollo con una versión comercial final.

## Cambios
- README consolidado para usar exclusivamente pnpm en el frontend.
- Versión visible actualizada a `2.0.0-rc.1`.
- Añadido `RELEASE_CHECKLIST.md` con controles de instalación, seguridad, migraciones, smoke tests y empaquetado.
- Se mantiene explícito que la validación completa debe ejecutarse en un entorno limpio con todas las dependencias instaladas.
- Se eliminan del README duplicaciones de instrucciones y estados históricos contradictorios.

## Validación del entorno de trabajo
- Revisión estática de estructura, configuración y referencias de desarrollo completada.
- La suite completa de backend no pudo ejecutarse en este entorno porque falta la dependencia `python-jose`; está declarada en `Backend/requirements.txt` y debe instalarse antes del release.
- El release no debe marcarse como final hasta completar `RELEASE_CHECKLIST.md`.
