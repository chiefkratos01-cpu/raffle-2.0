# Raffle 2.0 · Arquitectura inicial

## Principios

1. El backend es la autoridad para estados críticos.
2. El cliente nunca elige ganadores.
3. Los pagos manuales requieren confirmación del organizador.
4. La conectividad intermitente no debe destruir una reserva cuando la liberación automática está desactivada.
5. Las operaciones administrativas importantes quedan auditadas.
6. El software se licencia al organizador; una licencia de software no valida por sí misma la legalidad de una rifa concreta.
7. Producción usa migraciones Alembic. `create_all()` queda únicamente como comodidad de desarrollo inicial.

## Flujo de pago

`RESERVED → PAYMENT_REVIEW → CONFIRMED → Ticket PAID`

Rechazo:

`RESERVED/PAYMENT_REVIEW → REJECTED → Ticket RELEASED` según las reglas de la rifa.

## Flujo de sorteo

`IDLE → DRAW_REQUESTED → DRAWING → WINNER_SELECTED → ANIMATION → COMPLETED`

El ganador se persiste antes de emitir el evento autoritativo de realtime. Los clientes nuevos recuperan el estado actual desde la API.

## Temas

`system` sigue `prefers-color-scheme`. `light` y `dark` son preferencias explícitas y tienen prioridad sobre el sistema. No se mezcla con horarios. Se respetan preferencias de movimiento reducido.


### Transaction boundary
Las rutas que requieren auditoría componen cambios de dominio y `record_audit(..., commit=False)` en la misma sesión y ejecutan un único `db.commit()`. Los servicios exponen `commit=False` para evitar commits internos que rompan la atomicidad. Los eventos realtime se publican únicamente después del commit.
