# Milestone 30 — Auditoría final de seguridad de sesiones

## Objetivo
Cerrar una brecha de ciclo de vida de cuentas: desactivar una cuenta no debe dejar refresh sessions reutilizables.

## Cambios
- `POST /api/v1/auth/refresh` ahora verifica que el sujeto de la sesión siga existiendo y activo.
- Si el usuario o administrador asociado está inactivo, la sesión se revoca inmediatamente y el refresh devuelve `401`.
- Al desactivar un administrador desde Administración → Seguridad, se revocan todas sus sesiones activas en la misma transacción.
- La respuesta de cambio de estado informa cuántas sesiones fueron revocadas.

## Verificación
- `Backend/tests/test_final_security_hardening.py`: 2/2.
- `python -m compileall -q Backend/app`: OK.
- `DATABASE_URL=sqlite:///... alembic upgrade head`: OK desde BD limpia.

## Nota de entorno
La suite completa de runtime HTTP/JWT no se ejecuta en este entorno porque `python-jose` no está instalado en el intérprete disponible. La dependencia sí está declarada en `Backend/requirements.txt`.
