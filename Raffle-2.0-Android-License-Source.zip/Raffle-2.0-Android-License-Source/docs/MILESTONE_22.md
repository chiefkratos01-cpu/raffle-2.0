# Milestone 22 · Gestión de sesiones

Se añadió gestión explícita de sesiones autenticadas.

## Incluye
- Registro de IP y User-Agent al crear una sesión.
- Consulta de sesiones activas del usuario/administrador autenticado.
- Identificación de la sesión actual.
- Revocación individual de una sesión.
- Revocación de todas las demás sesiones manteniendo la actual.
- Nueva migración `c2e7a9f1b4d6_auth_session_metadata.py`.

## Seguridad
Los endpoints siempre filtran las sesiones por el sujeto obtenido del JWT. Un usuario no puede revocar ni consultar sesiones pertenecientes a otro sujeto.

La IP y el User-Agent son metadatos de seguridad para reconocer sesiones, no credenciales.
