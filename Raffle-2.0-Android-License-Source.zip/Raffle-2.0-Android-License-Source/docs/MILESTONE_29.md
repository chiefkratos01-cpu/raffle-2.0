# Milestone 29 — Auditoría integral y estados de rifa

## Objetivo
Revisar los puntos donde una rifa publicada podía cambiar de forma inconsistente o entrar en estados inválidos.

## Cambios
- Se impide modificar configuraciones estructurales después de que existan boletos vendidos: cantidad total, precio, moneda, cantidad de ganadores, límites por usuario, política de múltiples victorias y configuración de liberación.
- Los premios tampoco pueden cambiar después de que existan ventas.
- `total_tickets` nunca puede quedar por debajo de `tickets_sold`.
- Se revalidan posiciones de premios en cada actualización.
- Se exige `reservation_minutes` cuando la liberación automática está habilitada.
- Cancelar una rifa queda limitado a estados donde todavía tiene sentido hacerlo. No se puede cancelar una rifa que ya está sorteando, completada o cancelada.

## Verificación
- Se añadieron pruebas estáticas específicas de invariantes de estado.
- Se debe ejecutar la suite completa en un entorno con las dependencias de `requirements.txt`; este entorno de trabajo no tiene `python-jose` instalado.
