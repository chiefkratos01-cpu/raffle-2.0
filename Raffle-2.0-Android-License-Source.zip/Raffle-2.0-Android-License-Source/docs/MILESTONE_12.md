# Milestone 12 - Integración administrativa y verificación pública

Este hito completa varias piezas que ya existían en backend pero todavía no estaban expuestas correctamente en la interfaz.

## Cambios

### Verificación de ganadores
Los resultados publicados enlazan ahora con `/verify/winner/{codigo}` y el frontend consume el endpoint público de verificación del backend.

### Administración
El centro de control incorpora:
- Administradores.
- Activación y desactivación.
- Creación de administrador para SUPER_ADMIN.
- Registro de auditoría.
- Actualización manual del registro.

La seguridad real continúa estando en el backend. Ocultar o mostrar una pestaña en React nunca se considera una barrera de seguridad.

### Pagos
Rechazar un pago solicita un motivo. Esto evita que el operador deje una decisión sin explicación y permite conservar una trazabilidad útil.

### Sorteos
La interfaz recalca que el navegador solicita el sorteo, pero el backend selecciona y persiste el ganador. La ruleta solo representa el resultado recibido.

## Próximo bloque
El siguiente paso debe centrarse en separar el frontend monolítico en páginas, componentes, hooks y servicios sin cambiar el contrato funcional. Después se podrá atacar el selector de grandes volúmenes, recuperación realtime y PWA.
