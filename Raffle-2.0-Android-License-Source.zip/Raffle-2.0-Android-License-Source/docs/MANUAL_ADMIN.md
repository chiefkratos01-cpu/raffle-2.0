# Manual del administrador · Raffle 2.0

## Configurar una rifa

Antes de publicar una rifa, configure como mínimo:

- nombre y descripción;
- cantidad total de boletos;
- precio y moneda;
- premios y posiciones;
- cantidad de ganadores;
- reglas de la rifa;
- datos públicos del organizador;
- WhatsApp/teléfono de contacto;
- métodos e instrucciones de pago;
- política de liberación automática de reservas.

## Reservas y conectividad

La liberación automática es **opcional por rifa**.

Si está desactivada, una reserva no se libera automáticamente por el simple paso del tiempo. El organizador puede revisarla y confirmar, rechazar o liberar según las reglas configuradas.

Si está activada, el administrador debe seleccionar el período permitido, por ejemplo 10, 15 o 20 minutos. Esta condición debe aparecer en las reglas visibles de la rifa.

La aplicación no supone que el organizador tenga conexión permanente. Una reserva confirmada debe conservar su historial aunque la conexión haya sido intermitente.

## Confirmar un pago

1. Abra **Pagos pendientes**.
2. Busque la reserva por código o cliente.
3. Verifique el importe y el método acordado.
4. Compruebe el comprobante cuando corresponda.
5. Pulse **Confirmar pago**.
6. Raffle cambiará el pago a confirmado y los boletos asociados a estado válido para el sorteo.

## Rechazar un pago

El rechazo debe indicar un motivo cuando corresponda. Dependiendo de la política de la rifa, los boletos podrán liberarse para volver a estar disponibles.

## Importante

El administrador no debe registrar un pago como confirmado si no ha verificado que el dinero fue recibido. La confirmación queda registrada en la auditoría del sistema.

## Sorteos

El ganador lo selecciona el backend. El navegador del administrador no puede escoger manualmente el ticket ganador. Los clientes conectados reciben el estado autoritativo del sorteo mediante realtime.

## Modo demo y licencia

Una instalación en modo demo incluye una rifa de prueba que no aparece en el catálogo público. Sirve para recorrer el flujo antes de contratar una licencia.

Con una licencia comercial activa se pueden crear y publicar rifas reales. Si la licencia vence, no se permiten nuevas rifas ni nuevas publicaciones, pero una rifa que ya estaba activa puede completar las operaciones necesarias, incluido su sorteo.

## Equipo

Un organizador que trabaja solo no necesita crear otros accesos. Si necesita ayuda, puede añadir miembros con accesos separados para tareas como operación, pagos o consulta. Cada persona debe utilizar su propia cuenta.
