# Milestone 16 · Sorteos verificables

Se reforzó el motor de sorteos para que la selección sea reproducible y auditable sin permitir que el navegador elija al ganador.

## Cambios

- La semilla aleatoria se genera antes de seleccionar el boleto.
- Se guarda un compromiso SHA-256 de la semilla.
- Se calcula una huella SHA-256 del conjunto ordenado de boletos elegibles.
- La selección usa `SHA256_REJECTION_V1`, determinista y sin sesgo de módulo.
- Se registra una huella final del resultado.
- La API expone la prueba en el historial y en la verificación pública del ganador.
- El panel administrativo incorpora historial de sorteos y huella del resultado.
- Se mantienen las reglas de ganador único/múltiples victorias.

La prueba mejora la trazabilidad, pero no sustituye una auditoría externa ni pretende demostrar por sí sola la identidad del organizador o la legalidad de una rifa.
