# Milestone 20 · Notificaciones realtime seguras

## Objetivo
Convertir las notificaciones persistentes en un canal realtime privado sin exponer identificadores de usuario como salas públicas.

## Cambios
- Socket.IO acepta opcionalmente el JWT en `auth.token`.
- Solo tokens con rol `USER` reciben una sala privada `user:<id>` en el servidor.
- La sala privada no se puede solicitar desde el cliente.
- El cliente sincroniza el token actual al iniciar una suscripción y recupera las salas de rifas tras reconexión.
- `notification` se emite después de persistir la notificación en base de datos.
- La cuenta del cliente escucha notificaciones nuevas, muestra contador de no leídas y permite marcar una o todas como leídas.
- Se corrigió la importación de `QRCodeSVG` en la cuenta.
- Se mantiene la API persistente como fuente de verdad; realtime es una mejora de entrega.

## Seguridad
Nunca se confía en un `user_id` enviado por el navegador para entrar a una sala privada. El servidor deriva la identidad exclusivamente del JWT firmado.

## Compatibilidad
Los sockets públicos de rifas continúan funcionando para disponibilidad y sorteos. La autenticación solo añade una sala privada cuando existe un JWT válido de usuario.
