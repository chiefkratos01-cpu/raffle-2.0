# Milestone 33 - Release smoke and final hardening

## Included
- Added a dependency-light release smoke validator at `Backend/tools/smoke_check.py`.
- Smoke validator creates a fresh SQLite database and runs Alembic to `head`.
- Validates critical tables and the historical `ticket_allocations.ticket_id` `ON DELETE SET NULL` contract.
- Validates draw-proof fields, reservation/payment-review protections, canonical notifications, release version and pnpm pin.
- Hardened refresh-token rotation with a row lock via SQLAlchemy `with_for_update()` where supported by the database.
- Added production HTTPS enforcement for frontend API and realtime URLs.

## Verification in the development environment
- Static release gate: expected PASS.
- Dependency-light smoke check: expected PASS.
- `compileall`: expected PASS.
- Full backend tests still require the declared Python dependencies.
- Frontend build still requires Node/pnpm dependencies.

## Termux validation
This milestone is the bridge to real-device validation. Install the declared dependencies in Termux, run the smoke check, backend tests, frontend install/build, then perform the manual raffle flow from two clients.
