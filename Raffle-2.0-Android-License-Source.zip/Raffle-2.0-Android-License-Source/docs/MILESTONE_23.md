# Milestone 23 · Seguridad de sesiones en la interfaz

## Completado
- El cierre de sesión revoca la sesión actual en el backend, tanto para clientes como para administradores.
- El frontend añade un centro de sesiones activas con IP, navegador/dispositivo, fechas y sesión actual.
- Se puede cerrar una sesión individual o todas las demás sesiones manteniendo la actual.
- La interfaz usa el `sid` autenticado como autoridad y nunca acepta un identificador de usuario para seleccionar sesiones.
- Se normalizaron tokens visuales `--surface-2`, `--accent` y `--accent-soft` para evitar estilos incompletos en componentes de seguridad/verificación.

## Seguridad
El endpoint de logout ya no depende de que el cliente proporcione un refresh token válido para identificar qué sesión revocar. El access token autenticado identifica la sesión actual. El refresh token sigue rotándose y almacenándose como hash.
