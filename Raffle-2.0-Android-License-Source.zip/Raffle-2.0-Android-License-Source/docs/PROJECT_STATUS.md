# Estado del proyecto

## Milestone 5
- Verificación pública de boletos mediante código seguro.
- QR individual para cada boleto pagado, apuntando a la página pública de verificación.
- La verificación muestra rifa, número, estado de pago y si el boleto resultó ganador.
- El QR no expone credenciales ni datos privados del cliente.

## Milestone 4
- Centro administrativo visual para rifas, pagos y sorteos.
- Configuración visual de ganadores, premios, reglas y reservas.
- Ruleta conectada al resultado autoritativo del backend.

## Milestone 3
- Motor de sorteo autoritativo en backend: el navegador nunca decide el ganador.
- Ganador persistido antes de emitir el evento realtime.
- `animation_seed` y `target_angle` generados por servidor para que todos los clientes puedan representar el mismo resultado.
- Cantidad configurable de ganadores y premios por posición.
- Restricción opcional de una sola victoria por usuario.
- Boletos con código individual de verificación.
- Notificaciones persistentes para clientes.
- Panel administrativo funcional: métricas, pagos pendientes y sorteo.
- Interfaz cliente funcional: registro/login, rifas, selección de números, reserva, “Ya pagué”, mis boletos y notificaciones.
- Tema Sistema/Claro/Oscuro con transición y soporte de movimiento reducido.

## Siguiente bloque
- Selector virtualizado de números para 1.000+ y potencialmente 1.000.000 de boletos.
- Estado realtime completo: recuperación al reconectar y animación de ruleta sincronizada.
- CRUD administrativo visual de rifas, premios, reglas y medios de pago.
- QR y verificación pública de tickets.
- Auditoría automática de acciones administrativas.
- Licencias firmadas + keygen externo.
- Pruebas de concurrencia, seguridad, rate limiting, headers y CORS de producción.
- PWA, empaquetado y guía de instalación para Termux.

## Milestone 10
- Public winner results endpoint no longer exposes internal user IDs.
- Customer raffle detail includes live-safe winner history.
- Admin draw controls prevent starting another draw while a raffle is DRAWING.
- Public results link to winner verification codes.

## Milestone 11 - Integración y hardening
- Revisión del motor de sorteos para serializar peticiones y rechazar sorteos duplicados/en curso.
- Pruebas backend ejecutadas desde `Backend/`: 4 pruebas de integridad pasaron.
- Compilación Python del backend verificada.
- Documentación de preparación para integración y producción añadida.
- Frontend mantiene `pnpm@10.15.1` como gestor oficial.

## Milestone 12 - Integración administrativa y verificación pública
- Añadida la ruta pública `/verify/winner/{code}` para que los enlaces de verificación de ganadores funcionen realmente desde el frontend.
- Añadido panel administrativo de Administradores usando los endpoints protegidos de seguridad.
- Añadida activación/desactivación de cuentas administrativas desde el panel, manteniendo la protección SUPER_ADMIN en backend.
- Añadido visor de auditoría administrativa con actualización manual y detalle resumido del evento.
- Rechazo de pagos desde el panel ahora solicita y conserva un motivo explícito.
- Mensajería del centro de sorteos deja claro que el resultado lo decide el backend y no el navegador.
- Mejorada la información del selector de números cuando se alcanza el máximo de boletos por cliente.
- Mantiene exactamente los tres modos de tema: Sistema, Claro y Oscuro.
- Se conserva `pnpm@10.15.1` como gestor oficial del frontend.

### Verificación del hito
- Backend: 6/7 pruebas ejecutables pasaron; la prueba de importación de la aplicación no puede ejecutarse en este entorno porque falta el paquete `python-jose`, aunque está declarado en `Backend/requirements.txt`.
- Frontend: no se ejecutó `pnpm build` porque `pnpm` no está instalado en el entorno de trabajo. El proyecto conserva la configuración estricta de pnpm para la instalación real.

## Milestone 14 - Capa de servicios y realtime del frontend
- Extraídos servicios de rifas y Socket.IO para reducir acoplamiento en `App.js`.
- Extraídos hooks reutilizables de disponibilidad y realtime.
- Extraídos componentes de tema y toast.
- La ruleta usa la nueva capa realtime y mantiene polling de recuperación.
- `REACT_APP_SOCKET_URL` permite separar explícitamente el endpoint Socket.IO del API.
- No se añaden dependencias nuevas y se mantiene `pnpm@10.15.1`.


## Milestone 14
- Selector de boletos escalable por bloques.
- Búsqueda directa de número.
- Disponibilidad realtime mediante `raffle_update`.
- Realtime separado entre disponibilidad y sorteos.


## Milestone 15
- Frontend separado en páginas/componentes con `App.js` reducido a entrada y navegación.
- Servicios de negocio con control explícito de commit para composición transaccional.
- Auditoría de creación de rifa y decisiones de pago queda en la misma transacción que la operación principal.
- Realtime se emite después del commit.
- Pruebas enfocadas: 4/4.


## Milestone 16 - Sorteos verificables
- La semilla se genera antes de la selección y se conserva para reproducir el resultado.
- Añadido compromiso SHA-256 de la semilla, huella del conjunto elegible y huella final del resultado.
- Selección determinista `SHA256_REJECTION_V1` con rechazo para evitar sesgo de módulo.
- Historial administrativo de sorteos con huella de resultado.
- Verificación pública del ganador muestra la evidencia criptográfica disponible.
- Pruebas enfocadas del backend: 6/6 pasaron.


## Milestone 17

Completado: concurrencia de reservas reforzada y trazabilidad histórica de asignaciones de boletos mediante `ticket_allocations`. Migración `8c4d2e7a1b90`.

## Milestone 23 - Seguridad de sesiones en interfaz
- Logout revoca la sesión actual en backend para usuarios y administradores.
- Centro de sesiones activas en cuenta y administración.
- Cierre individual de sesiones y cierre de todas las demás manteniendo la actual.
- Se muestran dispositivo/navegador, IP y fechas sin exponer refresh tokens.
- Normalizados tokens visuales compartidos para superficies y acentos.
- Migraciones desde cero hasta `head` verificadas.

## Milestone 26 - Operación y observabilidad básica
- Añadidos endpoints de liveness/readiness para despliegue.
- `/health` informa estado y latencia de base de datos.
- `/health/ready` devuelve 503 cuando la base de datos no está disponible.
- La actividad de sesiones se actualiza con una ventana de cinco minutos para evitar escrituras innecesarias.
- Pruebas seleccionadas: 12/12.
- `compileall`: OK.
- Alembic desde cero hasta `head`: OK.


## Milestone 27 - Configuración segura de producción
- Validación de configuración sensible en entorno `production`.
- Rate limiting y clave pública de licencia obligatorios en producción.
- Frontend bloquea builds de producción que apunten a localhost.
- Plantillas `.env.example` actualizadas.


## Milestone 32 - Gate de release reproducible
- Añadido `Backend/tools/release_check.py` para validar estructura, versión, dependencias críticas y ausencia de artefactos locales/cache en el archivo fuente.
- README y checklist actualizados para usar el gate estático antes de una entrega.
- Gate estático: PASS en `2.0.0-rc.1`.
- Compilación Python: PASS.
- Migración limpia hasta `c2e7a9f1b4d6`: PASS.
- La suite completa y el build frontend siguen requiriendo un entorno con dependencias instaladas.


## Milestone 36 — Android client and configurable signed licensing (2026-09-30)
- Added a Capacitor 8 Android project (`com.codexiasystems.raffle2`) around the existing local React bundle, with secure AES-GCM session/cache storage backed by Android Keystore, system share/clipboard/haptics/network integrations, Android URL intents for WhatsApp, app Back handling, verification/raffle deep links, safe-area layout and Raffle-branded icon/splash.
- Added local Ed25519 schema-v2 verification and online/offline status UI; configurable interval/grace/suspension behavior; server-authoritative quota enforcement; reversible migration `a6d4f20c9b31` for license ID, organization and schema version.
- Added the Windows Tkinter Keygen source, editable Trial defaults (3/100/2/1; no fixed duration), blank-by-default configurable Commercial quotas persisted per user, strict numeric signed claims, encrypted signing-key format, CLI, tests and Windows packaging batch file. No private signing key was generated or included.
- Corrected a pre-existing SQLite-incompatible default-removal operation in migration `f1c2d3e4b5a6` so fresh SQLite migrations run; the new migration is also tested through upgrade/downgrade/re-upgrade.
- Verification in this sandbox: backend suite 86/86; frontend Jest 38/38; React production bundle compiled; fresh SQLite Alembic chain to `a6d4f20c9b31` plus downgrade/re-upgrade passed; Keygen GUI under Xvfb confirmed exact Trial values, blank duration, initially blank Commercial defaults and successful Commercial-default save/reload; Android `assembleDebug` and `bundleRelease` both compiled.
- The APK/AAB compile smoke used non-routable `example.invalid` endpoints and a dummy public key; it is not a usable or signed production client and is excluded from delivery. No Android emulator/device is attached. Actual connected APK/AAB testing needs the owner’s HTTPS API/Socket.IO/public web URL and matching Ed25519 public key; release distribution additionally needs the owner’s signing configuration. Windows `.exe` packaging must be run on Windows.
- See `docs/ANDROID_LICENSE_DELIVERY_REPORT.md` for the complete A–S report, test limits and build instructions.
