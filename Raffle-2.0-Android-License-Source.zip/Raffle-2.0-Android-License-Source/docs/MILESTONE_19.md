# Milestone 19 - Centro de notificaciones

## Objetivo
Completar la base del sistema de notificaciones persistentes para que el cliente pueda consultar su historial y gestionar su estado de lectura sin acceder a notificaciones de otros usuarios.

## Cambios
- Nuevo router `GET /api/v1/notifications/mine`.
- Nuevo endpoint `POST /api/v1/notifications/{notification_id}/read`.
- Nuevo endpoint `POST /api/v1/notifications/read-all`.
- Las consultas quedan estrictamente limitadas al usuario autenticado.
- El listado usa `created_at` + `id` para un orden estable.
- Se mantienen las notificaciones persistentes existentes de pagos y sorteos.
- Pruebas de aislamiento por usuario y estado de lectura.

## Seguridad
Un usuario no puede marcar como leída una notificación perteneciente a otro usuario. El backend es la autoridad para decidir qué notificaciones puede consultar y modificar cada cuenta.

## Pendiente
La entrega posterior puede añadir actualización realtime del buzón de notificaciones mediante un canal autenticado por usuario. No se habilita un room público por `user_id`, porque eso permitiría suscripciones no autorizadas.
