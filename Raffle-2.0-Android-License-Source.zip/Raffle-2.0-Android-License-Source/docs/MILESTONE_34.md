# Milestone 34 - UX, demo, organizer access and production workflow

## Producto y acceso
- La pantalla pública inicia en Home; el cliente no tiene que elegir un rol al registrarse.
- Se añadió el flujo `Quiero organizar rifas` para que una cuenta de cliente solicite acceso como organizador.
- Las solicitudes son revisadas por `SUPER_ADMIN`. Al aprobarse se crea el acceso de organizador principal con rol `ADMIN`.
- Se mantienen los roles administrativos existentes: `SUPER_ADMIN`, `ADMIN`, `OPERATOR`, `FINANCE` y `VIEWER`.
- Se añadió gestión de equipo para `ADMIN`, permitiendo accesos separados para `OPERATOR`, `FINANCE` y `VIEWER`.
- `SUPER_ADMIN` puede consultar y activar/desactivar cuentas de clientes sin borrar su historial.

## Demo y licencias
- En modo demo se crea una única rifa de prueba que no aparece en el catálogo público.
- La demo permite explorar el flujo sin presentar sus datos como una rifa real.
- La licencia activa habilita la operación de producción.
- Una licencia vencida entra en modo limitado: no permite crear/publicar nuevas rifas, pero las rifas activas pueden completar operaciones necesarias, incluido su sorteo.
- La activación de una licencia puede realizarla `SUPER_ADMIN` o el `ADMIN` principal del organizador.

## UX
- Home renovada con la identidad visual vibrante de Raffle 2.0.
- Nueva guía para clientes y administradores.
- Nueva sección de reglas de plataforma, reglas generales de rifas y explicación de reglas particulares.
- Campos de contraseña con mostrar/ocultar y confirmación durante el registro.
- Formulario de rifas con ayuda en lenguaje no técnico.
- Selector de imagen desde el dispositivo, sin pedir URLs.
- Las rifas usan una sola imagen principal opcional; no se añadieron galerías ni fotos de perfil.
- La ruleta sigue siendo un componente interactivo generado por código, no una imagen estática.

## Calidad
- Se corrigió el problema del precio decimal en el formulario mediante `step=0.01` y validación propia, evitando el salto de la página causado por la validación HTML nativa.
- Se incorporó la corrección de fechas ingenuas/UTC en sesiones.
- Se fijó `bcrypt==4.1.3` por compatibilidad con Passlib 1.7.4.
- Se añadieron pruebas de contrato para organizadores, demo, licencias, carga de imágenes y permisos.
- Se actualizaron las pruebas frontend de formato, selector de boletos y contraseñas.
- Compilación Python y análisis de sintaxis JSX realizados en el entorno de preparación.
- La suite completa de backend y el build/test real de frontend siguen requiriendo un entorno con todas las dependencias instaladas.
