# Milestone 26 - Observabilidad operativa y estado de sesiones

## Objetivo
Mejorar la preparación operacional de Raffle 2.0 sin añadir infraestructura externa.

## Cambios
- `GET /health` ahora informa estado general, estado de base de datos y latencia de la prueba `SELECT 1`.
- `GET /health/live` funciona como liveness probe y no depende de la base de datos.
- `GET /health/ready` funciona como readiness probe y comprueba la base de datos.
- La actividad de una sesión autenticada se actualiza como máximo una vez cada cinco minutos, evitando una escritura por cada petición.
- Se mantienen las mismas garantías de expiración y revocación de sesiones.

## Operación
En un despliegue real se recomienda usar `/health/live` para comprobar que el proceso existe y `/health/ready` para decidir si debe recibir tráfico.

La aplicación sigue sin exponer secretos en estos endpoints. La configuración pública continúa limitada a datos necesarios para el cliente.

## Verificación
- Pruebas unitarias específicas del contrato operativo y actividad de sesión.
- Compilación Python del backend.
- Migración limpia de Alembic desde la base inicial hasta `head`.
