# Milestone 15 · Arquitectura y consistencia transaccional

## Objetivo
Reducir el acoplamiento del frontend y asegurar que las operaciones de negocio con auditoría se confirmen como una sola transacción de base de datos.

## Frontend
`App.js` queda como punto de entrada/router ligero. Las vistas principales se separaron en `pages/` y las piezas reutilizables en `components/`.

Estructura relevante:

```text
Frontend/src/
├── App.js
├── pages/
│   ├── LoginPage.js
│   ├── HomePage.js
│   ├── RaffleDetailPage.js
│   ├── AccountPage.js
│   ├── AdminPage.js
│   ├── TicketVerifyPage.js
│   └── WinnerVerifyPage.js
├── components/
│   ├── NumberPicker.js
│   ├── Results.js
│   ├── RaffleEditor.js
│   ├── Roulette.js
│   ├── Toast.js
│   └── ThemeSelector.js
├── hooks/
├── services/
├── context/
├── styles/
└── utils/
```

## Backend
Los servicios de negocio aceptan ahora `commit=False` cuando una ruta necesita incorporar auditoría u otras modificaciones dentro de la misma transacción.

Aplicado a:
- creación de rifas + `RAFFLE_CREATED`
- creación de reservas desde API + commit explícito antes de realtime
- envío de comprobante de pago
- confirmación/rechazo de pagos + auditoría

`release_expired()` también permite participar en una transacción existente.

La emisión realtime continúa después del commit. Si un cliente Socket.IO falla, el estado persistido no se revierte, porque la base de datos es la autoridad.

## Verificación
Pruebas enfocadas ejecutadas desde `Backend`:

```text
4 passed in 0.30s
```

También se ejecutó `compileall` sobre backend y tests sin errores de sintaxis.

El build del frontend no se ejecutó en este entorno porque `pnpm` no está instalado.
