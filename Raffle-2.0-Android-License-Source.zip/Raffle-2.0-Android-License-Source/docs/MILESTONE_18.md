# Milestone 18: Realtime recovery and ticket-history referential integrity

## Objetivo

Hacer que la capa realtime sea resistente a múltiples componentes suscritos a la misma rifa y a reconexiones, y cerrar un problema de integridad entre el historial de asignaciones y los tickets reciclables.

## Cambios

- `TicketAllocation.ticket_id` usa `ON DELETE SET NULL` para que eliminar un ticket histórico no destruya ni bloquee su registro de auditoría.
- Nueva migración `9d6e4f2b7c31_ticket_allocation_ticket_fk_set_null.py`.
- El cliente Socket.IO mantiene conteo de suscriptores por rifa.
- Solo el primer suscriptor entra a la sala y solo el último sale.
- Las salas activas se vuelven a unir automáticamente después de una reconexión.
- La disponibilidad pública emite `raffle_update` cuando una consulta libera reservas expiradas, de modo que otros clientes puedan refrescarse sin esperar polling externo.

## Regla importante

La base de datos sigue siendo la autoridad. Socket.IO solo acelera la propagación de cambios. Si un cliente pierde conexión, la UI debe recuperar el estado mediante las APIs/polling existentes.

## Verificación

- Migración desde cero con Alembic sobre SQLite.
- Tests de reserva y prueba de borrado/reutilización del ticket histórico.
- Validación sintáctica de backend.
- El build de frontend queda pendiente de ejecutarse en un entorno con Node/pnpm y dependencias instaladas.
