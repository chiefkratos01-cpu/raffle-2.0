# Milestone 28 - Contrato frontend/backend

## Objetivo
Reducir regresiones entre las rutas HTTP que consume el frontend y las rutas que realmente expone el backend.

## Cambios
- Añadida una prueba de contrato estática que descubre rutas FastAPI en `Backend/app/api`.
- La prueba inspecciona las llamadas `api.get/post/put/patch/delete` del frontend y detecta endpoints fijos que no existen en el backend.
- Se verifica además la presencia de los archivos críticos de configuración/integración.
- No se modifican contratos públicos ni se introducen endpoints ficticios.

## Verificación
- `test_frontend_backend_contract.py`: pasa.
- `compileall` del backend: pasa.
- Migración Alembic desde una BD SQLite nueva hasta `head`: pasa.
- La suite completa no puede ejecutarse en este entorno porque falta la dependencia instalada `python-jose`; el proyecto la declara en `requirements.txt`.

## Nota
La prueba es deliberadamente conservadora: rutas dinámicas con `${...}` no se inventan ni se comparan como si fueran literales. Es una barrera de regresión, no un sustituto de pruebas E2E con navegador.
