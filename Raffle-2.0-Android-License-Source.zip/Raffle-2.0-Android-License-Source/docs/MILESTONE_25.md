# Milestone 25 · HTTP abuse protection and request hardening

## Objetivo
Añadir una primera capa de protección contra abuso HTTP sin introducir una dependencia externa obligatoria.

## Cambios
- Rate limiting deslizante por IP/endpoint.
- Límites más estrictos para login, registro, refresh, sorteos, reservas y verificación pública.
- Respuesta `429` con `Retry-After` cuando se supera el límite.
- `X-Request-ID` generado automáticamente si el cliente no lo proporciona.
- Respuestas de autenticación marcadas como `Cache-Control: no-store`.
- El middleware no confía en `X-Forwarded-For` de forma implícita.
- Nueva configuración `RATE_LIMIT_ENABLED` preparada para despliegues posteriores.

## Nota de producción
El limitador actual es **por proceso**. Es adecuado para una instalación local/una instancia, pero una instalación con varios workers debe sustituir el almacenamiento por Redis u otro almacén compartido antes de escalar horizontalmente.

## Validación
- Pruebas unitarias del limitador y selección de reglas.
- Compilación del backend.
- Migraciones no requieren cambios de esquema en este milestone.
