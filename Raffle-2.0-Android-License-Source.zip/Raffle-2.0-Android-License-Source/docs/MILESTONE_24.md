# Milestone 24 - Realtime authentication hardening

## Objetivo
Alinear la autenticación de Socket.IO con la sesión server-side introducida en los milestones 21-23 y limitar el abuso accidental de suscripciones a rifas.

## Cambios
- Socket.IO valida `sid`, usuario, sesión activa y expiración en la base de datos.
- Logout/revocación de una sesión invalida también futuras conexiones Socket.IO hechas con ese token.
- Usuarios desactivados no reciben sala privada de notificaciones.
- Se limita a 20 salas de rifas por conexión para evitar suscripciones accidentales masivas.
- La lista de salas activas se conserva por socket para que `leave_raffle` y la recuperación del frontend sean coherentes.
- Los administradores no reciben acceso a salas privadas de usuarios mediante el socket público.

## Seguridad
El socket sigue sin aceptar un `user_id` enviado por el cliente. La identidad privada procede exclusivamente del JWT y de la sesión persistida.

## Nota de despliegue
La validación usa una consulta síncrona corta porque el backend actual utiliza SQLAlchemy síncrono para su capa de persistencia. En una instalación de alta concurrencia puede migrarse a una sesión async dedicada.
