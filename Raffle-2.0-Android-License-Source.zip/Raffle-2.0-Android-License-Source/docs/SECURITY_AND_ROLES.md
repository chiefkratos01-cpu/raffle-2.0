# Seguridad y roles administrativos

Raffle usa un único token JWT para usuarios y administradores, pero el backend valida el rol y las capacidades en cada operación sensible.

## Roles

| Rol | Uso | Capacidades principales |
|---|---|---|
| SUPER_ADMIN | Propietario del sistema | Todas, incluyendo administradores y licencia |
| ADMIN | Gestión general | Rifas, sorteos, consultas y auditoría |
| OPERATOR | Operación diaria | Reservas, atención y sorteos |
| FINANCE | Pagos | Revisión y confirmación/rechazo de pagos |
| VIEWER | Solo lectura | Dashboard, rifas, reservas, clientes y auditoría |

`SUPER_ADMIN` puede realizar todas las capacidades. El resto usa permisos explícitos en `Backend/app/core/deps.py`.

## Auditoría

Las operaciones administrativas importantes generan registros en `audit_logs`, incluyendo actor, acción, entidad, valores relevantes, IP cuando está disponible y fecha UTC.

La auditoría no debe almacenar contraseñas, tokens JWT, claves privadas ni credenciales bancarias.

## Producción

Antes de pasar a producción:

- `DEBUG=false`
- `DEMO_MODE=false`
- `DOCS_ENABLED=false` salvo que exista protección adicional
- `JWT_SECRET_KEY` debe ser un secreto aleatorio de al menos 32 caracteres
- `CORS_ORIGINS` debe contener únicamente orígenes confiables
- TLS/HTTPS debe terminar en el servidor o proxy de producción
- Las credenciales expuestas históricamente deben rotarse, aunque ya no aparezcan en los archivos actuales

## Acceso de organizadores

El registro normal crea clientes. Una persona que quiera organizar rifas solicita acceso de organizador y el SUPER_ADMIN revisa la solicitud. Al aprobarla se crea un acceso administrativo principal con rol ADMIN.

El organizador principal puede añadir miembros de equipo con permisos limitados. Los accesos administrativos no deben compartirse entre personas.
