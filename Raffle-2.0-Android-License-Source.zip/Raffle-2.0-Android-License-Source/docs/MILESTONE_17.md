# Milestone 17 - Reservation concurrency and allocation history

## Objetivo

Reforzar el ciclo de vida de las reservas y evitar que reutilizar un número de boleto destruya la trazabilidad de una asignación anterior.

## Cambios

- Las reservas intentan bloquear la fila de la rifa con `SELECT ... FOR UPDATE` en bases que soportan bloqueo de filas.
- La restricción única `(raffle_id, number)` continúa siendo la última barrera contra una doble asignación.
- Las reservas expiradas y los rechazos de pago generan un registro en `ticket_allocations` antes de liberar el boleto.
- `ticket_allocations` conserva número, reserva, usuario, boleto original, código de verificación, estado y motivo/fecha de liberación.
- Un número liberado puede reutilizarse sin borrar su historial de asignación.
- `PAYMENT_REVIEW` continúa excluido de la liberación automática.
- `release_expired()` ahora devuelve la cantidad de boletos liberados y permite componer la operación dentro de una transacción existente.

## Garantía de diseño

La tabla `tickets` representa la asignación vigente del número. `ticket_allocations` representa el historial de asignaciones anteriores. Por tanto, una futura reserva del mismo número recibe una nueva identidad y un nuevo código de verificación sin perder la evidencia de la reserva anterior.

## Pruebas

- Migración completa sobre SQLite nuevo: OK.
- Integridad de reservas, sorteos, tickets y prueba verificable: 6 pruebas OK.
- Nueva prueba de historial de asignación: incluida en `test_reservation_integrity.py`.
