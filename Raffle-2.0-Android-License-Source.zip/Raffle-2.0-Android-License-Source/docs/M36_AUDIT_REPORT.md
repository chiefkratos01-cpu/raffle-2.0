# Raffle 2.0 · M36 audit report

## Scope

This audit reviewed the M36 source archive across backend architecture, lifecycle rules, public API exposure, authentication/RBAC, realtime behavior, media handling, frontend navigation, responsive UI, accessibility-oriented controls, visual consistency and release hygiene.

## Corrections applied

### Backend / business logic
- Public raffle reads now expose only public lifecycle states. Draft and cancelled raffles are no longer retrievable through public raffle, availability, latest-draw or winners surfaces.
- Administrative raffle responses no longer reuse the public visibility filter.
- Publishing is restricted to DRAFT raffles.
- Cancelling a raffle with paid tickets is blocked until a refund workflow exists.
- Cancelling a raffle with only unpaid reservations releases those tickets and rejects pending payment reviews consistently.
- LOW_TICKETS is now derived from confirmed sales and the configured threshold.
- Public draw responses avoid unnecessary internal ticket database IDs.
- Public ticket verification avoids unnecessary internal ticket/raffle database IDs.
- Image uploads validate both MIME type and JPG/PNG/WEBP magic bytes.
- Organizer-request password hashes are cleared after approval or rejection.
- Password strength/whitespace validation is consistent across customer, organizer, team and administrator creation.
- Production responses now include a Content-Security-Policy.
- Socket.IO raffle subscriptions are restricted to public, non-demo raffles.
- Socket session expiry handling normalizes naive database timestamps.

### Realtime / draw engine
- Fixed synchronous draw execution attempting to access an asyncio event loop directly from a worker thread.
- Added a thread-to-async realtime bridge for authoritative `draw_result` events.
- The database remains authoritative; realtime is a delivery mechanism.

### Frontend / UX
- Added stable public raffle URLs such as `/raffle/<id>` that survive refresh.
- Added browser back/forward handling for the main application routes.
- Added native share/copy-link behavior on public raffle details.
- Added explicit loading, empty and network-error states for the public catalogue.
- Replaced mixed emoji/glyph controls in public-facing UI with a consistent SVG icon system.
- Refined the visual palette toward a cleaner indigo/blue SaaS system while retaining Raffle 2.0's purple identity.
- Consolidated duplicated theme tokens.
- Replaced browser prompts for administrator/team credential creation with a proper form modal.
- Added visible labels and stronger accessibility semantics to login fields and toasts.
- Improved mobile/admin navigation consistency.

## External UX references

The audit considered current patterns from established raffle platforms including GalaBid and Raffall. Relevant patterns included direct/shareable raffle links, QR-oriented discovery, explicit raffle controls and operational dashboards, live draw displays, clear winner presentation, ticket verification and transparency. These were used as product references, not copied as branding.

## Verification status

Passed in this audit environment:
- Static release gate.
- Python compilation of application, tools and tests.
- Static regression assertions for the corrected contracts.
- No fixed development password remains in the source.
- No cache/database/environment artifacts are included in the source tree.

Not executable in this audit environment:
- Full backend pytest suite because the environment lacks the pinned `python-jose` dependency and cannot reach package registries.
- Frontend `pnpm test` / `pnpm build` because pnpm/dependencies are not installed and package registry access is unavailable.

These runtime gates must be executed in the real development environment before a commercial production release.

## Reference platforms reviewed

- GalaBid raffle documentation and platform feature pages.
- Raffall help documentation covering ticket visibility, winner flow, verification and public competition presentation.
