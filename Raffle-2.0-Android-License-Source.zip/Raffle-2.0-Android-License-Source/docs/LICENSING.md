# Raffle 2.0 licensing

Raffle 2.0 uses signed Ed25519 licenses. `TRIAL` and `COMMERCIAL` are the two schema-v2 product license types. The old `DEMO` mode remains a separate local demonstration configuration; it is not a schema-v2 commercial license. License validity is separate from raffle, ticket and payment state.

## Signed schema v2

Every schema-v2 token includes `schema_version`, unique `license_id`, `product`, `license_type`, `organization_id`, optional `organizer_id`, `issued_at`, `starts_at`, `expires_at` (nullable for a non-expiring issuance), `license_status` (`ACTIVE`, `SUSPENDED` or `REVOKED`), all four standard quota fields, an extensible `limits` object, `features`, and optional `installation_id`. Each field is inside the Ed25519-signed payload. The backend and Keygen require every standard quota to be an explicit non-negative integer; schema-v2 validation rejects missing or null standard quotas. No Commercial quota values are assumed; the issuer configures the actual values. The Android app reads these signed values and does not contain quota constants. Existing schema-v1 tokens retain their prior compatibility path.

Initial Trial defaults are configurable in backend environment and the Keygen's `license_defaults.json`: **3 active raffles**, **100 tickets per raffle**, **2 team/administration accounts**, and **1 associated organizer**. The Keygen does not assign a fixed Trial duration: an issuer selects a duration in days or an exact expiry date. Future quotas, features, and issue dates can therefore change without updating the Android application.

The current backend maps account quotas to its existing models: team seats count non-organizer `Admin` accounts (the organizer's own approved admin login is counted against `max_organizers` instead); approved organizer requests count against `max_organizers`; active raffles are those in `OPEN`, `LOW_TICKETS`, `SOLD_OUT`, `DRAW_SCHEDULED`, or `DRAWING`; and each real raffle is checked against `max_tickets_per_raffle`. The demo raffle is excluded. Limits are enforced in FastAPI on creation, publication, update, team/admin creation and organizer approval; changing Android requests cannot bypass them.

## Server status and offline behavior

The backend's license row is authoritative for current suspension and revocation. Activation verifies the Ed25519 signature, product, dates, signed schema and limits. `POST /api/v1/license/{license_id}/status` is restricted to `SUPER_ADMIN`, writes an audit event, and can set a registered license to `ACTIVE`, `SUSPENDED`, or `REVOKED`. A revoked license cannot be reactivated with the same key; a suspended license can be reactivated before expiry. Natural expiry remains `EXPIRED`, distinct from intentional `REVOKED`.

Suspension behavior is configurable using `LICENSE_SUSPENDED_POLICY`: `READ_ONLY` (default) blocks protected mutation routes while preserving reads; `ALLOW_EXISTING_COMPLETION` allows configured existing-raffle completion routes but still blocks new licensed operations. Revocation and expiry block new licensed operations. Existing records are not deleted or closed by a status transition.

The backend's `LICENSE_CHECK_INTERVAL_HOURS` defaults to 24 hours. Production must explicitly set `LICENSE_OFFLINE_GRACE_HOURS`; it has no invented commercial default. Android stores access/refresh tokens, signed license tokens and successful GET snapshots in encrypted app-private storage backed by Android Keystore, verifies the signed license locally, and can show cached existing data while disconnected. A cached active state is only considered within the configured grace window; after it becomes stale, the client asks for a fresh online verification before new licensed work. Since mutations are server-authoritative, no offline operation can bypass server quota enforcement. The offline cache is cleared on logout.

## Key generation

The Windows desktop source is [`Backend/tools/license_keygen_gui.py`](../Backend/tools/license_keygen_gui.py); build instructions are in [`Backend/tools/README_KEYGEN_WINDOWS.md`](../Backend/tools/README_KEYGEN_WINDOWS.md). It issues signed license tokens, verifies each signature before presenting it, saves `.lic` files, edits per-user Trial and Commercial defaults (Commercial defaults begin blank), and can update server status using an HTTPS backend and a temporary `SUPER_ADMIN` bearer token. The token is not saved by the Keygen.

New private keys are encrypted at rest with a passphrase-derived Scrypt key and Fernet authenticated encryption. Keep the encrypted signing key and its passphrase in the issuer's protected environment; never bundle either into the Android project, APK, public archive, or Keygen executable. The public key is not secret. Configure it in backend `LICENSE_PUBLIC_KEY` and Android/web build variable `REACT_APP_LICENSE_PUBLIC_KEY` for local signature validation.

The Windows executable is built on Windows (not cross-compiled in this Linux workspace): run `Backend/tools/build_windows_keygen.bat`. Python source and the packaging script are included. The CLI `Backend/tools/license_keygen.py` remains available for automation. Type-specific defaults are in `Backend/tools/license_defaults.json` and may be edited by the Keygen; the initial `commercial` section has no quota values. The backend's initial Trial defaults use `LICENSE_TRIAL_MAX_ACTIVE_RAFFLES`, `LICENSE_TRIAL_MAX_TICKETS_PER_RAFFLE`, `LICENSE_TRIAL_MAX_TEAM_ACCOUNTS` and `LICENSE_TRIAL_MAX_ORGANIZERS`.

## Deployment configuration

Set `LICENSE_PUBLIC_KEY`, a chosen non-negative `LICENSE_OFFLINE_GRACE_HOURS`, and the configured backend/API values before production. Set the corresponding frontend public-key build variable to the same public key. Apply the new additive Alembic migration `a6d4f20c9b31_versioned_license_claims` before using schema-v2 activations on an existing production database. It adds nullable external ID/organization fields and a schema version; it does not delete existing license rows. Existing schema-v1 tokens remain readable for compatibility.
