# Manual del cliente · Raffle 2.0

## Comprar un boleto

1. Selecciona una rifa activa.
2. Elige los números disponibles.
3. Raffle crea una reserva y muestra un código de reserva.
4. Revisa el importe y los métodos de contacto/pago indicados por el organizador.
5. Contacta al organizador por WhatsApp, teléfono o el medio habilitado.
6. Realiza el pago acordado, por ejemplo efectivo o transferencia.
7. Si el organizador lo solicita, envía el comprobante.
8. Espera la confirmación del organizador.

## Estados

- **Reservado:** los números están apartados, pero todavía no son boletos válidos para el sorteo.
- **Pago en revisión:** el organizador está comprobando el pago.
- **Confirmado:** el organizador registró el pago. Los boletos son válidos para el sorteo.
- **Liberado:** la reserva dejó de mantener esos números disponibles para el cliente.
- **Rechazado:** el pago no fue validado. El organizador debe indicar el motivo cuando corresponda.

## Conectividad

La disponibilidad de Internet puede ser intermitente. La rifa indicará su política de liberación automática de reservas. Si está desactivada, el paso del tiempo por sí solo no libera la reserva.

Si la liberación automática está activada, el período y las condiciones deberán mostrarse en las reglas de la rifa antes de la compra.

## Confirmación

El cliente no puede marcar su propio boleto como pagado. La compra se considera válida cuando el organizador confirma el pago en Raffle.

Una vez confirmada, la aplicación mostrará el boleto y su QR de verificación cuando esa función esté disponible.

## Solicitar acceso como organizador

El registro normal crea una cuenta de cliente y no pide elegir un rol administrativo. Si una persona quiere organizar sus propias rifas, puede usar la opción **Quiero administrar mis rifas** y enviar una solicitud. El acceso de organizador solo se habilita después de la revisión del SUPER_ADMIN.
