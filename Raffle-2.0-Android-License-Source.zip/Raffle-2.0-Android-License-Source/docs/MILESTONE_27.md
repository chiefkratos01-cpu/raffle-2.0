# Milestone 27 - Configuración segura de producción

## Objetivo
Evitar que una instalación llegue accidentalmente a producción con valores de desarrollo, rate limiting desactivado o endpoints frontend apuntando a localhost.

## Cambios
- La configuración backend rechaza en producción:
  - `DEBUG=true`.
  - JWT secreto ausente, débil o de ejemplo.
  - `DEMO_MODE=true`.
  - documentación pública habilitada.
  - CORS comodín o sin orígenes explícitos.
  - rate limiting desactivado.
  - contraseña administrativa de ejemplo.
  - clave pública de licencia ausente.
- El frontend centraliza las URLs en `src/config.js`.
- Un build de producción falla de forma explícita si API o Socket.IO siguen apuntando a localhost.
- Añadido `Frontend/.env.example`.

## Verificación
- Pruebas de configuración backend: `4/4`.
- Compilación Python: OK.
- Alembic desde base limpia hasta `head`: OK.
- Build frontend no ejecutado en este entorno porque no hay `pnpm`/`node_modules` instalados.
