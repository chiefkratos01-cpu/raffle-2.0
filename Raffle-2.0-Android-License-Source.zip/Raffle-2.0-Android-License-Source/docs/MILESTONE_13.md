# Milestone 13 - Capa de servicios y realtime del frontend

- Extraídos `ThemeSelector` y `Toast` a componentes independientes.
- Añadido `services/raffles.js` para aislar disponibilidad y resultados.
- Añadido `services/socket.js` con URL configurable mediante `REACT_APP_SOCKET_URL`.
- Añadidos hooks `useRaffleAvailability` y `useDrawRealtime`.
- La ruleta usa la capa realtime y mantiene polling como recuperación.
- El ganador continúa siendo exclusivamente autoritativo del backend.
- No se añaden dependencias nuevas.
- `pnpm@10.15.1` continúa como package manager oficial.
