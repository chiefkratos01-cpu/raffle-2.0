# Android implementation notes

## Official references

- [Capacitor Android documentation, v8](https://capacitorjs.com/docs/android) — Capacitor's Android runtime hosts the local web bundle and communicates with Java/Kotlin plugins. The v8 docs specify Android API 24+ support and the `@capacitor/android` / `npx cap add android` workflow; Android Studio is the primary native-project manager.
- [Capacitor Android plugin guide, v8](https://capacitorjs.com/docs/plugins/android) — a custom native plugin extends `com.getcapacitor.Plugin`, uses `@CapacitorPlugin`, and exposes Java methods annotated `@PluginMethod` to JavaScript.
- [Capacitor App Launcher API, v8](https://capacitorjs.com/docs/apis/app-launcher) — `AppLauncher.openUrl({ url })` delegates a URL to the platform. The existing WhatsApp HTTPS contact link uses this only on Android; web links retain browser behavior. The code does not call `canOpenUrl`, so no app-package visibility query is added.
- [noble-ed25519 official repository](https://github.com/paulmillr/noble-ed25519) — the current `@noble/ed25519` package documents asynchronous `verifyAsync(signature, message, publicKey)` for platforms without sync hash configuration. The app uses this pure-JavaScript verifier so Android WebView can validate Ed25519 signatures locally instead of depending on API-level-specific JCA support.

## Applied decisions

- Android package ID: `com.codexiasystems.raffle2`; version `2.0.0-rc.1`; min/target API 24/36; compile API 36; build tools 36.1.0. Product attribution remains Codexia Systems and Carlos Alejandro Arcia Miranda.
- The React application remains the source of product screens and business flows; the Android package bundles those local assets and calls the existing FastAPI backend.
- Android secure session storage uses an app-private SharedPreferences file encrypted with AES-GCM; the AES key is generated and retained in Android Keystore. Android backup is disabled so encrypted preferences cannot be restored without the Keystore key.
- Signed license tokens are stored in the same encrypted native storage, and `@noble/ed25519` validates their Ed25519 signatures locally with the public key supplied as a build-time setting. No private signing key is included in the app or APK.
- Capacitor App, Status Bar, Keyboard, Share, Haptics, Network and Clipboard integrations use Capacitor APIs. Android file inputs continue to use the platform's system document/photo picker; no camera permission is declared because the current app displays QR codes but does not scan them.
- WhatsApp contact links are delegated to Android's native URL intent so an installed, associated app can handle them; an available browser remains the HTTPS fallback. No WhatsApp-specific permission/provider is added.
- Android cleartext HTTP is disabled. Production/API deployments must use HTTPS/WSS; local emulator/API URLs may require a debug-only network security configuration rather than weakening release traffic policy.
- The app's custom `raffle://` scheme is used only for local app-to-app deep links when no public website URL is configured. Set `REACT_APP_PUBLIC_URL` in production builds to generate public verification and raffle URLs instead.
