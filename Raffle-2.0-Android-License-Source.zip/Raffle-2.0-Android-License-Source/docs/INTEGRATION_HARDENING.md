# Milestone 11 - Integración y hardening

## Objetivo

Esta etapa revisa el flujo completo antes de instalar el sistema en Termux.

## Sorteos

- El cliente nunca elige el boleto ganador.
- El backend crea el `Draw`, crea el `Winner` y persiste ambos antes de emitir el evento realtime.
- La rifa pasa a `DRAWING` mientras la animación está activa.
- Una segunda petición para el mismo premio se rechaza mientras exista un sorteo en curso o terminado.
- La restricción única `(raffle_id, prize_position)` actúa como última barrera de integridad.
- La selección solo considera boletos `PAID`.
- Si `allow_multiple_wins` está desactivado, se excluyen usuarios que ya ganaron en esa rifa.

## Reservas

- La disponibilidad se decide en el backend.
- La restricción única `(raffle_id, number)` evita duplicados.
- Una colisión concurrente se transforma en un error controlado y el cliente puede volver a intentar.
- `PAYMENT_REVIEW` no expira automáticamente.
- Las liberaciones conservan historial mediante `released_at` y `release_reason`.

## Producción

Antes de producción se deben definir por entorno:

- `ENVIRONMENT=production`
- `DEBUG=false`
- `DEMO_MODE=false`
- `DOCS_ENABLED=false`
- `JWT_SECRET_KEY` aleatoria y de al menos 32 caracteres
- `CORS_ORIGINS` con orígenes explícitos
- `LICENSE_PUBLIC_KEY` real
- base PostgreSQL y credenciales fuera del repositorio

No se deben copiar secretos del `.env.example` a producción.

## Pruebas backend

Desde `Backend/`:

```bash
PYTHONPATH=. python -m pytest -q
```

## Frontend

El frontend usa exclusivamente pnpm como gestor:

```bash
pnpm install
pnpm test
pnpm build
```

La versión fijada del gestor es `pnpm@10.15.1`.

## Nota de entorno de desarrollo

El proyecto mantiene SQLite como opción sencilla para desarrollo local. La instalación de producción debe usar una base de datos PostgreSQL configurada mediante variables de entorno.
