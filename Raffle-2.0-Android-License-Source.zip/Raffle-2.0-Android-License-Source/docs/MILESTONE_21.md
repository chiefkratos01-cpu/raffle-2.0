# Milestone 21 — Autenticación y sesiones endurecidas

## Objetivo
Hacer las sesiones revocables y reducir la exposición de credenciales de larga duración.

## Cambios
- Access tokens JWT pasan a incluir `sid`, `iat` y `jti`.
- La vigencia por defecto del access token baja a 30 minutos.
- Nuevo modelo `auth_sessions` para sesiones revocables.
- Nuevo refresh token opaco de alta entropía; solo se almacena su SHA-256.
- Endpoint `POST /auth/refresh` para renovar sesión.
- Endpoint `POST /auth/logout` para revocar la sesión del usuario.
- Cada request autenticada valida que la sesión exista, no esté revocada, no haya expirado y corresponda al sujeto/rol del JWT.
- Frontend renueva automáticamente el access token ante un 401 y elimina credenciales locales si el refresh falla.
- Logout limpia ambos tokens locales.

## Seguridad
El refresh token nunca se coloca dentro del JWT ni se guarda en texto plano en la base de datos. El access token sigue siendo una credencial de corta duración.

## Nota de pruebas
La compilación de Python y las pruebas independientes que no requieren `python-jose` se ejecutaron correctamente. El entorno de trabajo no tiene instaladas todas las dependencias fijadas del backend, por lo que no se presenta como ejecutada una prueba runtime completa de JWT/API.
