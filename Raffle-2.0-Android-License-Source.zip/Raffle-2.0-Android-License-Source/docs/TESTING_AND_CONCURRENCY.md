# Testing y concurrencia

## Reglas verificadas

- El número de boleto es único dentro de una rifa.
- Una reserva liberada o expirada no bloquea permanentemente ese número.
- El historial de la reserva liberada permanece en la base de datos.
- `PAYMENT_REVIEW` no es liberado por el temporizador automático.
- Una reserva `ACTIVE` cuyo tiempo ya venció no puede ser confirmada por administración.
- Cada posición de premio puede tener como máximo un `Draw` gracias a una restricción única de base de datos.
- El ganador se selecciona exclusivamente en el backend.
- Cuando no se permiten múltiples victorias, los boletos del usuario que ya ganó quedan fuera de los candidatos.

## Prueba manual recomendada antes de producción

1. Abrir una rifa con pocos números.
2. Desde dos dispositivos, seleccionar exactamente el mismo número casi al mismo tiempo.
3. Confirmar que solamente una reserva queda activa y la otra recibe conflicto.
4. Dejar expirar la reserva activa.
5. Comprobar que el mismo número vuelve a estar disponible.
6. Enviar una reserva a `PAYMENT_REVIEW` y superar su tiempo original.
7. Confirmar que continúa pendiente de revisión hasta que administración decida.
8. Intentar iniciar dos sorteos para la misma posición simultáneamente.
9. Confirmar que la base de datos permite solamente una posición de premio.

## Nota sobre SQLite y producción

Las pruebas locales usan SQLite por facilidad. La instalación de producción debe usar PostgreSQL para concurrencia multiusuario. Las restricciones únicas de la base de datos siguen siendo la última barrera contra duplicados, mientras que la lógica de servicio valida las reglas de negocio.
