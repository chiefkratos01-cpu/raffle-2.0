# Milestone 32 · Gate de release reproducible

## Objetivo
Crear una barrera automatizable para detectar errores de empaquetado antes de entregar Raffle 2.0.

## Cambios
- Añadido `Backend/tools/release_check.py`.
- Comprueba archivos críticos, coherencia de versión, pnpm 10.15.1, dependencias runtime críticas, checklist y ausencia de `.env`, bases locales, caches, `node_modules`, `build`, `dist` y `.pyc`.
- README y `RELEASE_CHECKLIST.md` actualizados para ejecutar el gate antes de la entrega.
- Limpieza de artefactos generados durante las pruebas.

## Validación
- Gate estático: PASS (`2.0.0-rc.1`).
- `compileall`: PASS.
- Alembic desde base SQLite limpia hasta `c2e7a9f1b4d6`: PASS.
- Suite completa backend: pendiente de entorno con `python-jose` instalado.
- Build/test frontend: pendiente de entorno con pnpm y dependencias instaladas.

## Criterio
Este milestone no declara el producto final. Declara que el código fuente supera los controles que sí pueden ejecutarse en el entorno actual; los gates dependientes de instalación completa deben ejecutarse antes de la release comercial.
