# Milestone 14 - Escalabilidad de boletos y disponibilidad realtime

## Objetivo
Preparar el selector de boletos para rifas grandes sin renderizar todos los números al mismo tiempo y mantener la disponibilidad sincronizada entre clientes.

## Cambios
- Selector paginado en bloques de 100 números.
- Búsqueda directa de un número y salto automático a su página.
- Límite por cliente mostrado de forma explícita.
- Mensaje visible cuando se alcanza el máximo permitido.
- API de disponibilidad conserva el límite de 500 números por consulta.
- Socket.IO emite `raffle_update` después de cambios de reserva/pago.
- El cliente refresca el bloque visible cuando recibe `raffle_update`.
- La ruleta conserva su canal `draw_result` independiente.
- Polling de recuperación de la ruleta permanece como respaldo.

## Principio de consistencia
El navegador puede mostrar disponibilidad, pero nunca puede reservar por sí mismo. La reserva real sigue validándose en el backend y la base de datos es la autoridad final.

## Escala
El límite actual de una rifa es 1.000.000 de boletos. El frontend no crea un millón de elementos: solamente representa el bloque visible de 100.
