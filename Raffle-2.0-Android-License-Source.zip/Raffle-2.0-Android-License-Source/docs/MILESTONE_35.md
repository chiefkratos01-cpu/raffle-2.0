# Milestone 35 - Demo aislada, RBAC, licencia de prueba y refinamiento móvil

## Acceso y permisos
- El panel administrativo respeta los roles SUPER_ADMIN, ADMIN, OPERATOR, FINANCE y VIEWER.
- Las sesiones administrativas se muestran únicamente a SUPER_ADMIN.
- La gestión de administradores generales queda exclusivamente en SUPER_ADMIN.
- VIEWER conserva únicamente las pestañas asociadas a sus permisos de lectura.
- OPERATOR y FINANCE no reciben controles de administración global.
- Los permisos se mantienen también protegidos en backend.

## Licencias
- SUPER_ADMIN puede administrar la instalación sin una licencia comercial activa.
- La demo no consume licencia.
- En desarrollo se crea una licencia TRIAL de 30 días para poder probar operaciones reales sin una licencia comercial.
- En producción se requiere una licencia TRIAL o COMMERCIAL válida para crear/publicar/editar rifas reales y cargar imágenes de operación real.
- Una licencia EXPIRED mantiene accesible la instalación y sus datos, pero limita las operaciones nuevas que requieren licencia.

## Demo aislada
- La demo vive en una experiencia separada `/demo`.
- No aparece en el catálogo público ni en las rifas reales del panel.
- Tiene participantes, boletos y resultados ficticios aislados.
- Puede preparar boletos de demostración y ejecutar el sorteo sin compras reales.
- La demo usa la misma lógica autoritativa de sorteo y la misma ruleta para demostrar el flujo.
- Los usuarios demo se marcan como `is_demo` y no aparecen como clientes normales.
- Se añadieron las imágenes suministradas para boleto, premio, ganador y verificación.
- Las imágenes se presentan con capas de luz, órbitas, destellos y movimiento sutil para evitar el aspecto de imagen congelada.

## Formularios y validaciones
- El acceso de cliente usa el texto "Correo, teléfono o usuario".
- Contraseñas de registro requieren al menos 12 caracteres y no permiten espacios.
- Correo y teléfono se validan en frontend y backend.
- Los datos administrativos también validan usuario, correo y teléfono.
- El formulario de rifa usa un único campo "Teléfono / WhatsApp" y conserva el mismo número para ambos usos.
- Se mantienen las validaciones de precios, cantidades, premios y reservas.

## Tema y móvil
- El selector de tema es un único botón cíclico: automático → claro → oscuro → automático.
- En claro muestra el icono que conduce a oscuro; en oscuro muestra el icono que conduce a claro; en automático muestra el icono de sistema.
- Los iconos son SVG, sin emojis.
- El botón funciona también en móvil.
- Se refinó el control de contraseña para claro y oscuro.
- Se sustituyeron los iconos de la navegación móvil por SVG.
- Se corrigió el desbordamiento de botones administrativos en pantallas pequeñas.
- Se mantiene compatibilidad con `prefers-reduced-motion`.

## Credenciales de desarrollo
- SUPER_ADMIN de desarrollo: `admin` por defecto.
- Si `DEMO_ADMIN_PASSWORD` no está configurada, el entorno de desarrollo genera una contraseña temporal aleatoria y la muestra una sola vez en la consola de arranque.
- En producción la contraseña predeterminada está prohibida y debe sustituirse mediante configuración segura.

## Recuperación de contraseña
- No se implementa todavía el flujo "Olvidé mi contraseña".
- La recuperación/restablecimiento administrado queda planificada para una iteración posterior.

## Calidad
- Se conservan las pruebas existentes de M34.
- Se añaden contratos de M35 para demo aislada, licencia de desarrollo, selector de tema, sesiones por rol y operación real con licencia.
- Se añade migración `f1c2d3e4b5a6_demo_users` para separar usuarios ficticios de clientes reales.

### Verificación adicional de pruebas
- Las pruebas de contrato que leen archivos usan rutas ancladas al repositorio y ya no dependen del directorio desde el que se ejecute `pytest`.
- `Backend/tests/conftest.py` añade `Backend/` al `PYTHONPATH` para que la suite pueda descubrir `app` tanto desde la raíz del repositorio como desde `Backend/`.
- Se reforzaron los contratos de M35 para cubrir permisos por rol, acceso móvil, demo aislada, validaciones, campo único Teléfono / WhatsApp y controles de tema.
- Se añadió validación backend del teléfono del organizador en el esquema de creación/actualización de rifas.
