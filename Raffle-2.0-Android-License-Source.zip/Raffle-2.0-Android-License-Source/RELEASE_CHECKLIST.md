# Raffle 2.0 Release Checklist

## Before delivery
- [ ] Run `python Backend/tools/release_check.py` and obtain a PASS.
- [ ] Install `Backend/requirements.txt` in a clean virtual environment.
- [ ] Install frontend dependencies with `pnpm install` using pnpm 10.15.1.
- [ ] Run the complete backend test suite.
- [ ] Run the frontend production build and tests.
- [ ] Run Alembic migrations against a fresh database and verify `alembic current`.
- [ ] Configure production `.env` from `Backend/.env.example`.
- [ ] Set a unique `JWT_SECRET_KEY` (32+ random characters).
- [ ] Set `ENVIRONMENT=production`, `DEBUG=false`, `DEMO_MODE=false`.
- [ ] Keep API documentation disabled unless explicitly protected.
- [ ] Set explicit trusted `CORS_ORIGINS`.
- [ ] Keep rate limiting enabled.
- [ ] Install the developer-supplied `LICENSE_PUBLIC_KEY`.
- [ ] Create the first real administrator with a unique password.
- [ ] Never ship `.env`, database files, private license keys, refresh tokens, or real credentials.

## Functional smoke test
- [ ] Register/login as a client.
- [ ] Request organizer access, approve it as SUPER_ADMIN, and verify organizer login.
- [ ] Verify demo mode exposes one non-public test raffle and does not allow a second demo raffle.
- [ ] Verify device image upload accepts JPG/PNG/WEBP, rejects unsupported/oversized files, and rejects files whose bytes do not match the declared image type.
- [ ] Verify license expiry blocks new production raffles while allowing an already active raffle to finish.
- [ ] Create/publish a raffle as an authorized administrator.
- [ ] Reserve tickets concurrently from two clients and verify no duplicate allocation.
- [ ] Submit payment review and verify administrator confirmation/rejection behavior.
- [ ] Verify rejected reservations release tickets according to raffle policy.
- [ ] Verify QR/ticket verification publicly without exposing private account data or unnecessary internal database IDs.
- [ ] Verify draft/cancelled raffles cannot be fetched through public raffle, availability, draw-latest or winners endpoints.
- [ ] Verify direct `/raffle/<id>` URLs survive refresh and can be shared/copied.
- [ ] Execute a draw and verify that the backend result is authoritative and reproducible from its stored proof.
- [ ] Verify cancelling a raffle with paid tickets is rejected until refunds are supported, and unpaid reservations are released on cancellation.
- [ ] Open a second client during/after the draw and verify state recovery.
- [ ] Verify notifications are private to the authenticated user.
- [ ] Revoke a session and confirm its refresh token can no longer be used.
- [ ] Confirm `/health/live` and `/health/ready` behave correctly.

## Release package
- [ ] Update version to the intended release version.
- [ ] Re-run the static release gate after the version update.
- [ ] Review `docs/PROJECT_STATUS.md` and milestone history.
- [ ] Review licensing and customer/admin manuals.
- [ ] Remove development-only artifacts and caches.
- [ ] Build the frontend in production mode.
- [ ] Package only the files required for deployment/distribution.
- [ ] Keep the source ZIP as an internal backup and publish the final package only after the complete test pass.


## Milestone 33 gates
- [ ] `python Backend/tools/smoke_check.py` passes in a dependency-complete environment.
- [ ] Backend test suite passes with `Backend/requirements.txt` installed.
- [ ] Frontend `pnpm install --frozen-lockfile` and `pnpm build` pass.
- [ ] Manual two-client raffle, reservation, payment, draw, realtime recovery and QR verification test completed.
- [ ] Production deployment uses HTTPS API/realtime endpoints.

## Android / license / Keygen additions
- [ ] Run the new signed-license, quotas and encrypted-Keygen regression tests.
- [ ] Confirm signed Trial quota values are 3 active raffles, 100 tickets per raffle, 2 team accounts and 1 organizer; set the Trial duration in the issuer configuration for each issuance.
- [ ] Choose and explicitly set `LICENSE_OFFLINE_GRACE_HOURS` and `LICENSE_SUSPENDED_POLICY` in production.
- [ ] Apply Alembic head `a6d4f20c9b31` on a database backup, and verify v1 legacy token behavior before production cutover.
- [ ] Run `pnpm android:debug` with production HTTPS endpoints and the public license key configured; install and smoke-test on supported Android API 24+ hardware/emulators.
- [ ] Verify Android Keystore token storage, logout/account-switch cache clearing, offline GET behavior, stale grace handling, app links, QR verification links, haptics, share, network banner and hardware Back/modal handling.
- [ ] Build the Windows Keygen on Windows using `Backend/tools/build_windows_keygen.bat`; test Trial/Commercial issuance, key verification and authenticated status management.
- [ ] Verify the distributed Android app, Keygen executable and source archive contain no private signing keys, passphrases, admin tokens, `.env` files or customer license files.


## Milestone 36 sandbox verification (2026-09-30)
- [x] Backend regression suite: 86 passed, including signed v2 quota validation and configurable Commercial Keygen defaults.
- [x] Frontend Jest suite: 38 passed; production React bundle compiled with non-routable test-only endpoints and a dummy public key.
- [x] Fresh SQLite migration chain to `a6d4f20c9b31`; downgrade of the new migration and re-upgrade passed.
- [x] Windows Keygen source GUI tested under Xvfb; exact Trial defaults and blank duration confirmed; Commercial fields begin blank, and explicitly configured Commercial defaults save/reload. Python Keygen signing tests passed.
- [x] Capacitor sync and Android `assembleDebug` plus `bundleRelease` compile smokes passed; package ID/version, API 24 minimum/API 36 target, app entry point, debug signature and permissions inspected.
- [x] Smoke APK/AAB excluded from delivery: build used `.invalid` endpoints and a dummy, non-production public key; the AAB is unsigned.
- [ ] Run `python Backend/tools/release_check.py` after removing local dependency/build caches; the gate intentionally rejects an in-tree `node_modules` directory.
- [ ] Owner to configure real HTTPS API and Socket.IO URLs, public website URL, matching public Ed25519 key and production backend license settings.
- [ ] Install and test on physical Android/API 24+ and current devices; no emulator/device was attached to this sandbox.
- [ ] Configure the owner's release signing key and build/sign the production AAB; build the Windows Keygen executable on Windows.
