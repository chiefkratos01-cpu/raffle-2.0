"""Allow historical allocation rows to survive ticket recycling.

Revision ID: 9d6e4f2b7c31
Revises: 8c4d2e7a1b90
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect

revision = "9d6e4f2b7c31"
down_revision = "8c4d2e7a1b90"
branch_labels = None
depends_on = None


def _fk_name(bind, table, column, referred_table):
    for fk in inspect(bind).get_foreign_keys(table):
        if column in fk.get("constrained_columns", []) and fk.get("referred_table") == referred_table:
            return fk.get("name")
    return None


def upgrade():
    bind = op.get_bind()
    name = _fk_name(bind, "ticket_allocations", "ticket_id", "tickets")
    if bind.dialect.name == "sqlite":
        with op.batch_alter_table("ticket_allocations", recreate="always") as batch:
            if name:
                batch.drop_constraint(name, type_="foreignkey")
            batch.create_foreign_key(
                "fk_ticket_allocations_ticket_id",
                "tickets",
                ["ticket_id"],
                ["id"],
                ondelete="SET NULL",
            )
    else:
        if name:
            op.drop_constraint(name, "ticket_allocations", type_="foreignkey")
        op.create_foreign_key(
            "fk_ticket_allocations_ticket_id",
            "ticket_allocations",
            "tickets",
            ["ticket_id"],
            ["id"],
            ondelete="SET NULL",
        )


def downgrade():
    bind = op.get_bind()
    name = _fk_name(bind, "ticket_allocations", "ticket_id", "tickets")
    if bind.dialect.name == "sqlite":
        with op.batch_alter_table("ticket_allocations", recreate="always") as batch:
            if name:
                batch.drop_constraint(name, type_="foreignkey")
            batch.create_foreign_key(
                "fk_ticket_allocations_ticket_id",
                "tickets",
                ["ticket_id"],
                ["id"],
            )
    else:
        if name:
            op.drop_constraint(name, "ticket_allocations", type_="foreignkey")
        op.create_foreign_key(
            "fk_ticket_allocations_ticket_id",
            "ticket_allocations",
            "tickets",
            ["ticket_id"],
            ["id"],
        )
