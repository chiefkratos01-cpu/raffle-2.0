"""store versioned license identity and organization claims

Revision ID: a6d4f20c9b31
Revises: f1c2d3e4b5a6
"""
from alembic import op
import sqlalchemy as sa

revision = "a6d4f20c9b31"
down_revision = "f1c2d3e4b5a6"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("licenses", sa.Column("external_license_id", sa.String(length=128), nullable=True))
    op.create_index("ix_licenses_external_license_id", "licenses", ["external_license_id"], unique=True)
    op.add_column("licenses", sa.Column("organization_id", sa.String(length=128), nullable=True))
    op.create_index("ix_licenses_organization_id", "licenses", ["organization_id"], unique=False)
    op.add_column("licenses", sa.Column("schema_version", sa.Integer(), nullable=False, server_default="1"))
    if op.get_bind().dialect.name == "sqlite":
        with op.batch_alter_table("licenses") as batch_op:
            batch_op.alter_column("schema_version", existing_type=sa.Integer(), existing_nullable=False, server_default=None)
    else:
        op.alter_column("licenses", "schema_version", existing_type=sa.Integer(), existing_nullable=False, server_default=None)


def downgrade():
    op.drop_column("licenses", "schema_version")
    op.drop_index("ix_licenses_organization_id", table_name="licenses")
    op.drop_column("licenses", "organization_id")
    op.drop_index("ix_licenses_external_license_id", table_name="licenses")
    op.drop_column("licenses", "external_license_id")
