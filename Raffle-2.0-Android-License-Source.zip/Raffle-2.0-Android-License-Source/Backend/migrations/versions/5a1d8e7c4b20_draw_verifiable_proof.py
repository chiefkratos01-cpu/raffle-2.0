"""add verifiable draw proof fields

Revision ID: 5a1d8e7c4b20
Revises: 3f7c2a9e6d11
"""
from alembic import op
import sqlalchemy as sa

revision = "5a1d8e7c4b20"
down_revision = "3f7c2a9e6d11"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("draws") as batch_op:
        batch_op.add_column(sa.Column("randomness_commitment", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("eligible_pool_hash", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("result_hash", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("eligible_count", sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column("selection_algorithm", sa.String(length=100), nullable=True))
        batch_op.create_index("ix_draws_randomness_commitment", ["randomness_commitment"], unique=False)
        batch_op.create_index("ix_draws_result_hash", ["result_hash"], unique=False)


def downgrade():
    with op.batch_alter_table("draws") as batch_op:
        batch_op.drop_index("ix_draws_result_hash")
        batch_op.drop_index("ix_draws_randomness_commitment")
        batch_op.drop_column("selection_algorithm")
        batch_op.drop_column("eligible_count")
        batch_op.drop_column("result_hash")
        batch_op.drop_column("eligible_pool_hash")
        batch_op.drop_column("randomness_commitment")
