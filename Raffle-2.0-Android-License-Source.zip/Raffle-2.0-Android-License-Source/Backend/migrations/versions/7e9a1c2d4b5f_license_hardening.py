"""license hardening metadata

Revision ID: 7e9a1c2d4b5f
Revises: 4d2c7f1b9a31
"""
from alembic import op
import sqlalchemy as sa

revision = "7e9a1c2d4b5f"
down_revision = "4d2c7f1b9a31"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("licenses", sa.Column("last_checked_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("licenses", sa.Column("activation_count", sa.Integer(), nullable=False, server_default="0"))

def downgrade():
    op.drop_column("licenses", "activation_count")
    op.drop_column("licenses", "last_checked_at")
