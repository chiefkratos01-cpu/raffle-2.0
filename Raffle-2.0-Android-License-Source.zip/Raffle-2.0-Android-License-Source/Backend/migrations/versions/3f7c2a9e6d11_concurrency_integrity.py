"""Add draw uniqueness for concurrent draw requests.

Revision ID: 3f7c2a9e6d11
Revises: 7e9a1c2d4b5f
"""
from alembic import op

revision = "3f7c2a9e6d11"
down_revision = "7e9a1c2d4b5f"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("draws") as batch_op:
        batch_op.create_unique_constraint(
            "uq_draw_raffle_prize_position", ["raffle_id", "prize_position"]
        )


def downgrade():
    with op.batch_alter_table("draws") as batch_op:
        batch_op.drop_constraint("uq_draw_raffle_prize_position", type_="unique")
