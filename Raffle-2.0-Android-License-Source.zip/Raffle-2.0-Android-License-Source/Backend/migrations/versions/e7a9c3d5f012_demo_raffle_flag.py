"""add demo raffle flag

Revision ID: e7a9c3d5f012
Revises: d4f6a8b2c901
"""
from alembic import op
import sqlalchemy as sa

revision = "e7a9c3d5f012"
down_revision = "d4f6a8b2c901"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("raffles", sa.Column("is_demo", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.create_index("ix_raffles_is_demo", "raffles", ["is_demo"], unique=False)


def downgrade():
    op.drop_index("ix_raffles_is_demo", table_name="raffles")
    op.drop_column("raffles", "is_demo")
