"""add auth session metadata

Revision ID: c2e7a9f1b4d6
Revises: b7f1c9d2e430
"""
from alembic import op
import sqlalchemy as sa

revision = "c2e7a9f1b4d6"
down_revision = "b7f1c9d2e430"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("auth_sessions", sa.Column("ip_address", sa.String(length=64), nullable=True))
    op.add_column("auth_sessions", sa.Column("user_agent", sa.String(length=512), nullable=True))


def downgrade():
    op.drop_column("auth_sessions", "user_agent")
    op.drop_column("auth_sessions", "ip_address")
