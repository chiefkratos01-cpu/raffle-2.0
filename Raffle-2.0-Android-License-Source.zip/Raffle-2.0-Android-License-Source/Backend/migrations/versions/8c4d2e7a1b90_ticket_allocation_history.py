"""Add immutable ticket allocation history.

Revision ID: 8c4d2e7a1b90
Revises: 5a1d8e7c4b20
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "8c4d2e7a1b90"
down_revision = "5a1d8e7c4b20"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "ticket_allocations",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("raffle_id", sa.Integer(), sa.ForeignKey("raffles.id"), nullable=False),
        sa.Column("reservation_id", sa.Integer(), sa.ForeignKey("reservations.id"), nullable=False),
        sa.Column("ticket_id", sa.Integer(), sa.ForeignKey("tickets.id", name="fk_ticket_allocations_ticket_id"), nullable=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("number", sa.Integer(), nullable=False),
        sa.Column("verification_code", sa.String(length=64), nullable=True),
        sa.Column("status", postgresql.ENUM("RESERVED", "PAID", "CANCELLED", "RELEASED", name="ticketstatus", create_type=False), nullable=False),
        sa.Column("allocated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("released_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("release_reason", sa.String(length=255), nullable=True),
    )
    for name, cols in [
        ("ix_ticket_allocations_raffle_id", ["raffle_id"]),
        ("ix_ticket_allocations_reservation_id", ["reservation_id"]),
        ("ix_ticket_allocations_ticket_id", ["ticket_id"]),
        ("ix_ticket_allocations_user_id", ["user_id"]),
        ("ix_ticket_allocations_number", ["number"]),
        ("ix_ticket_allocations_verification_code", ["verification_code"]),
    ]:
        op.create_index(name, "ticket_allocations", cols, unique=False)


def downgrade():
    for name in [
        "ix_ticket_allocations_verification_code", "ix_ticket_allocations_number",
        "ix_ticket_allocations_user_id", "ix_ticket_allocations_ticket_id",
        "ix_ticket_allocations_reservation_id", "ix_ticket_allocations_raffle_id",
    ]:
        op.drop_index(name, table_name="ticket_allocations")
    op.drop_table("ticket_allocations")
