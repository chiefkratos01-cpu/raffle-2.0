"""milestone 3 draw engine, ticket verification and notifications"""
from alembic import op
import sqlalchemy as sa
revision='4d2c7f1b9a31'; down_revision='98a52ff99724'; branch_labels=None; depends_on=None
def upgrade():
    op.add_column('raffles',sa.Column('winner_count',sa.Integer(),nullable=False,server_default='1')); op.add_column('raffles',sa.Column('low_ticket_threshold',sa.Integer(),nullable=False,server_default='10')); op.add_column('raffles',sa.Column('payment_instructions',sa.Text(),nullable=True))
    op.add_column('tickets',sa.Column('verification_code',sa.String(length=64),nullable=True)); op.create_index('ix_tickets_verification_code','tickets',['verification_code'],unique=True)
    op.create_table('notifications',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('user_id',sa.Integer(),nullable=False),sa.Column('title',sa.String(length=160),nullable=False),sa.Column('message',sa.Text(),nullable=False),sa.Column('kind',sa.String(length=40),nullable=False),sa.Column('is_read',sa.Boolean(),nullable=False),sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),sa.ForeignKeyConstraint(['user_id'],['users.id'],ondelete='CASCADE'))
    op.create_index('ix_notifications_user_id','notifications',['user_id']); op.create_index('ix_notifications_is_read','notifications',['is_read']); op.create_index('ix_notifications_created_at','notifications',['created_at'])
    op.execute("UPDATE tickets SET verification_code = 'LEGACY-' || id WHERE verification_code IS NULL")
def downgrade():
    for n in ['ix_notifications_created_at','ix_notifications_is_read','ix_notifications_user_id']: op.drop_index(n,table_name='notifications')
    op.drop_table('notifications'); op.drop_index('ix_tickets_verification_code',table_name='tickets'); op.drop_column('tickets','verification_code'); op.drop_column('raffles','payment_instructions'); op.drop_column('raffles','low_ticket_threshold'); op.drop_column('raffles','winner_count')
