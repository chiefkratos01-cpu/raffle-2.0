"""add organizer requests

Revision ID: d4f6a8b2c901
Revises: c2e7a9f1b4d6
"""
from alembic import op
import sqlalchemy as sa

revision = "d4f6a8b2c901"
down_revision = "c2e7a9f1b4d6"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "organizer_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("desired_username", sa.String(length=80), nullable=False),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("business_name", sa.String(length=160), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="PENDING"),
        sa.Column("admin_id", sa.Integer(), sa.ForeignKey("admins.id", ondelete="SET NULL"), nullable=True),
        sa.Column("reviewed_by_admin_id", sa.Integer(), sa.ForeignKey("admins.id", ondelete="SET NULL"), nullable=True),
        sa.Column("rejection_reason", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("user_id", name="uq_organizer_request_user"),
        sa.UniqueConstraint("desired_username", name="uq_organizer_request_username"),
    )
    op.create_index("ix_organizer_requests_user_id", "organizer_requests", ["user_id"], unique=True)
    op.create_index("ix_organizer_requests_desired_username", "organizer_requests", ["desired_username"], unique=True)
    op.create_index("ix_organizer_requests_status", "organizer_requests", ["status"])
    op.create_index("ix_organizer_requests_admin_id", "organizer_requests", ["admin_id"])
    op.create_index("ix_organizer_requests_reviewed_by_admin_id", "organizer_requests", ["reviewed_by_admin_id"])


def downgrade():
    op.drop_index("ix_organizer_requests_reviewed_by_admin_id", table_name="organizer_requests")
    op.drop_index("ix_organizer_requests_admin_id", table_name="organizer_requests")
    op.drop_index("ix_organizer_requests_status", table_name="organizer_requests")
    op.drop_index("ix_organizer_requests_desired_username", table_name="organizer_requests")
    op.drop_index("ix_organizer_requests_user_id", table_name="organizer_requests")
    op.drop_table("organizer_requests")
