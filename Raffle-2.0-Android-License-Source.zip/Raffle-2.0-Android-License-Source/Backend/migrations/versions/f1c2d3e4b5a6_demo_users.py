"""add demo flag to users

Revision ID: f1c2d3e4b5a6
Revises: d4f6a8b2c901
"""
from alembic import op
import sqlalchemy as sa
revision="f1c2d3e4b5a6"
down_revision="e7a9c3d5f012"
branch_labels=None
depends_on=None

def upgrade():
    op.add_column("users", sa.Column("is_demo", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.create_index("ix_users_is_demo", "users", ["is_demo"], unique=False)
    if op.get_bind().dialect.name == "sqlite":
        with op.batch_alter_table("users") as batch_op:
            batch_op.alter_column("is_demo", existing_type=sa.Boolean(), existing_nullable=False, server_default=None)
    else:
        op.alter_column("users", "is_demo", existing_type=sa.Boolean(), existing_nullable=False, server_default=None)

def downgrade():
    op.drop_index("ix_users_is_demo", table_name="users")
    op.drop_column("users", "is_demo")
