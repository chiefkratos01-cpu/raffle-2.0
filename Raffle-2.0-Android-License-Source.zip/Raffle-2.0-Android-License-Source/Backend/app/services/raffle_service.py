import re
import unicodedata
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.models.raffle import Raffle
from app.models.prize import Prize
from app.models.enums import RaffleStatus


def slugify(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value or "raffle"


def unique_slug(db: Session, title: str, exclude_id: int | None = None) -> str:
    base = slugify(title)
    slug = base
    n = 2
    while True:
        q = select(Raffle.id).where(Raffle.slug == slug)
        if exclude_id:
            q = q.where(Raffle.id != exclude_id)
        if db.scalar(q) is None:
            return slug
        slug = f"{base}-{n}"
        n += 1


def create_raffle(db: Session, data, *, commit: bool = True, is_demo: bool = False) -> Raffle:
    if data.winner_count > len(data.prizes):
        raise ValueError("Create a prize for each winner position")
    positions = [p.position for p in data.prizes]
    if len(positions) != len(set(positions)):
        raise ValueError("Duplicate prize position")
    if any(p.position > data.winner_count for p in data.prizes):
        raise ValueError("Prize position exceeds winner count")
    if data.auto_release_enabled and data.reservation_minutes is None:
        raise ValueError("reservation_minutes is required when automatic release is enabled")
    raffle = Raffle(
        title=data.title.strip(), description=data.description, image=data.image, is_demo=is_demo,
        total_tickets=data.total_tickets, ticket_price=data.ticket_price,
        currency=data.currency.upper(), status=RaffleStatus.DRAFT,
        draw_date=data.draw_date, max_tickets_per_user=data.max_tickets_per_user,
        allow_multiple_wins=data.allow_multiple_wins, auto_release_enabled=data.auto_release_enabled,
        reservation_minutes=data.reservation_minutes, low_ticket_threshold=data.low_ticket_threshold, winner_count=data.winner_count,
        rules=data.rules, payment_instructions=data.payment_instructions,
        organizer_name=data.organizer_name, organizer_whatsapp=data.organizer_whatsapp,
        organizer_phone=data.organizer_phone, slug=unique_slug(db, data.title),
    )
    for prize in sorted(data.prizes, key=lambda p: p.position):
        raffle.prizes.append(Prize(**prize.model_dump()))
    db.add(raffle)
    if commit:
        db.commit()
        db.refresh(raffle)
    else:
        db.flush()
    return raffle



def refresh_sales_status(raffle: Raffle) -> None:
    """Keep the public sales status aligned with confirmed ticket sales.

    Draft/cancelled/drawing/completed states are controlled by explicit lifecycle
    operations and are intentionally left untouched here.
    """
    if raffle.status not in {
        RaffleStatus.OPEN,
        RaffleStatus.LOW_TICKETS,
        RaffleStatus.SOLD_OUT,
        RaffleStatus.DRAW_SCHEDULED,
    }:
        return

    remaining = max(0, raffle.total_tickets - raffle.tickets_sold)
    if remaining == 0:
        raffle.status = RaffleStatus.SOLD_OUT
    elif raffle.status == RaffleStatus.SOLD_OUT:
        raffle.status = RaffleStatus.OPEN
    elif raffle.tickets_sold > 0 and remaining <= raffle.low_ticket_threshold:
        raffle.status = RaffleStatus.LOW_TICKETS
    elif raffle.status == RaffleStatus.LOW_TICKETS:
        raffle.status = RaffleStatus.OPEN

def list_public(db: Session):
    return db.scalars(select(Raffle).options(selectinload(Raffle.prizes)).where(Raffle.is_demo.is_(False), Raffle.status.in_([RaffleStatus.OPEN, RaffleStatus.LOW_TICKETS, RaffleStatus.SOLD_OUT, RaffleStatus.DRAW_SCHEDULED])).order_by(Raffle.created_at.desc())).all()


PUBLIC_RAFFLE_STATUSES = (
    RaffleStatus.OPEN,
    RaffleStatus.LOW_TICKETS,
    RaffleStatus.SOLD_OUT,
    RaffleStatus.DRAW_SCHEDULED,
    RaffleStatus.DRAWING,
    RaffleStatus.COMPLETED,
)


def get_public(db: Session, raffle_id: int, *, include_demo: bool = False):
    query = (
        select(Raffle)
        .options(selectinload(Raffle.prizes))
        .where(
            Raffle.id == raffle_id,
            Raffle.status.in_(PUBLIC_RAFFLE_STATUSES),
        )
    )
    if not include_demo:
        query = query.where(Raffle.is_demo.is_(False))
    return db.scalar(query)
