import hashlib

SELECTION_ALGORITHM = "SHA256_REJECTION_V1"


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def choose_index(seed: str, pool_hash: str, count: int) -> int:
    """Deterministically select an index without modulo bias."""
    if count <= 0:
        raise ValueError("No eligible tickets")
    counter = 0
    limit = (1 << 256) - ((1 << 256) % count)
    while True:
        digest = hashlib.sha256(f"{seed}:{pool_hash}:{counter}".encode("utf-8")).digest()
        value = int.from_bytes(digest, "big")
        if value < limit:
            return value % count
        counter += 1


def result_hash(*, seed: str, pool_hash: str, ticket_number: int, prize_position: int) -> str:
    return sha256(f"{SELECTION_ALGORITHM}|{seed}|{pool_hash}|{ticket_number}|{prize_position}")
