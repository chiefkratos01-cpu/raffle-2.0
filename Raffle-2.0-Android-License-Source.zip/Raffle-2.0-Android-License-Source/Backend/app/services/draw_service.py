from datetime import datetime, timezone
import hashlib
import secrets

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.draw import Draw
from app.models.winner import Winner
from app.models.ticket import Ticket
from app.models.prize import Prize
from app.models.raffle import Raffle
from app.models.enums import DrawStatus, RaffleStatus, TicketStatus
from app.services.notification_service import notify
from app.realtime.events import emit_user_notification, emit_draw_result
from app.services.draw_proof import SELECTION_ALGORITHM, sha256, choose_index, result_hash


def now():
    return datetime.now(timezone.utc)


def _pool_hash(candidates: list[Ticket]) -> str:
    material = ",".join(str(t.number) for t in sorted(candidates, key=lambda item: item.number))
    return sha256(material)

def angle(index: int, total: int, seed: str) -> float:
    return ((index + 0.5) / total) * 360 + (int(seed[:16], 16) % 360)



def perform_draw(db: Session, raffle: Raffle, prize_position: int):
    raffle = db.scalar(select(Raffle).where(Raffle.id == raffle.id).with_for_update())
    if not raffle:
        raise ValueError("Raffle not found")
    if raffle.status not in (RaffleStatus.OPEN, RaffleStatus.LOW_TICKETS, RaffleStatus.SOLD_OUT, RaffleStatus.DRAW_SCHEDULED):
        raise ValueError("Raffle is not ready for a draw")

    prize = db.scalar(select(Prize).where(Prize.raffle_id == raffle.id, Prize.position == prize_position))
    if not prize:
        raise ValueError("Prize position does not exist")

    existing = db.scalar(select(Draw).where(Draw.raffle_id == raffle.id, Draw.prize_position == prize_position))
    if existing:
        if existing.status in (DrawStatus.DRAWING, DrawStatus.WINNER_SELECTED, DrawStatus.ANIMATION):
            raise ValueError("This prize position already has a draw in progress")
        raise ValueError("This prize position has already been drawn")

    completed_count = db.scalar(
        select(func.count(Draw.id)).where(Draw.raffle_id == raffle.id, Draw.status == DrawStatus.COMPLETED)
    ) or 0
    if completed_count >= raffle.winner_count:
        raise ValueError("All winners have already been drawn")

    q = select(Ticket).where(Ticket.raffle_id == raffle.id, Ticket.status == TicketStatus.PAID).order_by(Ticket.number)
    if not raffle.allow_multiple_wins:
        q = q.where(~Ticket.user_id.in_(select(Winner.user_id).where(Winner.raffle_id == raffle.id)))
    candidates = db.scalars(q).all()
    if not candidates:
        raise ValueError("No eligible paid tickets remain")

    # The seed is generated before selection. Its commitment and the eligible-pool
    # fingerprint make the final selection reproducible and auditable.
    seed = secrets.token_hex(32)
    commitment = sha256(seed)
    pool_hash = _pool_hash(candidates)
    selected = candidates[choose_index(seed, pool_hash, len(candidates))]
    proof_hash = result_hash(
        seed=seed,
        pool_hash=pool_hash,
        ticket_number=selected.number,
        prize_position=prize_position,
    )

    draw = Draw(
        raffle_id=raffle.id,
        status=DrawStatus.WINNER_SELECTED,
        prize_position=prize_position,
        winning_ticket_id=selected.id,
        animation_seed=seed,
        randomness_commitment=commitment,
        eligible_pool_hash=pool_hash,
        result_hash=proof_hash,
        eligible_count=len(candidates),
        selection_algorithm=SELECTION_ALGORITHM,
        started_at=now(),
    )
    db.add(draw)
    db.flush()

    winner = Winner(
        raffle_id=raffle.id,
        draw_id=draw.id,
        ticket_id=selected.id,
        user_id=selected.user_id,
        prize_position=prize_position,
        prize_description=prize.description or prize.title,
        verification_code=secrets.token_urlsafe(32),
    )
    db.add(winner)
    raffle.status = RaffleStatus.DRAWING
    draw.status = DrawStatus.ANIMATION

    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise ValueError("Another draw request for this prize was accepted first") from exc

    db.refresh(draw)
    db.refresh(winner)
    payload = {
        "type": "DRAW_RESULT",
        "draw_id": draw.id,
        "raffle_id": raffle.id,
        "prize_position": prize_position,
        "ticket_number": selected.number,
        "winning_ticket_id": selected.id,
        "winner_id": winner.id,
        "animation_seed": seed,
        "randomness_commitment": commitment,
        "eligible_pool_hash": pool_hash,
        "eligible_count": len(candidates),
        "selection_algorithm": SELECTION_ALGORITHM,
        "result_hash": proof_hash,
        "target_angle": angle(selected.number - 1, raffle.total_tickets, seed),
    }
    emit_draw_result(raffle.id, payload)

    notification = notify(
        db,
        selected.user_id,
        "¡Has ganado!",
        f"Has ganado el premio #{prize_position}: {winner.prize_description or ''}",
        "WINNER",
    )
    db.commit()
    db.refresh(notification)
    emit_user_notification(selected.user_id, {
        "id": notification.id,
        "title": notification.title,
        "message": notification.message,
        "kind": notification.kind,
        "is_read": notification.is_read,
        "created_at": notification.created_at.isoformat() if notification.created_at else None,
    })
    return draw, winner, payload


def finalize_draw(db: Session, draw: Draw):
    if draw.status != DrawStatus.ANIMATION:
        return draw
    raffle = db.scalar(select(Raffle).where(Raffle.id == draw.raffle_id).with_for_update())
    if not raffle:
        return draw

    draw.status = DrawStatus.COMPLETED
    draw.completed_at = now()
    db.flush()
    completed_count = db.scalar(
        select(func.count(Draw.id)).where(Draw.raffle_id == raffle.id, Draw.status == DrawStatus.COMPLETED)
    ) or 0
    raffle.status = RaffleStatus.COMPLETED if completed_count >= raffle.winner_count else RaffleStatus.OPEN
    db.commit()
    db.refresh(draw)
    return draw
