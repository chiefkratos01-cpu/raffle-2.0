from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.notification import Notification


def notify(db: Session, user_id: int, title: str, message: str, kind: str = "INFO") -> Notification:
    item = Notification(user_id=user_id, title=title, message=message, kind=kind)
    db.add(item)
    return item


def mine(db: Session, user_id: int):
    return db.scalars(
        select(Notification)
        .where(Notification.user_id == user_id)
        .order_by(Notification.created_at.desc(), Notification.id.desc())
        .limit(100)
    ).all()
