from datetime import datetime, timedelta, timezone
from uuid import uuid4
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload
from app.models.enums import RaffleStatus, ReservationStatus, TicketStatus, PaymentStatus
from app.models.raffle import Raffle
from app.models.ticket import Ticket
from app.models.reservation import Reservation
from app.models.payment import Payment
from app.models.ticket_allocation import TicketAllocation
from secrets import token_urlsafe
from app.services.notification_service import notify
from app.services.raffle_service import refresh_sales_status

ACTIVE_RESERVATION_STATUSES = (ReservationStatus.ACTIVE, ReservationStatus.PAYMENT_REVIEW)


def now():
    return datetime.now(timezone.utc)


def release_expired(db: Session, raffle_id: int | None = None, *, commit: bool = True):
    q = select(Reservation).where(
        Reservation.status == ReservationStatus.ACTIVE,
        Reservation.expires_at.is_not(None),
        Reservation.expires_at <= now(),
    )
    if raffle_id:
        q = q.where(Reservation.raffle_id == raffle_id)
    reservations = db.scalars(q.options(selectinload(Reservation.tickets))).all()
    released_count = 0
    released_at = now()
    for r in reservations:
        r.status = ReservationStatus.EXPIRED
        r.released_at = released_at
        r.release_reason = "Automatic reservation timeout"
        for ticket in r.tickets:
            if ticket.status == TicketStatus.RESERVED:
                db.add(TicketAllocation(
                    raffle_id=ticket.raffle_id,
                    reservation_id=r.id,
                    ticket_id=ticket.id,
                    user_id=ticket.user_id,
                    number=ticket.number,
                    verification_code=ticket.verification_code,
                    status=TicketStatus.RELEASED,
                    allocated_at=ticket.created_at,
                    released_at=released_at,
                    release_reason=r.release_reason,
                ))
                ticket.status = TicketStatus.RELEASED
                released_count += 1
    if reservations and commit:
        db.commit()
    elif reservations:
        db.flush()
    return released_count


def create_reservation(db: Session, raffle: Raffle, user_id: int, numbers: list[int], *, commit: bool = True) -> Reservation:
    release_expired(db, raffle.id, commit=False)
    # PostgreSQL serializes competing reservations for the same raffle.
    # SQLite still relies on the unique ticket constraint as the final guard.
    locked_raffle = db.scalar(select(Raffle).where(Raffle.id == raffle.id).with_for_update())
    if locked_raffle is None:
        raise ValueError("Raffle not found")
    raffle = locked_raffle
    if raffle.status not in (RaffleStatus.OPEN, RaffleStatus.LOW_TICKETS):
        raise ValueError("Raffle is not accepting reservations")
    numbers = sorted(set(numbers))
    if any(n < 1 or n > raffle.total_tickets for n in numbers):
        raise ValueError("One or more ticket numbers are outside the raffle range")
    if raffle.max_tickets_per_user:
        paid_or_reserved = db.scalar(select(func.count(Ticket.id)).where(Ticket.raffle_id == raffle.id, Ticket.user_id == user_id, Ticket.status.in_([TicketStatus.RESERVED, TicketStatus.PAID]))) or 0
        if paid_or_reserved + len(numbers) > raffle.max_tickets_per_user:
            raise ValueError("Maximum tickets per user exceeded")
    occupied = set(db.scalars(select(Ticket.number).where(Ticket.raffle_id == raffle.id, Ticket.number.in_(numbers), Ticket.status.in_([TicketStatus.RESERVED, TicketStatus.PAID]))).all())
    if occupied:
        raise ValueError(f"Ticket numbers unavailable: {', '.join(map(str, sorted(occupied)))}")
    # Released/cancelled ticket rows are historical allocations and cannot be reused
    # because (raffle_id, number) is intentionally unique. Remove only those stale
    # allocation rows immediately before creating the new reservation. The reservation
    # itself remains in history with its release reason.
    stale = db.scalars(
        select(Ticket).where(
            Ticket.raffle_id == raffle.id,
            Ticket.number.in_(numbers),
            Ticket.status.in_([TicketStatus.RELEASED, TicketStatus.CANCELLED]),
        )
    ).all()
    for ticket in stale:
        # Older allocation rows remain available in ticket_allocations, so the
        # public ticket row can be recycled without erasing allocation history.
        if not db.scalar(select(TicketAllocation.id).where(TicketAllocation.ticket_id == ticket.id)):
            db.add(TicketAllocation(
                raffle_id=ticket.raffle_id,
                reservation_id=ticket.reservation_id,
                ticket_id=ticket.id,
                user_id=ticket.user_id,
                number=ticket.number,
                verification_code=ticket.verification_code,
                status=ticket.status,
                allocated_at=ticket.created_at,
                released_at=ticket.cancelled_at or now(),
                release_reason="Historical ticket allocation",
            ))
        db.delete(ticket)
    db.flush()
    expires_at = None
    if raffle.auto_release_enabled:
        expires_at = now() + timedelta(minutes=raffle.reservation_minutes or 10)
    reservation = Reservation(code=f"R-{uuid4().hex[:10].upper()}", raffle_id=raffle.id, user_id=user_id, status=ReservationStatus.ACTIVE, expires_at=expires_at)
    db.add(reservation)
    db.flush()
    for number in numbers:
        db.add(Ticket(raffle_id=raffle.id, user_id=user_id, reservation_id=reservation.id, number=number, status=TicketStatus.RESERVED, verification_code=token_urlsafe(32)))
    db.add(Payment(raffle_id=raffle.id, reservation_id=reservation.id, amount=raffle.ticket_price * len(numbers), status=PaymentStatus.PENDING))
    try:
        if commit:
            db.commit()
        else:
            db.flush()
    except IntegrityError:
        db.rollback()
        raise ValueError("One or more selected tickets were taken at the same time. Please try again.")
    return db.scalar(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment)).where(Reservation.id == reservation.id))


def submit_payment(db: Session, reservation: Reservation, data, *, commit: bool = True):
    if reservation.status not in (ReservationStatus.ACTIVE, ReservationStatus.PAYMENT_REVIEW):
        raise ValueError("Reservation is no longer awaiting payment")
    if reservation.status == ReservationStatus.ACTIVE and reservation.expires_at and reservation.expires_at <= now():
        release_expired(db, reservation.raffle_id, commit=False)
        if commit:
            db.commit()
        raise ValueError("Reservation has expired")
    reservation.status = ReservationStatus.PAYMENT_REVIEW
    payment = reservation.payment
    payment.method = data.method
    payment.reference = data.reference
    payment.notes = data.notes
    if commit:
        db.commit()
    else:
        db.flush()
    return reservation


def decide_payment(db: Session, reservation: Reservation, admin_id: int, data, confirm: bool, *, commit: bool = True):
    if reservation.status not in (ReservationStatus.ACTIVE, ReservationStatus.PAYMENT_REVIEW):
        raise ValueError("Reservation is not awaiting a payment decision")
    # A reservation that is still ACTIVE may expire according to the raffle policy.
    # PAYMENT_REVIEW is deliberately exempt: the administrator may be offline while
    # reviewing a proof, so the original timeout must never revoke that review.
    if reservation.status == ReservationStatus.ACTIVE and reservation.expires_at and reservation.expires_at <= now():
        release_expired(db, reservation.raffle_id, commit=False)
        raise ValueError("Reservation has expired and can no longer be confirmed")
    payment = reservation.payment
    if confirm:
        payment.status = PaymentStatus.CONFIRMED
        payment.method = data.method or payment.method
        payment.reference = data.reference or payment.reference
        payment.notes = data.notes or payment.notes
        payment.confirmed_by_admin_id = admin_id
        payment.confirmed_at = now()
        reservation.status = ReservationStatus.CONFIRMED
        for ticket in reservation.tickets:
            if ticket.status == TicketStatus.RESERVED:
                ticket.status = TicketStatus.PAID
                ticket.paid_at = now()
        reservation.expires_at = None
        notify(db, reservation.user_id, "Pago confirmado", f"Tu reserva {reservation.code} ha sido confirmada.", "PAYMENT_CONFIRMED")
        reservation.raffle.tickets_sold += len(reservation.tickets)
        refresh_sales_status(reservation.raffle)
    else:
        payment.status = PaymentStatus.REJECTED
        payment.rejection_reason = data.rejection_reason or "Payment not verified"
        reservation.status = ReservationStatus.RELEASED
        reservation.released_at = now()
        reservation.release_reason = payment.rejection_reason
        released_at = now()
        for ticket in reservation.tickets:
            if ticket.status == TicketStatus.RESERVED:
                db.add(TicketAllocation(
                    raffle_id=ticket.raffle_id, reservation_id=reservation.id, ticket_id=ticket.id,
                    user_id=ticket.user_id, number=ticket.number, verification_code=ticket.verification_code,
                    status=TicketStatus.RELEASED, allocated_at=ticket.created_at,
                    released_at=released_at, release_reason=reservation.release_reason,
                ))
                ticket.status = TicketStatus.RELEASED
        reservation.expires_at = None
    if commit:
        db.commit()
    else:
        db.flush()
    return reservation
