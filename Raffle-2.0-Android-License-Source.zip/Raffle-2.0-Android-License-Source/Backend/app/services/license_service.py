import base64
import json
import secrets
from datetime import datetime, timedelta, timezone

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.license import License, LicenseType

LICENSE_STATUSES = {"ACTIVE", "SUSPENDED", "REVOKED"}
STANDARD_LIMITS = (
    "max_active_raffles",
    "max_tickets_per_raffle",
    "max_team_accounts",
    "max_organizers",
)
ACTIVE_RAFFLE_STATUSES = {"OPEN", "LOW_TICKETS", "SOLD_OUT", "DRAW_SCHEDULED", "DRAWING"}


def _b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _b64e(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _parse_date(value: str | None, field: str) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"Campo de licencia no válido: {field}")
    try:
        return _aware(datetime.fromisoformat(value.replace("Z", "+00:00")))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Fecha de licencia no válida: {field}") from exc


def _validate_v2_claims(payload: dict) -> None:
    required = {
        "license_id", "license_type", "organization_id", "issued_at", "starts_at",
        "expires_at", "license_status", "schema_version", "features", *STANDARD_LIMITS,
    }
    if not required.issubset(payload):
        raise ValueError("Faltan datos obligatorios en la licencia")
    if payload.get("license_type") not in {"TRIAL", "COMMERCIAL"}:
        raise ValueError("Tipo de licencia no válido")
    if not isinstance(payload.get("license_id"), str) or not payload["license_id"].strip():
        raise ValueError("Identificador de licencia no válido")
    if not isinstance(payload.get("organization_id"), str) or not payload["organization_id"].strip():
        raise ValueError("La licencia debe incluir la organización")
    if payload.get("license_status") not in LICENSE_STATUSES:
        raise ValueError("Estado de licencia no válido")
    if not isinstance(payload.get("features"), dict) or not isinstance(payload.get("limits", {}), dict):
        raise ValueError("Límites o capacidades de licencia no válidos")
    for key in STANDARD_LIMITS:
        value = payload.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"Límite no válido: {key}")
    for key, value in payload.get("limits", {}).items():
        if not isinstance(key, str) or not key.strip():
            raise ValueError("Nombre de límite adicional no válido")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
            raise ValueError(f"Límite adicional no válido: {key}")
    issued = _parse_date(payload.get("issued_at"), "issued_at")
    starts = _parse_date(payload.get("starts_at"), "starts_at")
    expires = _parse_date(payload.get("expires_at"), "expires_at")
    if issued is None or starts is None:
        raise ValueError("La licencia requiere fechas de emisión e inicio")
    if expires is not None and expires <= starts:
        raise ValueError("El vencimiento debe ser posterior al inicio")


def verify_license_token(token: str) -> dict:
    parts = token.strip().split(".")
    if len(parts) != 2:
        raise ValueError("Formato de licencia no válido")
    payload_part, signature_part = parts
    public_key_b64 = settings.license_public_key.strip()
    if not public_key_b64:
        raise ValueError("La clave pública de licencia no está configurada")
    try:
        public_key = Ed25519PublicKey.from_public_bytes(_b64d(public_key_b64))
        public_key.verify(_b64d(signature_part), payload_part.encode())
        payload = json.loads(_b64d(payload_part).decode())
    except (ValueError, TypeError, KeyError, UnicodeDecodeError, json.JSONDecodeError, InvalidSignature) as exc:
        raise ValueError("Firma de licencia no válida") from exc
    if not isinstance(payload, dict) or payload.get("product") != settings.license_product:
        raise ValueError("La licencia no pertenece a este producto")
    if payload.get("license_id") is None or payload.get("license_type") not in {item.value for item in LicenseType}:
        raise ValueError("Datos de licencia incompletos")

    schema_version = payload.get("schema_version", 1)
    if isinstance(schema_version, bool) or not isinstance(schema_version, int) or schema_version not in {1, 2}:
        raise ValueError("Versión de licencia no compatible")
    if schema_version == 2:
        _validate_v2_claims(payload)

    expires = _parse_date(payload.get("expires_at"), "expires_at")
    starts = _parse_date(payload.get("starts_at"), "starts_at") if payload.get("starts_at") else None
    now = datetime.now(timezone.utc)
    if starts and starts > now:
        raise ValueError("La licencia todavía no está vigente")
    if expires and expires <= now:
        raise ValueError("La licencia ha expirado")
    return payload


def _payload_limits(payload: dict, license_type: str) -> dict:
    limits = {key: payload.get(key) for key in STANDARD_LIMITS}
    limits.update(payload.get("limits") or {})
    if payload.get("schema_version", 1) == 1 and license_type == "TRIAL":
        defaults = {
            "max_active_raffles": settings.license_trial_max_active_raffles,
            "max_tickets_per_raffle": settings.license_trial_max_tickets_per_raffle,
            "max_team_accounts": settings.license_trial_max_team_accounts,
            "max_organizers": settings.license_trial_max_organizers,
        }
        for key, default in defaults.items():
            if limits.get(key) is None:
                limits[key] = default
    return limits


def activate_license(db: Session, token: str, installation_id: str | None = None) -> License:
    payload = verify_license_token(token)
    installation_id = installation_id or secrets.token_urlsafe(24)
    bound = payload.get("installation_id")
    if bound and bound != installation_id:
        raise ValueError("La licencia está vinculada a otra instalación")

    existing = db.scalar(select(License).where(License.license_key == token))
    external_id = str(payload.get("license_id"))
    if not existing:
        existing = db.scalar(select(License).where(License.external_license_id == external_id))
        if existing and existing.license_key != token:
            raise ValueError("Ya existe otra clave con este identificador de licencia")

    now = datetime.now(timezone.utc)
    if existing:
        if existing.installation_id and existing.installation_id != installation_id:
            raise ValueError("La licencia está vinculada a otra instalación")
        if existing.status == "ACTIVE" and payload.get("license_status") == "ACTIVE":
            existing.activated_at = existing.activated_at or now
            existing.installation_id = installation_id
            existing.activation_count = (existing.activation_count or 0) + 1
            existing.last_checked_at = now
        return existing

    license_row = License(
        license_key=token,
        external_license_id=external_id,
        organization_id=payload.get("organization_id"),
        schema_version=payload.get("schema_version", 1),
        product=payload["product"],
        license_type=LicenseType(payload["license_type"]),
        issued_at=_parse_date(payload.get("issued_at"), "issued_at") or now,
        activated_at=now,
        expires_at=_parse_date(payload.get("expires_at"), "expires_at"),
        installation_id=installation_id,
        status=payload.get("license_status", "ACTIVE"),
        metadata_json=json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        activation_count=1,
        last_checked_at=now,
    )
    db.add(license_row)
    db.flush()
    return license_row


def ensure_development_trial(db: Session) -> License | None:
    if settings.environment.lower() != "development":
        return current_license(db)
    row = current_license(db)
    if row:
        return row
    now = datetime.now(timezone.utc)
    payload = {
        "schema_version": 2,
        "license_id": "DEV-TRIAL",
        "product": settings.license_product,
        "license_type": "TRIAL",
        "organization_id": "DEVELOPMENT",
        "issued_at": now.isoformat().replace("+00:00", "Z"),
        "starts_at": now.isoformat().replace("+00:00", "Z"),
        "expires_at": (now + timedelta(days=settings.development_trial_days)).isoformat().replace("+00:00", "Z"),
        "license_status": "ACTIVE",
        "max_active_raffles": settings.license_trial_max_active_raffles,
        "max_tickets_per_raffle": settings.license_trial_max_tickets_per_raffle,
        "max_team_accounts": settings.license_trial_max_team_accounts,
        "max_organizers": settings.license_trial_max_organizers,
        "limits": {},
        "features": {},
    }
    row = License(
        license_key="DEV-TRIAL",
        external_license_id="DEV-TRIAL",
        organization_id="DEVELOPMENT",
        schema_version=2,
        product=settings.license_product,
        license_type=LicenseType.TRIAL,
        issued_at=now,
        activated_at=now,
        expires_at=now + timedelta(days=settings.development_trial_days),
        installation_id="development",
        status="ACTIVE",
        metadata_json=json.dumps(payload, separators=(",", ":")),
        activation_count=1,
        last_checked_at=now,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def current_license(db: Session) -> License | None:
    return db.scalar(
        select(License)
        .where(
            License.product == settings.license_product,
            License.status.in_(["ACTIVE", "SUSPENDED", "REVOKED"]),
        )
        .order_by(License.id.desc())
        .limit(1)
    )


def lock_current_license_for_update(db: Session) -> dict:
    """Serialize license-governed writes on the current license row when supported by the DB."""
    db.scalar(
        select(License)
        .where(
            License.product == settings.license_product,
            License.status.in_(["ACTIVE", "SUSPENDED", "REVOKED"]),
        )
        .order_by(License.id.desc())
        .limit(1)
        .execution_options(populate_existing=True)
        .with_for_update()
    )
    return license_public_status(db)


def license_public_status(db: Session) -> dict:
    row = current_license(db)
    check_interval_seconds = settings.license_check_interval_hours * 3600
    if not row:
        if settings.demo_mode:
            return {
                "active": True, "limited": False, "mode": "DEMO", "license_status": "ACTIVE",
                "license_type": "DEMO", "days_remaining": None, "expires_at": None,
                "activated_at": None, "installation_id": None, "license_id": None,
                "organization_id": None, "schema_version": 1, "limits": {}, "features": {},
                "last_verified_at": datetime.now(timezone.utc), "check_interval_seconds": check_interval_seconds,
                "offline_grace_hours": settings.license_offline_grace_hours,
                "suspended_policy": settings.license_suspended_policy,
            }
        return {
            "active": False, "limited": True, "mode": "UNLICENSED", "license_status": "UNLICENSED",
            "license_type": None, "days_remaining": None, "expires_at": None,
            "activated_at": None, "installation_id": None, "license_id": None,
            "organization_id": None, "schema_version": None, "limits": {}, "features": {},
            "last_verified_at": None, "check_interval_seconds": check_interval_seconds,
            "offline_grace_hours": settings.license_offline_grace_hours,
            "suspended_policy": settings.license_suspended_policy,
        }

    try:
        payload = json.loads(row.metadata_json or "{}")
    except json.JSONDecodeError:
        payload = {}
    now = datetime.now(timezone.utc)
    expires = _aware(row.expires_at)
    starts = _parse_date(payload.get("starts_at"), "starts_at") if payload.get("starts_at") else None
    status = row.status or payload.get("license_status", "ACTIVE")
    if status == "REVOKED":
        mode = "REVOKED"
        effective_status = "REVOKED"
    elif expires and expires <= now:
        mode = "EXPIRED"
        effective_status = "EXPIRED"
    elif starts and starts > now:
        mode = "NOT_STARTED"
        effective_status = "NOT_STARTED"
    elif status == "SUSPENDED":
        mode = "SUSPENDED"
        effective_status = "SUSPENDED"
    elif status == "ACTIVE":
        mode = row.license_type.value
        effective_status = "ACTIVE"
    else:
        mode = status
        effective_status = status
    is_active = effective_status == "ACTIVE"
    days = max(0, (expires - now).days) if expires and is_active else (0 if expires and effective_status == "EXPIRED" else None)
    return {
        "active": is_active,
        "limited": not is_active,
        "mode": mode,
        "license_status": effective_status,
        "license_type": row.license_type.value,
        "days_remaining": days,
        "expires_at": expires,
        "starts_at": starts,
        "issued_at": _aware(row.issued_at),
        "activated_at": _aware(row.activated_at),
        "installation_id": row.installation_id,
        "license_id": row.external_license_id or row.id,
        "organization_id": row.organization_id or payload.get("organization_id"),
        "schema_version": row.schema_version or payload.get("schema_version", 1),
        "limits": _payload_limits(payload, row.license_type.value),
        "features": payload.get("features") or {},
        "last_verified_at": now,
        "check_interval_seconds": check_interval_seconds,
        "offline_grace_hours": settings.license_offline_grace_hours,
        "suspended_policy": settings.license_suspended_policy,
    }


def check_license_limit(state: dict, limit_name: str, current_usage: int, requested: int = 1) -> None:
    limit = (state.get("limits") or {}).get(limit_name)
    if limit is not None and current_usage + requested > limit:
        raise ValueError(f"El límite de la licencia para {limit_name} es {limit}.")


def may_complete_existing_raffle(state: dict, raffle_status: str) -> bool:
    if state.get("active"):
        return True
    if raffle_status not in ACTIVE_RAFFLE_STATUSES:
        return False
    if state.get("mode") == "EXPIRED":
        return True
    return state.get("mode") == "SUSPENDED" and state.get("suspended_policy") == "ALLOW_EXISTING_COMPLETION"


def team_account_usage(db: Session) -> int:
    from app.models.admin import Admin
    from app.models.organizer_request import OrganizerRequest

    organizer_admin_ids = select(OrganizerRequest.admin_id).where(
        OrganizerRequest.status == "APPROVED",
        OrganizerRequest.admin_id.is_not(None),
    )
    return int(db.scalar(select(func.count(Admin.id)).where(~Admin.id.in_(organizer_admin_ids))) or 0)


def organizer_usage(db: Session) -> int:
    from app.models.organizer_request import OrganizerRequest

    return int(db.scalar(select(func.count(OrganizerRequest.id)).where(OrganizerRequest.status == "APPROVED")) or 0)
