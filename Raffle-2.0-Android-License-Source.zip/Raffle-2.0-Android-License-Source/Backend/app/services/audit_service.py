from __future__ import annotations
from typing import Any
from sqlalchemy.orm import Session
from app.models.audit import AuditLog


def record_audit(
    db: Session,
    *,
    actor_admin_id: int | None,
    action: str,
    entity_type: str,
    entity_id: str | int | None = None,
    old_value: dict[str, Any] | None = None,
    new_value: dict[str, Any] | None = None,
    ip_address: str | None = None,
    details: str | None = None,
    commit: bool = False,
) -> AuditLog:
    row = AuditLog(
        actor_admin_id=actor_admin_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        old_value=old_value,
        new_value=new_value,
        ip_address=ip_address,
        details=details,
    )
    db.add(row)
    if commit:
        db.commit()
    return row
