from decimal import Decimal
from sqlalchemy import ForeignKey, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base


class Prize(Base):
    __tablename__ = "prizes"
    __table_args__ = (UniqueConstraint("raffle_id", "position", name="uq_prize_position"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    raffle_id: Mapped[int] = mapped_column(ForeignKey("raffles.id", ondelete="CASCADE"), index=True)
    position: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    image: Mapped[str | None] = mapped_column(String(500))
    value: Mapped[Decimal | None] = mapped_column(Numeric(12, 2))

    raffle = relationship("Raffle", back_populates="prizes")
