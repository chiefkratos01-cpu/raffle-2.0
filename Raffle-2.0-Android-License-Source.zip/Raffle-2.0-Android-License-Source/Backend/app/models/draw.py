from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base
from app.models.enums import DrawStatus


def utcnow():
    return datetime.now(timezone.utc)


class Draw(Base):
    __tablename__ = "draws"
    __table_args__ = (UniqueConstraint("raffle_id", "prize_position", name="uq_draw_raffle_prize_position"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    raffle_id: Mapped[int] = mapped_column(ForeignKey("raffles.id"), index=True)
    status: Mapped[DrawStatus] = mapped_column(SAEnum(DrawStatus), default=DrawStatus.IDLE, nullable=False, index=True)
    prize_position: Mapped[int] = mapped_column(Integer)
    winning_ticket_id: Mapped[int | None] = mapped_column(ForeignKey("tickets.id"))
    animation_seed: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    error_message: Mapped[str | None] = mapped_column(String(500))
    randomness_commitment: Mapped[str | None] = mapped_column(String(64), index=True)
    eligible_pool_hash: Mapped[str | None] = mapped_column(String(64))
    result_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    eligible_count: Mapped[int | None] = mapped_column(Integer)
    selection_algorithm: Mapped[str | None] = mapped_column(String(100))

    raffle = relationship("Raffle", back_populates="draws")
    winner = relationship("Winner", back_populates="draw", uselist=False)
