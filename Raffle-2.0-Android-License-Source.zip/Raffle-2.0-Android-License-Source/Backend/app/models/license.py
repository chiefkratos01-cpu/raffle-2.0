from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, String, Text, Integer
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
from enum import Enum


class LicenseType(str, Enum):
    DEMO = "DEMO"
    TRIAL = "TRIAL"
    COMMERCIAL = "COMMERCIAL"


def utcnow():
    return datetime.now(timezone.utc)


class License(Base):
    __tablename__ = "licenses"

    id: Mapped[int] = mapped_column(primary_key=True)
    license_key: Mapped[str | None] = mapped_column(String(512), unique=True)
    external_license_id: Mapped[str | None] = mapped_column(String(128), unique=True, index=True)
    organization_id: Mapped[str | None] = mapped_column(String(128), index=True)
    schema_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    product: Mapped[str] = mapped_column(String(80), default="raffle")
    license_type: Mapped[LicenseType] = mapped_column(SAEnum(LicenseType), default=LicenseType.DEMO, nullable=False)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    activated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    installation_id: Mapped[str | None] = mapped_column(String(128), unique=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", nullable=False)
    metadata_json: Mapped[str | None] = mapped_column(Text)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    activation_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
