from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base
from app.models.enums import TicketStatus

def utcnow(): return datetime.now(timezone.utc)
class Ticket(Base):
    __tablename__="tickets"; __table_args__=(UniqueConstraint("raffle_id","number",name="uq_ticket_raffle_number"),)
    id:Mapped[int]=mapped_column(primary_key=True); raffle_id:Mapped[int]=mapped_column(ForeignKey("raffles.id"),index=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"),index=True); reservation_id:Mapped[int|None]=mapped_column(ForeignKey("reservations.id"),index=True)
    number:Mapped[int]=mapped_column(Integer); status:Mapped[TicketStatus]=mapped_column(SAEnum(TicketStatus),default=TicketStatus.RESERVED,nullable=False,index=True)
    verification_code:Mapped[str]=mapped_column(String(64),unique=True,index=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False); paid_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True)); cancelled_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    raffle=relationship("Raffle",back_populates="tickets"); user=relationship("User",back_populates="tickets"); reservation=relationship("Reservation",back_populates="tickets"); winners=relationship("Winner",back_populates="ticket")
