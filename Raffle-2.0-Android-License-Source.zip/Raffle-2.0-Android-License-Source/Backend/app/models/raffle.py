from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import Boolean, DateTime, Enum as SAEnum, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base
from app.models.enums import RaffleStatus


def utcnow():
    return datetime.now(timezone.utc)


class Raffle(Base):
    __tablename__ = "raffles"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(220), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text)
    image: Mapped[str | None] = mapped_column(String(500))
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    total_tickets: Mapped[int] = mapped_column(Integer)
    tickets_sold: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    ticket_price: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    currency: Mapped[str] = mapped_column(String(10), default="CUP")
    status: Mapped[RaffleStatus] = mapped_column(SAEnum(RaffleStatus), default=RaffleStatus.DRAFT, nullable=False, index=True)
    draw_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    winner_count: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    max_tickets_per_user: Mapped[int | None] = mapped_column(Integer)
    allow_multiple_wins: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    auto_release_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    reservation_minutes: Mapped[int | None] = mapped_column(Integer)
    low_ticket_threshold: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
    rules: Mapped[str | None] = mapped_column(Text)
    payment_instructions: Mapped[str | None] = mapped_column(Text)
    organizer_name: Mapped[str | None] = mapped_column(String(160))
    organizer_whatsapp: Mapped[str | None] = mapped_column(String(40))
    organizer_phone: Mapped[str | None] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)
    prizes = relationship("Prize", back_populates="raffle", cascade="all, delete-orphan")
    tickets = relationship("Ticket", back_populates="raffle")
    reservations = relationship("Reservation", back_populates="raffle")
    payments = relationship("Payment", back_populates="raffle")
    draws = relationship("Draw", back_populates="raffle")
