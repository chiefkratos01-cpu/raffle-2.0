from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
from app.models.enums import TicketStatus


def utcnow():
    return datetime.now(timezone.utc)


class TicketAllocation(Base):
    """Immutable audit trail for every allocation of a raffle number."""
    __tablename__ = "ticket_allocations"

    id: Mapped[int] = mapped_column(primary_key=True)
    raffle_id: Mapped[int] = mapped_column(ForeignKey("raffles.id"), index=True)
    reservation_id: Mapped[int] = mapped_column(ForeignKey("reservations.id"), index=True)
    ticket_id: Mapped[int | None] = mapped_column(ForeignKey("tickets.id", ondelete="SET NULL"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    number: Mapped[int] = mapped_column(Integer, index=True)
    verification_code: Mapped[str | None] = mapped_column(String(64), index=True)
    status: Mapped[TicketStatus] = mapped_column(SAEnum(TicketStatus), nullable=False)
    allocated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    release_reason: Mapped[str | None] = mapped_column(String(255))
