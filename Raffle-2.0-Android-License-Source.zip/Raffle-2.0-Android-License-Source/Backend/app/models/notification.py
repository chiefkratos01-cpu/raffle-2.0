from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base

def utcnow(): return datetime.now(timezone.utc)
class Notification(Base):
    __tablename__="notifications"
    id:Mapped[int]=mapped_column(primary_key=True); user_id:Mapped[int]=mapped_column(ForeignKey("users.id",ondelete="CASCADE"),index=True)
    title:Mapped[str]=mapped_column(String(160)); message:Mapped[str]=mapped_column(Text); kind:Mapped[str]=mapped_column(String(40),default="INFO")
    is_read:Mapped[bool]=mapped_column(Boolean,default=False,nullable=False,index=True); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False,index=True)
