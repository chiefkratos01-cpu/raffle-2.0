import re
from fastapi import HTTPException

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
PHONE_RE = re.compile(r"^\+?[0-9][0-9 ()\-]{6,19}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,80}$")

def validate_email(value: str) -> str:
    value = value.strip().lower()
    if len(value) > 255 or not EMAIL_RE.fullmatch(value):
        raise HTTPException(422, "Introduce un correo electrónico válido.")
    return value

def validate_phone(value: str) -> str:
    value = value.strip()
    compact = re.sub(r"[ ()-]", "", value)
    if not PHONE_RE.fullmatch(value) or len(compact.lstrip("+")) < 7:
        raise HTTPException(422, "Introduce un número de teléfono válido.")
    return value

def validate_person_name(value: str, label: str = "Nombre") -> str:
    value = " ".join(value.strip().split())
    if len(value) < 2 or len(value) > 160 or any(ord(ch) < 32 for ch in value):
        raise HTTPException(422, f"{label} no es válido.")
    return value

def validate_username(value: str) -> str:
    value = value.strip()
    if not USERNAME_RE.fullmatch(value):
        raise HTTPException(422, "El nombre de acceso solo puede usar letras, números, punto, guion y guion bajo.")
    return value
