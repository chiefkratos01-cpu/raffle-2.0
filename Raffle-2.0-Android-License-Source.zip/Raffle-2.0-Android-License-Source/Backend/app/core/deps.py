from collections.abc import Iterable
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.admin import Admin
from app.models.enums import AdminRole
from app.models.user import User
from app.models.auth_session import AuthSession
from datetime import datetime, timedelta, timezone

bearer = HTTPBearer(auto_error=False)


def _claims(credentials: HTTPAuthorizationCredentials | None):
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    try:
        return decode_access_token(credentials.credentials)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")


def _active_session(claims: dict, db: Session) -> AuthSession:
    try:
        session_id = int(claims["sid"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid session")
    session = db.get(AuthSession, session_id)
    now = datetime.now(timezone.utc)
    if not session or session.revoked_at or session.subject_type != claims.get("role"):
        raise HTTPException(status_code=401, detail="Session revoked or expired")
    expires_at = session.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at <= now:
        raise HTTPException(status_code=401, detail="Session revoked or expired")
    try:
        subject_id = int(claims["sub"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid session subject")
    if session.subject_id != subject_id:
        raise HTTPException(status_code=401, detail="Invalid session subject")
    last_used_at = session.last_used_at
    if last_used_at is not None and last_used_at.tzinfo is None:
        last_used_at = last_used_at.replace(tzinfo=timezone.utc)
    if last_used_at is None or last_used_at <= now - timedelta(minutes=5):
        session.last_used_at = now
        db.flush()
    return session


def get_current_session(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> AuthSession:
    claims = _claims(credentials)
    return _active_session(claims, db)

def get_current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> User:
    claims = _claims(credentials)
    session = _active_session(claims, db)
    if claims.get("role") != "USER":
        raise HTTPException(status_code=403, detail="User account required")
    user = db.get(User, int(claims["sub"]))
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Inactive or missing user")
    return user


def get_current_admin(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> Admin:
    claims = _claims(credentials)
    session = _active_session(claims, db)
    if claims.get("role") != "ADMIN":
        raise HTTPException(status_code=403, detail="Administrator account required")
    try:
        admin_id = int(claims["sub"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid administrator token")
    admin = db.get(Admin, admin_id)
    if not admin or not admin.is_active:
        raise HTTPException(status_code=401, detail="Inactive or missing administrator")
    return admin


def require_admin_roles(*allowed: AdminRole):
    allowed_set = set(allowed)

    def dependency(admin: Admin = Depends(get_current_admin)) -> Admin:
        if admin.role not in allowed_set and admin.role != AdminRole.SUPER_ADMIN:
            raise HTTPException(status_code=403, detail="Insufficient administrator permissions")
        return admin

    return dependency


ROLE_PERMISSIONS: dict[AdminRole, set[str]] = {
    AdminRole.SUPER_ADMIN: {"*"},
    AdminRole.ADMIN: {"dashboard:read", "raffle:write", "draw:write", "draw:read", "reservation:read", "customer:read", "audit:read", "license:read", "team:read", "team:manage"},
    AdminRole.OPERATOR: {"dashboard:read", "raffle:read", "reservation:read", "reservation:write", "draw:write", "customer:read"},
    AdminRole.FINANCE: {"dashboard:read", "reservation:read", "payment:write", "customer:read"},
    AdminRole.VIEWER: {"dashboard:read", "raffle:read", "draw:read", "reservation:read", "customer:read", "audit:read", "license:read"},
}


def require_permission(permission: str):
    def dependency(admin: Admin = Depends(get_current_admin)) -> Admin:
        permissions = ROLE_PERMISSIONS.get(admin.role, set())
        if "*" not in permissions and permission not in permissions:
            raise HTTPException(status_code=403, detail=f"Permission required: {permission}")
        return admin
    return dependency


def require_valid_license(db: Session = Depends(get_db)):
    """Require demo mode or a current, non-expired license for new production work."""
    from app.services.license_service import license_public_status
    state = license_public_status(db)
    if not state["active"]:
        raise HTTPException(status_code=402, detail="Licencia requerida. Activa o renueva tu licencia desde Administración → Licencia.")
    return state



def require_production_license(db: Session = Depends(get_db)):
    """Require an actual TRIAL or COMMERCIAL license for real raffle operations."""
    from app.services.license_service import license_public_status
    state = license_public_status(db)
    if state["mode"] not in {"TRIAL", "COMMERCIAL"} or not state["active"]:
        raise HTTPException(status_code=402, detail="Licencia requerida. Activa una licencia o utiliza el periodo de prueba desde Administración → Licencia.")
    return state

def require_license_for_existing_raffle(db: Session = Depends(get_db)):
    """Return license state; routes may allow an existing raffle to finish after expiry."""
    from app.services.license_service import license_public_status
    state = license_public_status(db)
    if state["mode"] == "SUSPENDED" and state.get("suspended_policy") == "READ_ONLY":
        raise HTTPException(status_code=423, detail="La licencia está suspendida. La información existente permanece disponible en modo de solo lectura.")
    return state
