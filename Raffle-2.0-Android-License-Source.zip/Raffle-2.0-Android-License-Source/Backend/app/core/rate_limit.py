from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from threading import Lock
from time import monotonic


@dataclass(frozen=True)
class RateLimitRule:
    limit: int
    window_seconds: int


class InMemoryRateLimiter:
    """Small process-local sliding-window limiter for abuse protection.

    It intentionally has no external dependency. For multi-worker production
    deployments, replace this store with Redis or another shared limiter.
    """

    def __init__(self) -> None:
        self._events: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def check(self, key: str, rule: RateLimitRule) -> tuple[bool, int]:
        now = monotonic()
        cutoff = now - rule.window_seconds
        with self._lock:
            events = self._events[key]
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= rule.limit:
                retry_after = max(1, int(events[0] + rule.window_seconds - now + 0.999))
                return False, retry_after
            events.append(now)
            return True, 0

    def cleanup(self, max_keys: int = 5000) -> None:
        if len(self._events) <= max_keys:
            return
        now = monotonic()
        with self._lock:
            stale = [key for key, events in self._events.items() if not events or events[-1] < now - 3600]
            for key in stale:
                self._events.pop(key, None)


limiter = InMemoryRateLimiter()

RULES = {
    "auth_login": RateLimitRule(10, 300),
    "auth_register": RateLimitRule(5, 900),
    "auth_refresh": RateLimitRule(30, 300),
    "draw": RateLimitRule(10, 60),
    "reservation": RateLimitRule(30, 60),
    "verification": RateLimitRule(60, 60),
    "default": RateLimitRule(180, 60),
}


def rule_for(path: str, method: str) -> RateLimitRule:
    if path == "/api/v1/auth/login":
        return RULES["auth_login"]
    if path == "/api/v1/auth/register":
        return RULES["auth_register"]
    if path == "/api/v1/auth/refresh":
        return RULES["auth_refresh"]
    if path.startswith("/api/v1/draws/") and method == "POST":
        return RULES["draw"]
    if path.startswith("/api/v1/reservations") and method in {"POST", "PUT", "PATCH", "DELETE"}:
        return RULES["reservation"]
    if path.startswith("/api/v1/draws/verify/"):
        return RULES["verification"]
    return RULES["default"]
