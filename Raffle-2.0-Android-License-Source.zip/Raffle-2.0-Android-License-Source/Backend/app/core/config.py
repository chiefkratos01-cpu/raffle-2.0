from functools import lru_cache
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Raffle"
    app_version: str = "2.0.0-rc.1"
    environment: str = "development"
    debug: bool = True
    database_url: str = "sqlite:///./raffle.db"
    jwt_secret_key: str = "CHANGE_ME_IN_ENV"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 30
    refresh_token_days: int = 30
    cors_origins: str = "http://localhost:3000"
    docs_enabled: bool = True
    demo_mode: bool = True
    organizer_name: str = "Organizador"
    organizer_whatsapp: str = ""
    organizer_phone: str = ""
    demo_admin_username: str = "admin"
    demo_admin_password: str = "CHANGE_ME_ADMIN_PASSWORD"
    development_trial_days: int = 30
    timezone: str = "America/Havana"
    license_product: str = "raffle"
    license_public_key: str = ""
    license_trial_max_active_raffles: int = 3
    license_trial_max_tickets_per_raffle: int = 100
    license_trial_max_team_accounts: int = 2
    license_trial_max_organizers: int = 1
    license_check_interval_hours: int = 24
    license_offline_grace_hours: int | None = None
    license_suspended_policy: str = "READ_ONLY"
    rate_limit_enabled: bool = True
    media_dir: str = "./media"
    max_image_upload_bytes: int = 5 * 1024 * 1024

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


    @model_validator(mode="after")
    def validate_security(self):
        if self.environment.lower() == "production":
            if self.debug:
                raise ValueError("DEBUG must be false in production")
            if self.jwt_secret_key in {"CHANGE_ME_IN_ENV", "", "secret", "changeme"} or len(self.jwt_secret_key) < 32:
                raise ValueError("JWT_SECRET_KEY must be a strong secret of at least 32 characters in production")
            if self.demo_mode:
                raise ValueError("DEMO_MODE must be false in production")
            if self.docs_enabled:
                raise ValueError("DOCS_ENABLED must be false in production unless explicitly protected")
            if not self.cors_origin_list or "*" in self.cors_origin_list:
                raise ValueError("CORS_ORIGINS must contain explicit trusted origins in production")
            if not self.rate_limit_enabled:
                raise ValueError("RATE_LIMIT_ENABLED must be true in production")
            if self.demo_admin_password in {"CHANGE_ME_ADMIN_PASSWORD", "", "change-this-password"}:
                raise ValueError("DEMO_ADMIN_PASSWORD must be replaced in production")
            if not self.license_public_key.strip():
                raise ValueError("LICENSE_PUBLIC_KEY is required in production")
            if self.license_offline_grace_hours is None:
                raise ValueError("LICENSE_OFFLINE_GRACE_HOURS must be configured in production")
        if self.license_check_interval_hours < 1:
            raise ValueError("LICENSE_CHECK_INTERVAL_HOURS must be at least 1")
        if self.license_offline_grace_hours is not None and self.license_offline_grace_hours < 0:
            raise ValueError("LICENSE_OFFLINE_GRACE_HOURS cannot be negative")
        if self.license_suspended_policy not in {"READ_ONLY", "ALLOW_EXISTING_COMPLETION"}:
            raise ValueError("LICENSE_SUSPENDED_POLICY must be READ_ONLY or ALLOW_EXISTING_COMPLETION")
        if min(self.license_trial_max_active_raffles, self.license_trial_max_tickets_per_raffle,
               self.license_trial_max_team_accounts, self.license_trial_max_organizers) < 0:
            raise ValueError("TRIAL license limits cannot be negative")
        return self

    @property
    def cors_origin_list(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
