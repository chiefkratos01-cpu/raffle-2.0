from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.core.database import get_db
from app.models.ticket import Ticket
from app.models.winner import Winner
from app.models.raffle import Raffle
from app.schemas.ticket import TicketVerificationResponse

router = APIRouter(prefix="/tickets", tags=["tickets"])

@router.get("/verify/{code}", response_model=TicketVerificationResponse)
def verify_ticket(code: str, db: Session = Depends(get_db)):
    ticket = db.scalar(
        select(Ticket).options(selectinload(Ticket.raffle)).where(Ticket.verification_code == code)
    )
    if not ticket:
        raise HTTPException(404, "Ticket verification code not found")
    winner = db.scalar(select(Winner).where(Winner.ticket_id == ticket.id))
    return TicketVerificationResponse(
        raffle_title=ticket.raffle.title,
        ticket_number=ticket.number,
        status=ticket.status,
        verification_code=ticket.verification_code,
        paid_at=ticket.paid_at,
        is_winner=winner is not None,
        prize_position=winner.prize_position if winner else None,
        prize_description=winner.prize_description if winner else None,
        winner_verification_code=winner.verification_code if winner else None,
    )
