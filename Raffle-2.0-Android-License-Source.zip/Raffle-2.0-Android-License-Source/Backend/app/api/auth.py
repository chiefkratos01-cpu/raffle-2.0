from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_, select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.deps import get_current_user, get_current_admin, get_current_session, bearer, _claims
from app.core.security import hash_password, verify_password, create_access_token, new_refresh_token, hash_refresh_token
from app.core.config import settings
from app.models.user import User
from app.models.admin import Admin
from app.models.auth_session import AuthSession
from app.core.validation import validate_email, validate_phone, validate_person_name
from app.schemas.auth import RegisterRequest, LoginRequest, TokenResponse, MeResponse, RefreshRequest, LogoutRequest, SessionResponse, RevokeAllResponse

router = APIRouter(prefix="/auth", tags=["auth"])


def _issue(db: Session, subject_id: int, role: str, request: Request | None = None) -> TokenResponse:
    refresh = new_refresh_token()
    now = datetime.now(timezone.utc)
    session = AuthSession(subject_type=role, subject_id=subject_id, refresh_token_hash=hash_refresh_token(refresh),
                          created_at=now, expires_at=now + timedelta(days=settings.refresh_token_days), last_used_at=now,
                          ip_address=request.client.host if request and request.client else None,
                          user_agent=(request.headers.get("user-agent", "")[:512] if request else None))
    db.add(session); db.flush()
    access = create_access_token(str(subject_id), role, str(session.id))
    db.commit()
    return TokenResponse(access_token=access, refresh_token=refresh)


def _rotate(db: Session, refresh: str) -> TokenResponse:
    session = db.scalar(
        select(AuthSession)
        .where(AuthSession.refresh_token_hash == hash_refresh_token(refresh))
        .with_for_update()
    )
    now = datetime.now(timezone.utc)
    if not session or session.revoked_at:
        raise HTTPException(401, "Invalid or expired refresh token")
    expires_at = session.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at <= now:
        raise HTTPException(401, "Invalid or expired refresh token")
    if session.subject_type == "USER":
        subject = db.get(User, session.subject_id)
    elif session.subject_type == "ADMIN":
        subject = db.get(Admin, session.subject_id)
    else:
        subject = None
    if not subject or not subject.is_active:
        session.revoked_at = now
        db.commit()
        raise HTTPException(401, "Account inactive")
    new_refresh_value = new_refresh_token()
    session.refresh_token_hash = hash_refresh_token(new_refresh_value)
    session.last_used_at = now
    access = create_access_token(str(session.subject_id), session.subject_type, str(session.id))
    db.commit()
    return TokenResponse(access_token=access, refresh_token=new_refresh_value)


@router.post("/register", response_model=TokenResponse)
def register(data: RegisterRequest, request: Request, db: Session = Depends(get_db)):
    name = validate_person_name(data.name, "Nombre")
    email = validate_email(data.email) if data.email else None
    phone = validate_phone(data.phone) if data.phone else None
    if email and db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "Ese correo ya está registrado")
    if phone and db.scalar(select(User.id).where(User.phone == phone)):
        raise HTTPException(409, "Ese teléfono ya está registrado")
    user = User(name=name, phone=phone, email=email, password_hash=hash_password(data.password))
    db.add(user); db.flush()
    return _issue(db, user.id, "USER", request)


@router.post("/login", response_model=TokenResponse)
def login(data: LoginRequest, request: Request, db: Session = Depends(get_db)):
    identifier = data.identifier.strip()
    user = db.scalar(select(User).where(User.is_demo.is_(False), or_(User.email == identifier.lower(), User.phone == identifier)))
    if user and verify_password(data.password, user.password_hash):
        user.last_login = datetime.now(timezone.utc); db.flush()
        return _issue(db, user.id, "USER", request)
    admin = db.scalar(select(Admin).where(Admin.username == identifier))
    if admin and verify_password(data.password, admin.password_hash):
        return _issue(db, admin.id, "ADMIN", request)
    raise HTTPException(401, "Invalid credentials")


@router.post("/refresh", response_model=TokenResponse)
def refresh(data: RefreshRequest, db: Session = Depends(get_db)):
    return _rotate(db, data.refresh_token)


@router.post("/logout")
def logout(data: LogoutRequest, db: Session = Depends(get_db), current: AuthSession = Depends(get_current_session)):
    """Revoke the authenticated session on the server.

    The optional refresh token is accepted for backwards compatibility, but the
    access-token session is the authority. This works for both customers and
    administrators and prevents a client from logging out a different session.
    """
    now = datetime.now(timezone.utc)
    current.revoked_at = now
    db.commit()
    return {"ok": True, "revoked_session_id": current.id}



@router.get("/me", response_model=MeResponse)
def me(user: User = Depends(get_current_user)):
    return user


@router.get("/admin/me")
def admin_me(admin: Admin = Depends(get_current_admin)):
    return {
        "id": admin.id,
        "username": admin.username,
        "email": admin.email,
        "phone": admin.phone,
        "role": admin.role.value,
        "is_active": admin.is_active,
    }


@router.get("/sessions", response_model=list[SessionResponse])
def sessions(credentials=Depends(bearer), current: AuthSession = Depends(get_current_session), db: Session = Depends(get_db)):
    claims = _claims(credentials)
    rows = db.scalars(
        select(AuthSession)
        .where(AuthSession.subject_type == claims["role"], AuthSession.subject_id == int(claims["sub"]))
        .order_by(AuthSession.created_at.desc(), AuthSession.id.desc())
    ).all()
    return [SessionResponse(
        id=s.id, subject_type=s.subject_type, created_at=s.created_at.isoformat(),
        expires_at=s.expires_at.isoformat(), last_used_at=s.last_used_at.isoformat() if s.last_used_at else None,
        ip_address=s.ip_address, user_agent=s.user_agent, current=s.id == current.id
    ) for s in rows if s.revoked_at is None]


@router.delete("/sessions/{session_id}")
def revoke_session(session_id: int, credentials=Depends(bearer), current: AuthSession = Depends(get_current_session), db: Session = Depends(get_db)):
    claims = _claims(credentials)
    session = db.scalar(select(AuthSession).where(
        AuthSession.id == session_id, AuthSession.subject_type == claims["role"],
        AuthSession.subject_id == int(claims["sub"]), AuthSession.revoked_at.is_(None)
    ))
    if not session:
        raise HTTPException(404, "Session not found")
    session.revoked_at = datetime.now(timezone.utc)
    db.commit()
    return {"ok": True, "revoked_session_id": session_id, "current": session_id == current.id}


@router.post("/sessions/revoke-others", response_model=RevokeAllResponse)
def revoke_other_sessions(credentials=Depends(bearer), current: AuthSession = Depends(get_current_session), db: Session = Depends(get_db)):
    claims = _claims(credentials)
    rows = db.scalars(select(AuthSession).where(
        AuthSession.subject_type == claims["role"], AuthSession.subject_id == int(claims["sub"]),
        AuthSession.revoked_at.is_(None), AuthSession.id != current.id
    )).all()
    now = datetime.now(timezone.utc)
    for session in rows:
        session.revoked_at = now
    db.commit()
    return {"ok": True, "revoked": len(rows)}
