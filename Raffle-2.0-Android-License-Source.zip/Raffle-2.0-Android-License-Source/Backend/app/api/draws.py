from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.database import get_db, SessionLocal
from app.core.deps import require_permission, require_license_for_existing_raffle
from app.services.license_service import lock_current_license_for_update, may_complete_existing_raffle
from app.models.admin import Admin
from app.models.raffle import Raffle
from app.models.draw import Draw
from app.models.winner import Winner
from app.schemas.draw import DrawRequest, DrawResponse, WinnerResponse, PublicWinnerResponse, PublicDrawResponse
from app.services.draw_service import perform_draw, finalize_draw
from app.services.audit_service import record_audit
from app.services.raffle_service import get_public

router = APIRouter(prefix="/draws", tags=["draws"])


def _proof(draw: Draw) -> dict:
    return {
        "randomness_commitment": draw.randomness_commitment,
        "eligible_pool_hash": draw.eligible_pool_hash,
        "result_hash": draw.result_hash,
        "eligible_count": draw.eligible_count,
        "selection_algorithm": draw.selection_algorithm,
    }


def winner_response(w: Winner) -> WinnerResponse:
    return WinnerResponse(
        id=w.id,
        raffle_id=w.raffle_id,
        draw_id=w.draw_id,
        ticket_id=w.ticket_id,
        user_id=w.user_id,
        ticket_number=w.ticket.number,
        prize_position=w.prize_position,
        prize_description=w.prize_description,
        verification_code=w.verification_code,
        created_at=w.created_at,
        animation_seed=w.draw.animation_seed,
        **_proof(w.draw),
    )


def public_winner_response(w: Winner) -> PublicWinnerResponse:
    return PublicWinnerResponse(
        id=w.id,
        raffle_id=w.raffle_id,
        draw_id=w.draw_id,
        ticket_number=w.ticket.number,
        prize_position=w.prize_position,
        prize_description=w.prize_description,
        verification_code=w.verification_code,
        created_at=w.created_at,
        animation_seed=w.draw.animation_seed,
        **_proof(w.draw),
    )


@router.get("/verify/{code}", response_model=PublicWinnerResponse)
def verify(code: str, db: Session = Depends(get_db)):
    w = db.scalar(
        select(Winner)
        .options(selectinload(Winner.ticket), selectinload(Winner.draw))
        .where(Winner.verification_code == code)
    )
    if not w:
        raise HTTPException(404, "Verification code not found")
    return public_winner_response(w)


@router.get("/{raffle_id}/latest", response_model=PublicDrawResponse | None)
def latest(raffle_id: int, db: Session = Depends(get_db)):
    if not get_public(db, raffle_id):
        raise HTTPException(404, "Raffle not found")
    return db.scalar(
        select(Draw)
        .where(Draw.raffle_id == raffle_id)
        .order_by(Draw.id.desc())
        .limit(1)
    )


@router.get("/{raffle_id}/history", response_model=list[DrawResponse])
def history(
    raffle_id: int,
    admin: Admin = Depends(require_permission("draw:read")),
    db: Session = Depends(get_db),
):
    raffle = db.get(Raffle, raffle_id)
    if not raffle:
        raise HTTPException(404, "Raffle not found")
    return db.scalars(
        select(Draw).where(Draw.raffle_id == raffle_id).order_by(Draw.prize_position.asc(), Draw.id.asc())
    ).all()


@router.post("/{raffle_id}", response_model=DrawResponse)
def draw(
    raffle_id: int,
    data: DrawRequest,
    background_tasks: BackgroundTasks,
    request: Request,
    admin: Admin = Depends(require_permission("draw:write")),
    license_state=Depends(require_license_for_existing_raffle),
    db: Session = Depends(get_db),
):
    raffle = db.get(Raffle, raffle_id)
    if not raffle:
        raise HTTPException(404, "Raffle not found")
    license_state = lock_current_license_for_update(db)
    if not may_complete_existing_raffle(license_state, raffle.status.value):
        raise HTTPException(402, "La licencia no permite realizar nuevas operaciones de sorteo.")
    try:
        result = perform_draw(db, raffle, data.prize_position)
        draw_obj = result[0]

        def finish():
            import time
            time.sleep(7)
            with SessionLocal() as work_db:
                current = work_db.get(Draw, draw_obj.id)
                if current:
                    finalize_draw(work_db, current)

        background_tasks.add_task(finish)
        record_audit(
            db,
            actor_admin_id=admin.id,
            action="DRAW_STARTED",
            entity_type="DRAW",
            entity_id=draw_obj.id,
            new_value={
                "raffle_id": raffle.id,
                "prize_position": data.prize_position,
                "result_hash": draw_obj.result_hash,
            },
            ip_address=request.client.host if request.client else None,
        )
        db.commit()
        return draw_obj
    except ValueError as e:
        raise HTTPException(409, str(e))


@router.get("/{raffle_id}/winners", response_model=list[PublicWinnerResponse])
def winners(raffle_id: int, db: Session = Depends(get_db)):
    if not get_public(db, raffle_id):
        raise HTTPException(404, "Raffle not found")
    rows = db.scalars(
        select(Winner)
        .options(selectinload(Winner.ticket), selectinload(Winner.draw))
        .where(Winner.raffle_id == raffle_id)
        .order_by(Winner.prize_position)
    ).all()
    return [public_winner_response(w) for w in rows]
