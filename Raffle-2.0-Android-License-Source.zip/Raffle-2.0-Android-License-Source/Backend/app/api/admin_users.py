from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_admin_roles, require_permission
from app.models.admin import Admin
from app.models.auth_session import AuthSession
from app.models.user import User
from app.services.audit_service import record_audit

router = APIRouter(prefix="/admin/users", tags=["admin-users"])


class UserStatus(BaseModel):
    is_active: bool


def safe(user: User) -> dict:
    return {"id": user.id, "name": user.name, "email": user.email, "phone": user.phone, "is_active": user.is_active, "created_at": user.created_at, "last_login": user.last_login}


@router.get("")
def list_users(admin: Admin = Depends(require_permission("customer:read")), db: Session = Depends(get_db)):
    return [safe(x) for x in db.scalars(select(User).order_by(User.created_at.desc(), User.id.desc())).all()]


@router.patch("/{user_id}/status")
def set_status(user_id: int, data: UserStatus, request: Request, admin: Admin = Depends(require_admin_roles()), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "Usuario no encontrado")
    user.is_active = data.is_active
    revoked = 0
    if not user.is_active:
        now = datetime.now(timezone.utc)
        sessions = db.scalars(select(AuthSession).where(AuthSession.subject_type == "USER", AuthSession.subject_id == user.id, AuthSession.revoked_at.is_(None))).all()
        for session in sessions:
            session.revoked_at = now
        revoked = len(sessions)
    record_audit(db, actor_admin_id=admin.id, action="USER_STATUS_CHANGED", entity_type="USER", entity_id=user.id, new_value={"is_active": user.is_active}, ip_address=request.client.host if request.client else None)
    db.commit()
    return safe(user) | {"revoked_sessions": revoked}
