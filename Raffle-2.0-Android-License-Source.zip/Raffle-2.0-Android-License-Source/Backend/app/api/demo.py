from datetime import datetime, timezone
import secrets
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy import select, delete
from sqlalchemy.orm import Session, selectinload
from app.core.database import get_db, SessionLocal
from app.core.config import settings
from app.core.deps import require_admin_roles
from app.models.admin import Admin
from app.models.raffle import Raffle
from app.models.user import User
from app.models.ticket import Ticket
from app.models.winner import Winner
from app.models.draw import Draw
from app.models.enums import AdminRole, TicketStatus, RaffleStatus, DrawStatus
from app.services.draw_service import perform_draw, finalize_draw
from app.schemas.raffle import RaffleResponse

router=APIRouter(prefix="/demo", tags=["demo"])

def _get_demo(db):
    return db.scalar(select(Raffle).options(selectinload(Raffle.prizes)).where(Raffle.is_demo.is_(True)).order_by(Raffle.id).limit(1))

def _safe(raffle, db):
    tickets=db.scalars(select(Ticket).where(Ticket.raffle_id==raffle.id, Ticket.status==TicketStatus.PAID).order_by(Ticket.number)).all()
    draws=db.scalars(select(Draw).where(Draw.raffle_id==raffle.id).order_by(Draw.id)).all()
    raffle_payload=RaffleResponse.model_validate(raffle).model_dump(mode="json")
    return {"raffle": raffle_payload, "tickets":[{"number":t.number,"status":t.status.value,"user_name":t.user.name if t.user else "Participante Demo"} for t in tickets], "draws":[{"id":d.id,"status":d.status.value,"prize_position":d.prize_position,"winning_ticket_id":d.winning_ticket_id,"eligible_count":d.eligible_count,"result_hash":d.result_hash} for d in draws], "ready":bool(tickets), "eligible_count":len(tickets)}

@router.get("/state")
def state(admin:Admin=Depends(require_admin_roles(AdminRole.SUPER_ADMIN,AdminRole.ADMIN)), db:Session=Depends(get_db)):
    if not settings.demo_mode:
        raise HTTPException(404,"La demo no está disponible en esta instalación.")
    raffle=_get_demo(db)
    if not raffle: raise HTTPException(404,"La demo no está disponible.")
    return _safe(raffle,db)

@router.post("/prepare")
def prepare(admin:Admin=Depends(require_admin_roles(AdminRole.SUPER_ADMIN,AdminRole.ADMIN)), db:Session=Depends(get_db)):
    if not settings.demo_mode: raise HTTPException(404,"La demo no está disponible en esta instalación.")
    raffle=_get_demo(db)
    if not raffle: raise HTTPException(404,"La demo no está disponible.")
    winner_ids=db.scalars(select(Winner.id).where(Winner.raffle_id==raffle.id)).all()
    if winner_ids: db.execute(delete(Winner).where(Winner.id.in_(winner_ids)))
    db.execute(delete(Draw).where(Draw.raffle_id==raffle.id))
    db.execute(delete(Ticket).where(Ticket.raffle_id==raffle.id))
    users=[]
    for i in range(1,9):
        email=f"demo-participante-{i}@raffle.local"
        user=db.scalar(select(User).where(User.email==email))
        if not user:
            user=User(name=f"Participante Demo {i:02d}",email=email,password_hash=secrets.token_urlsafe(32),is_active=True,is_demo=True)
            db.add(user); db.flush()
        users.append(user)
    for number,user in zip([4,7,12,18,23,29,36,44],users):
        db.add(Ticket(raffle_id=raffle.id,user_id=user.id,number=number,status=TicketStatus.PAID,verification_code=f"DEMO-{secrets.token_urlsafe(18)}",paid_at=datetime.now(timezone.utc)))
    raffle.tickets_sold=8
    raffle.status=RaffleStatus.OPEN
    db.commit(); db.refresh(raffle)
    return _safe(raffle,db)

@router.post("/draw")
def draw(background_tasks:BackgroundTasks, admin:Admin=Depends(require_admin_roles(AdminRole.SUPER_ADMIN,AdminRole.ADMIN)), db:Session=Depends(get_db)):
    if not settings.demo_mode: raise HTTPException(404,"La demo no está disponible en esta instalación.")
    raffle=_get_demo(db)
    if not raffle: raise HTTPException(404,"La demo no está disponible.")
    if not db.scalar(select(Ticket.id).where(Ticket.raffle_id==raffle.id,Ticket.status==TicketStatus.PAID)):
        prepare(admin,db)
        raffle=_get_demo(db)
    try:
        result=perform_draw(db,raffle,1)
        draw_obj=result[0]
        def finish():
            import time; time.sleep(7)
            with SessionLocal() as work_db:
                current=work_db.get(Draw,draw_obj.id)
                if current: finalize_draw(work_db,current)
        background_tasks.add_task(finish)
        return draw_obj
    except ValueError as exc:
        raise HTTPException(409,str(exc))
