from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.deps import require_permission
from app.models.admin import Admin
from app.models.audit import AuditLog

router = APIRouter(prefix="/admin/audit", tags=["audit"])

@router.get("")
def list_audit(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), admin: Admin = Depends(require_permission("audit:read")), db: Session = Depends(get_db)):
    rows = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).offset(offset).limit(limit)).all()
    return [{
        "id": x.id, "actor_admin_id": x.actor_admin_id, "action": x.action, "entity_type": x.entity_type,
        "entity_id": x.entity_id, "old_value": x.old_value, "new_value": x.new_value,
        "ip_address": x.ip_address, "details": x.details, "created_at": x.created_at,
    } for x in rows]
