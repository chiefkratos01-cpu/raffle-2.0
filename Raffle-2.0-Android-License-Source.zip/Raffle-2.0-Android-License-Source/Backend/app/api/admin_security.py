from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.deps import require_permission, require_admin_roles, require_production_license
from app.core.security import hash_password
from app.models.admin import Admin
from app.models.auth_session import AuthSession
from app.models.enums import AdminRole
from app.services.audit_service import record_audit
from app.core.validation import validate_email, validate_phone, validate_username
from app.services.license_service import check_license_limit, lock_current_license_for_update, team_account_usage

router = APIRouter(prefix="/admin/security", tags=["admin-security"])

class AdminCreateRequest(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=12, max_length=128)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=40)
    role: AdminRole = AdminRole.VIEWER

    @field_validator("password")
    @classmethod
    def strong_password(cls, value):
        if any(ch.isspace() for ch in value) or len(set(value)) < 5:
            raise ValueError("La contraseña debe tener al menos 12 caracteres variados y no contener espacios.")
        return value


class AdminStatusRequest(BaseModel):
    is_active: bool


def _safe(a: Admin) -> dict:
    return {"id": a.id, "username": a.username, "email": a.email, "phone": a.phone, "role": a.role, "is_active": a.is_active, "created_at": a.created_at}

@router.get("/admins")
def list_admins(admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)), db: Session = Depends(get_db)):
    return [_safe(x) for x in db.scalars(select(Admin).order_by(Admin.username)).all()]

@router.post("/admins")
def create_admin(data: AdminCreateRequest, request: Request, admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)), license_state=Depends(require_production_license), db: Session = Depends(get_db)):
    if data.role == AdminRole.SUPER_ADMIN:
        raise HTTPException(403, "No puedes crear otro SUPER_ADMIN desde esta sección")
    if db.scalar(select(Admin).where(Admin.username == data.username)):
        raise HTTPException(409, "Username already exists")
    if data.email and db.scalar(select(Admin).where(Admin.email == data.email)):
        raise HTTPException(409, "Email already exists")
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para crear cuentas de equipo.")
    try:
        check_license_limit(license_state, "max_team_accounts", team_account_usage(db), 1)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    username = validate_username(data.username)
    email = validate_email(data.email) if data.email else None
    phone = validate_phone(data.phone) if data.phone else None
    row = Admin(username=username, password_hash=hash_password(data.password), email=email, phone=phone, role=data.role, is_active=True)
    db.add(row)
    db.flush()
    record_audit(db, actor_admin_id=admin.id, action="ADMIN_CREATED", entity_type="ADMIN", entity_id=row.id, new_value={"username": row.username, "role": row.role.value}, ip_address=request.client.host if request.client else None)
    db.commit()
    return _safe(row)

@router.patch("/admins/{admin_id}/status")
def change_status(admin_id: int, data: AdminStatusRequest, request: Request, admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)), db: Session = Depends(get_db)):
    target = db.get(Admin, admin_id)
    if not target:
        raise HTTPException(404, "Administrator not found")
    if target.id == admin.id and not data.is_active:
        raise HTTPException(400, "You cannot deactivate your own administrator account")
    old = {"is_active": target.is_active}
    target.is_active = data.is_active
    revoked_sessions = 0
    if not data.is_active:
        now = datetime.now(timezone.utc)
        rows = db.scalars(select(AuthSession).where(
            AuthSession.subject_type == "ADMIN",
            AuthSession.subject_id == target.id,
            AuthSession.revoked_at.is_(None),
        )).all()
        for session in rows:
            session.revoked_at = now
        revoked_sessions = len(rows)
    record_audit(db, actor_admin_id=admin.id, action="ADMIN_STATUS_CHANGED", entity_type="ADMIN", entity_id=target.id, old_value=old, new_value={"is_active": target.is_active}, ip_address=request.client.host if request.client else None)
    db.commit()
    result = _safe(target)
    result["revoked_sessions"] = revoked_sessions
    return result
