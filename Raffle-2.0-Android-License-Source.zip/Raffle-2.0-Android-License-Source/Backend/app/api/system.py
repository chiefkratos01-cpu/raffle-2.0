from datetime import datetime, timezone
from time import perf_counter
from fastapi import APIRouter, Response
from sqlalchemy import text
from app.core.config import settings
from app.core.database import engine
from app.schemas.system import HealthResponse, LivenessResponse

router = APIRouter(tags=["system"])


def _db_probe() -> tuple[str, float | None]:
    started = perf_counter()
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return "ok", round((perf_counter() - started) * 1000, 2)
    except Exception:
        return "error", None


@router.get("/health", response_model=HealthResponse)
def health():
    database, latency = _db_probe()
    status = "healthy" if database == "ok" else "degraded"
    return HealthResponse(
        status=status, version=settings.app_version, environment=settings.environment,
        timestamp=datetime.now(timezone.utc), database=database, database_latency_ms=latency,
    )


@router.get("/health/live", response_model=LivenessResponse)
def liveness():
    return LivenessResponse(status="alive", version=settings.app_version, timestamp=datetime.now(timezone.utc))


@router.get("/health/ready", response_model=HealthResponse)
def readiness(response: Response):
    database, latency = _db_probe()
    status = "ready" if database == "ok" else "not_ready"
    if status != "ready":
        response.status_code = 503
    return HealthResponse(
        status=status, version=settings.app_version, environment=settings.environment,
        timestamp=datetime.now(timezone.utc), database=database, database_latency_ms=latency,
    )


@router.get("/config/public")
def public_config():
    return {"app_name": settings.app_name, "version": settings.app_version, "demo_mode": settings.demo_mode, "organizer": {"name": settings.organizer_name, "whatsapp": settings.organizer_whatsapp, "phone": settings.organizer_phone}}
