from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from sqlalchemy.orm import Session, selectinload
from app.core.database import get_db
from app.core.deps import require_permission, require_production_license, require_license_for_existing_raffle
from app.models.admin import Admin
from app.models.enums import RaffleStatus, TicketStatus, ReservationStatus, PaymentStatus
from app.models.raffle import Raffle
from app.schemas.raffle import RaffleCreate, RaffleUpdate, RaffleResponse
from app.schemas.availability import TicketAvailabilityResponse
from app.models.ticket import Ticket
from app.models.reservation import Reservation
from app.models.ticket_allocation import TicketAllocation
from app.services.reservation_service import release_expired
from app.services.raffle_service import create_raffle, list_public, get_public
from app.services.audit_service import record_audit
from app.realtime.events import emit_raffle_update
from sqlalchemy import func, select
from app.services.license_service import check_license_limit, lock_current_license_for_update

router = APIRouter(prefix="/raffles", tags=["raffles"])


def _admin_response(raffle: Raffle) -> RaffleResponse:
    return RaffleResponse.model_validate(raffle)

@router.get("", response_model=list[RaffleResponse])
def public_raffles(db: Session = Depends(get_db)):
    return list_public(db)

@router.get("/{raffle_id}/availability", response_model=TicketAvailabilityResponse)
def raffle_availability(raffle_id: int, start: int = Query(default=1, ge=1), limit: int = Query(default=100, ge=1, le=500), db: Session = Depends(get_db)):
    raffle = get_public(db, raffle_id)
    if not raffle:
        raise HTTPException(404, "Raffle not found")
    released = release_expired(db, raffle_id)
    if released:
        emit_raffle_update(raffle_id, {"type": "tickets_changed", "raffle_id": raffle_id, "released": released})
    end = min(raffle.total_tickets, start + limit - 1)
    if start > raffle.total_tickets:
        return TicketAvailabilityResponse(raffle_id=raffle.id, total_tickets=raffle.total_tickets, start=start, end=start - 1, occupied=[])
    occupied = db.scalars(
        select(Ticket.number).where(
            Ticket.raffle_id == raffle_id,
            Ticket.number >= start, Ticket.number <= end,
            Ticket.status.in_([TicketStatus.RESERVED, TicketStatus.PAID])
        ).order_by(Ticket.number)
    ).all()
    return TicketAvailabilityResponse(raffle_id=raffle.id, total_tickets=raffle.total_tickets, start=start, end=end, occupied=occupied)

@router.get("/{raffle_id}", response_model=RaffleResponse)
def public_raffle(raffle_id: int, db: Session = Depends(get_db)):
    raffle = get_public(db, raffle_id)
    if not raffle: raise HTTPException(404, "Raffle not found")
    return raffle

@router.post("", response_model=RaffleResponse)
def admin_create(data: RaffleCreate, request: Request, db: Session = Depends(get_db), admin: Admin = Depends(require_permission("raffle:write")), license_state=Depends(require_production_license)):
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para crear rifas.")
    try:
        check_license_limit(license_state, "max_tickets_per_raffle", 0, data.total_tickets)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    try:
        raffle = create_raffle(db, data, commit=False, is_demo=False)
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    record_audit(db, actor_admin_id=admin.id, action="RAFFLE_CREATED", entity_type="RAFFLE", entity_id=raffle.id, new_value={"title": raffle.title, "status": raffle.status.value, "winner_count": raffle.winner_count}, ip_address=request.client.host if request.client else None)
    db.commit()
    return _admin_response(raffle)

@router.post("/{raffle_id}/publish", response_model=RaffleResponse)
def publish(raffle_id: int, request: Request, db: Session = Depends(get_db), admin: Admin = Depends(require_permission("raffle:write")), license_state=Depends(require_production_license)):
    raffle = db.get(Raffle, raffle_id)
    if not raffle:
        raise HTTPException(404, "Raffle not found")
    if raffle.status != RaffleStatus.DRAFT:
        raise HTTPException(409, "Solo las rifas en borrador pueden publicarse")
    if not raffle.prizes:
        raise HTTPException(400, "Add at least one prize before publishing")
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para publicar rifas.")
    active_count = db.scalar(select(func.count(Raffle.id)).where(
        Raffle.is_demo.is_(False),
        Raffle.status.in_([RaffleStatus.OPEN, RaffleStatus.LOW_TICKETS, RaffleStatus.SOLD_OUT, RaffleStatus.DRAW_SCHEDULED, RaffleStatus.DRAWING]),
    )) or 0
    try:
        check_license_limit(license_state, "max_active_raffles", int(active_count), 1)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    raffle.status = RaffleStatus.OPEN
    record_audit(db, actor_admin_id=admin.id, action="RAFFLE_PUBLISHED", entity_type="RAFFLE", entity_id=raffle.id, new_value={"status": raffle.status.value}, ip_address=request.client.host if request.client else None)
    db.commit()
    return _admin_response(raffle)

@router.put("/{raffle_id}", response_model=RaffleResponse)
def update(raffle_id:int,data:RaffleUpdate,request:Request,db:Session=Depends(get_db),admin:Admin=Depends(require_permission("raffle:write")),license_state=Depends(require_production_license)):
    raffle=db.get(Raffle,raffle_id)
    if not raffle: raise HTTPException(404,"Raffle not found")
    if raffle.status in (RaffleStatus.DRAWING,RaffleStatus.COMPLETED,RaffleStatus.CANCELLED):
        raise HTTPException(409,"Raffle can no longer be edited")

    has_sales = raffle.tickets_sold > 0
    core_fields = {"total_tickets", "ticket_price", "currency", "winner_count", "max_tickets_per_user", "allow_multiple_wins", "auto_release_enabled", "reservation_minutes"}
    incoming = data.model_dump(exclude={"prizes"})
    if has_sales:
        changed = [field for field in core_fields if incoming.get(field) != getattr(raffle, field)]
        if changed:
            raise HTTPException(409, "Core raffle settings cannot change after tickets have been sold")
        current_prizes = sorted((p.position, p.title, p.description, p.image, p.value) for p in raffle.prizes)
        new_prizes = sorted((p.position, p.title, p.description, p.image, p.value) for p in data.prizes)
        if current_prizes != new_prizes:
            raise HTTPException(409, "Prizes cannot change after tickets have been sold")

    if data.total_tickets < raffle.tickets_sold:
        raise HTTPException(422, "Total tickets cannot be lower than tickets already sold")
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para actualizar rifas.")
    try:
        check_license_limit(license_state, "max_tickets_per_raffle", 0, data.total_tickets)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    if data.auto_release_enabled and data.reservation_minutes is None:
        raise HTTPException(422, "reservation_minutes is required when automatic release is enabled")
    positions={p.position for p in data.prizes}
    if len(positions) != len(data.prizes):
        raise HTTPException(422,"Duplicate prize position")
    if any(p.position > data.winner_count for p in data.prizes):
        raise HTTPException(422,"Prize position exceeds winner count")
    if data.winner_count > len(data.prizes):
        raise HTTPException(422,"Create a prize for each winner position")

    for field,value in incoming.items():
        setattr(raffle,field,value)
    raffle.prizes.clear()
    from app.models.prize import Prize
    for prize in sorted(data.prizes, key=lambda p: p.position):
        raffle.prizes.append(Prize(**prize.model_dump()))
    record_audit(db, actor_admin_id=admin.id, action="RAFFLE_UPDATED", entity_type="RAFFLE", entity_id=raffle.id, new_value={"title": raffle.title, "status": raffle.status.value, "winner_count": raffle.winner_count}, ip_address=request.client.host if request.client else None)
    db.commit(); db.refresh(raffle); return _admin_response(raffle)

@router.post("/{raffle_id}/cancel",response_model=RaffleResponse)
def cancel(raffle_id:int,request:Request,db:Session=Depends(get_db),admin:Admin=Depends(require_permission("raffle:write")),license_state=Depends(require_license_for_existing_raffle)):
    raffle = db.scalar(
        select(Raffle)
        .options(selectinload(Raffle.reservations).selectinload(Reservation.tickets), selectinload(Raffle.reservations).selectinload(Reservation.payment))
        .where(Raffle.id == raffle_id)
    )
    if not raffle:
        raise HTTPException(404, "Raffle not found")
    if not license_state["active"]:
        if license_state["mode"] != "EXPIRED" or raffle.status.value not in {"DRAFT", "OPEN", "LOW_TICKETS", "SOLD_OUT", "DRAW_SCHEDULED"}:
            raise HTTPException(402, "Licencia vencida. Renueva para realizar esta acción.")
    cancellable = {RaffleStatus.DRAFT, RaffleStatus.OPEN, RaffleStatus.LOW_TICKETS, RaffleStatus.SOLD_OUT, RaffleStatus.DRAW_SCHEDULED}
    if raffle.status not in cancellable:
        raise HTTPException(409, "Raffle cannot be cancelled in its current state")
    if raffle.tickets_sold > 0:
        raise HTTPException(
            409,
            "No puedes cancelar una rifa que ya tiene boletos pagados. Gestiona primero los reembolsos correspondientes.",
        )

    released_at = datetime.now(timezone.utc)
    for reservation in raffle.reservations:
        if reservation.status not in (ReservationStatus.ACTIVE, ReservationStatus.PAYMENT_REVIEW):
            continue
        reservation.status = ReservationStatus.RELEASED
        reservation.released_at = released_at
        reservation.expires_at = None
        reservation.release_reason = "Rifa cancelada"
        if reservation.payment and reservation.payment.status == PaymentStatus.PENDING:
            reservation.payment.status = PaymentStatus.REJECTED
            reservation.payment.rejection_reason = "Rifa cancelada"
        for ticket in reservation.tickets:
            if ticket.status == TicketStatus.RESERVED:
                db.add(TicketAllocation(
                    raffle_id=ticket.raffle_id,
                    reservation_id=reservation.id,
                    ticket_id=ticket.id,
                    user_id=ticket.user_id,
                    number=ticket.number,
                    verification_code=ticket.verification_code,
                    status=TicketStatus.RELEASED,
                    allocated_at=ticket.created_at,
                    released_at=released_at,
                    release_reason="Rifa cancelada",
                ))
                ticket.status = TicketStatus.RELEASED

    raffle.status = RaffleStatus.CANCELLED
    record_audit(db, actor_admin_id=admin.id, action="RAFFLE_CANCELLED", entity_type="RAFFLE", entity_id=raffle.id, new_value={"status": raffle.status.value}, ip_address=request.client.host if request.client else None)
    db.commit(); db.refresh(raffle); return _admin_response(raffle)
