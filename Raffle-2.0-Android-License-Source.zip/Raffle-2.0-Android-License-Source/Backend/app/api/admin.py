from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.core.database import get_db
from app.core.deps import require_permission
from app.models.admin import Admin
from app.models.reservation import Reservation
from app.models.enums import ReservationStatus
from app.schemas.reservation import ReservationResponse, PaymentDecision
from app.services.reservation_service import decide_payment
from app.realtime.events import emit_raffle_update
from app.services.audit_service import record_audit

router = APIRouter(prefix="/admin", tags=["admin"])

def response(r):
    return ReservationResponse(id=r.id, code=r.code, raffle_id=r.raffle_id, user_id=r.user_id, status=r.status, expires_at=r.expires_at, created_at=r.created_at, tickets=r.tickets, payment_status=r.payment.status if r.payment else None, payment_amount=r.payment.amount if r.payment else None)

@router.get("/reservations/pending", response_model=list[ReservationResponse])
def pending(admin: Admin = Depends(require_permission("reservation:read")), db: Session = Depends(get_db)):
    rows = db.scalars(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment)).where(Reservation.status.in_([ReservationStatus.ACTIVE, ReservationStatus.PAYMENT_REVIEW])).order_by(Reservation.created_at.asc())).all()
    return [response(r) for r in rows]

@router.post("/reservations/{reservation_id}/confirm", response_model=ReservationResponse)
def confirm(reservation_id: int, data: PaymentDecision, request: Request, admin: Admin = Depends(require_permission("payment:write")), db: Session = Depends(get_db)):
    r = db.scalar(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment), selectinload(Reservation.raffle)).where(Reservation.id == reservation_id))
    if not r: raise HTTPException(404, "Reservation not found")
    try:
        result = decide_payment(db, r, admin.id, data, True, commit=False)
        record_audit(db, actor_admin_id=admin.id, action="PAYMENT_CONFIRMED", entity_type="RESERVATION", entity_id=r.id, new_value={"payment_status": "CONFIRMED", "reservation_status": result.status.value}, ip_address=request.client.host if request.client else None)
        db.commit()
        emit_raffle_update(r.raffle_id, {'type': 'tickets_changed', 'raffle_id': r.raffle_id})
        return response(result)
    except ValueError as exc: raise HTTPException(409, str(exc))

@router.post("/reservations/{reservation_id}/reject", response_model=ReservationResponse)
def reject(reservation_id: int, data: PaymentDecision, request: Request, admin: Admin = Depends(require_permission("payment:write")), db: Session = Depends(get_db)):
    r = db.scalar(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment), selectinload(Reservation.raffle)).where(Reservation.id == reservation_id))
    if not r: raise HTTPException(404, "Reservation not found")
    try:
        result = decide_payment(db, r, admin.id, data, False, commit=False)
        record_audit(db, actor_admin_id=admin.id, action="PAYMENT_REJECTED", entity_type="RESERVATION", entity_id=r.id, new_value={"payment_status": "REJECTED", "reservation_status": result.status.value, "reason": result.release_reason}, ip_address=request.client.host if request.client else None)
        db.commit()
        emit_raffle_update(r.raffle_id, {'type': 'tickets_changed', 'raffle_id': r.raffle_id})
        return response(result)
    except ValueError as exc: raise HTTPException(409, str(exc))
