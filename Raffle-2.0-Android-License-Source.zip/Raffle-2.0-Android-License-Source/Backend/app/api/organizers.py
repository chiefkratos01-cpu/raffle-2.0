from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user, require_admin_roles, require_production_license
from app.core.security import hash_password
from app.models.admin import Admin
from app.models.enums import AdminRole
from app.models.organizer_request import OrganizerRequest
from app.models.user import User
from app.services.audit_service import record_audit
from app.services.license_service import check_license_limit, lock_current_license_for_update, organizer_usage
from app.services.notification_service import notify

router = APIRouter(prefix="/organizer", tags=["organizer"])
admin_router = APIRouter(prefix="/admin/organizers", tags=["admin-organizers"])


class OrganizerRequestCreate(BaseModel):
    desired_username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=128)
    business_name: str | None = Field(default=None, max_length=160)
    notes: str | None = Field(default=None, max_length=2000)

    @field_validator("password")
    @classmethod
    def strong_password(cls, value):
        if any(ch.isspace() for ch in value) or len(set(value)) < 5:
            raise ValueError("La contraseña debe tener al menos 12 caracteres variados y no contener espacios.")
        return value


class OrganizerDecision(BaseModel):
    reason: str | None = Field(default=None, max_length=2000)


def _safe(row: OrganizerRequest, user: User | None = None) -> dict:
    return {
        "id": row.id,
        "user_id": row.user_id,
        "applicant_name": user.name if user else None,
        "email": user.email if user else None,
        "phone": user.phone if user else None,
        "desired_username": row.desired_username,
        "business_name": row.business_name,
        "notes": row.notes,
        "status": row.status,
        "admin_id": row.admin_id,
        "rejection_reason": row.rejection_reason,
        "created_at": row.created_at,
        "reviewed_at": row.reviewed_at,
    }


@router.post("/requests")
def request_organizer(
    data: OrganizerRequestCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    existing = db.scalar(select(OrganizerRequest).where(OrganizerRequest.user_id == user.id))
    if existing:
        if existing.status == "PENDING":
            raise HTTPException(409, "Ya tienes una solicitud pendiente")
        if existing.status == "APPROVED":
            raise HTTPException(409, "Tu acceso como organizador ya fue aprobado")
        db.delete(existing)
        db.flush()

    if db.scalar(select(Admin.id).where(Admin.username == data.desired_username)):
        raise HTTPException(409, "Ese nombre de acceso ya está en uso")
    if db.scalar(select(OrganizerRequest.id).where(OrganizerRequest.desired_username == data.desired_username)):
        raise HTTPException(409, "Ese nombre de acceso ya está solicitado")

    row = OrganizerRequest(
        user_id=user.id,
        desired_username=data.desired_username.strip(),
        password_hash=hash_password(data.password),
        business_name=data.business_name.strip() if data.business_name else None,
        notes=data.notes.strip() if data.notes else None,
        status="PENDING",
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return _safe(row, user)


@router.get("/requests/mine")
def my_organizer_request(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    row = db.scalar(select(OrganizerRequest).where(OrganizerRequest.user_id == user.id))
    return _safe(row, user) if row else None


@admin_router.get("/requests")
def list_requests(
    admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)),
    db: Session = Depends(get_db),
):
    rows = db.scalars(select(OrganizerRequest).order_by(OrganizerRequest.created_at.desc(), OrganizerRequest.id.desc())).all()
    users = {u.id: u for u in db.scalars(select(User).where(User.id.in_([r.user_id for r in rows]))).all()} if rows else {}
    return [_safe(row, users.get(row.user_id)) for row in rows]


@admin_router.post("/requests/{request_id}/approve")
def approve_request(
    request_id: int,
    request: Request,
    decision: OrganizerDecision | None = None,
    admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)),
    license_state=Depends(require_production_license),
    db: Session = Depends(get_db),
):
    row = db.get(OrganizerRequest, request_id)
    if not row:
        raise HTTPException(404, "Solicitud no encontrada")
    if row.status != "PENDING":
        raise HTTPException(409, "La solicitud ya fue resuelta")
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para aprobar organizadores.")
    try:
        check_license_limit(license_state, "max_organizers", organizer_usage(db), 1)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    user = db.get(User, row.user_id)
    if not user or not user.is_active:
        raise HTTPException(409, "La cuenta del solicitante no está activa")
    if db.scalar(select(Admin.id).where(Admin.username == row.desired_username)):
        raise HTTPException(409, "El nombre de acceso ya está en uso")
    if user.email and db.scalar(select(Admin.id).where(Admin.email == user.email)):
        raise HTTPException(409, "El correo del solicitante ya pertenece a un administrador")

    organizer_admin = Admin(
        username=row.desired_username,
        password_hash=row.password_hash,
        email=user.email,
        phone=user.phone,
        role=AdminRole.ADMIN,
        is_active=True,
    )
    row.password_hash = "CLEARED_AFTER_APPROVAL"
    db.add(organizer_admin)
    db.flush()
    now = datetime.now(timezone.utc)
    row.status = "APPROVED"
    row.admin_id = organizer_admin.id
    row.reviewed_by_admin_id = admin.id
    row.reviewed_at = now
    row.rejection_reason = None
    notify(db, user.id, "Acceso como organizador aprobado", f"Tu acceso como organizador fue aprobado. Usa el acceso '{row.desired_username}' para entrar al panel administrativo.", "ORGANIZER_APPROVED")
    record_audit(db, actor_admin_id=admin.id, action="ORGANIZER_REQUEST_APPROVED", entity_type="ORGANIZER_REQUEST", entity_id=row.id, new_value={"admin_id": organizer_admin.id, "username": organizer_admin.username}, ip_address=request.client.host if request.client else None)
    db.commit()
    return _safe(row, user) | {"admin_username": organizer_admin.username}


@admin_router.post("/requests/{request_id}/reject")
def reject_request(
    request_id: int,
    request: Request,
    decision: OrganizerDecision,
    admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)),
    db: Session = Depends(get_db),
):
    row = db.get(OrganizerRequest, request_id)
    if not row:
        raise HTTPException(404, "Solicitud no encontrada")
    if row.status != "PENDING":
        raise HTTPException(409, "La solicitud ya fue resuelta")
    user = db.get(User, row.user_id)
    now = datetime.now(timezone.utc)
    row.status = "REJECTED"
    row.reviewed_by_admin_id = admin.id
    row.reviewed_at = now
    row.rejection_reason = (decision.reason or "Solicitud no aprobada").strip()
    row.password_hash = "CLEARED_AFTER_REJECTION"
    if user:
        notify(db, user.id, "Solicitud de organizador no aprobada", row.rejection_reason, "ORGANIZER_REJECTED")
    record_audit(db, actor_admin_id=admin.id, action="ORGANIZER_REQUEST_REJECTED", entity_type="ORGANIZER_REQUEST", entity_id=row.id, new_value={"reason": row.rejection_reason}, ip_address=request.client.host if request.client else None)
    db.commit()
    return _safe(row, user)
