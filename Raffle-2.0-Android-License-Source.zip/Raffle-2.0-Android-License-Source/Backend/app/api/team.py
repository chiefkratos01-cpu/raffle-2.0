from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_permission, require_admin_roles, require_production_license
from app.core.security import hash_password
from app.models.admin import Admin
from app.models.auth_session import AuthSession
from app.models.enums import AdminRole
from app.services.audit_service import record_audit
from app.core.validation import validate_email, validate_phone, validate_username
from app.services.license_service import check_license_limit, lock_current_license_for_update, team_account_usage

router = APIRouter(prefix="/admin/team", tags=["admin-team"])
MANAGED_ROLES = {AdminRole.ADMIN, AdminRole.OPERATOR, AdminRole.FINANCE, AdminRole.VIEWER}


class TeamMemberCreate(BaseModel):
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=128)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=40)
    role: AdminRole = AdminRole.VIEWER


    @field_validator("password")
    @classmethod
    def strong_password(cls, value):
        if any(ch.isspace() for ch in value) or len(set(value)) < 5:
            raise ValueError("La contraseña debe tener al menos 12 caracteres variados y no contener espacios.")
        return value


class TeamMemberStatus(BaseModel):
    is_active: bool


def safe(row: Admin) -> dict:
    return {"id": row.id, "username": row.username, "email": row.email, "phone": row.phone, "role": row.role.value, "is_active": row.is_active, "created_at": row.created_at}


@router.get("")
def list_team(admin: Admin = Depends(require_permission("team:read")), db: Session = Depends(get_db)):
    query = select(Admin).where(Admin.id != admin.id)
    if admin.role != AdminRole.SUPER_ADMIN:
        query = query.where(Admin.role.in_([AdminRole.OPERATOR, AdminRole.FINANCE, AdminRole.VIEWER]))
    rows = db.scalars(query.order_by(Admin.username)).all()
    return [safe(x) for x in rows]


@router.post("")
def add_member(data: TeamMemberCreate, request: Request, admin: Admin = Depends(require_permission("team:manage")), license_state=Depends(require_production_license), db: Session = Depends(get_db)):
    if data.role == AdminRole.SUPER_ADMIN:
        raise HTTPException(403, "No puedes crear otro SUPER_ADMIN desde el equipo")
    if admin.role != AdminRole.SUPER_ADMIN and data.role == AdminRole.ADMIN:
        raise HTTPException(403, "Solo el SUPER_ADMIN puede crear administradores")
    if db.scalar(select(Admin.id).where(Admin.username == data.username)):
        raise HTTPException(409, "Ese nombre de acceso ya está en uso")
    if data.email and db.scalar(select(Admin.id).where(Admin.email == data.email)):
        raise HTTPException(409, "Ese correo ya está en uso")
    license_state = lock_current_license_for_update(db)
    if not license_state["active"]:
        raise HTTPException(402, "Licencia activa requerida para crear cuentas de equipo.")
    try:
        check_license_limit(license_state, "max_team_accounts", team_account_usage(db), 1)
    except ValueError as exc:
        raise HTTPException(402, str(exc))
    username = validate_username(data.username)
    email = validate_email(data.email) if data.email else None
    phone = validate_phone(data.phone) if data.phone else None
    row = Admin(username=username, password_hash=hash_password(data.password), email=email, phone=phone, role=data.role, is_active=True)
    db.add(row)
    db.flush()
    record_audit(db, actor_admin_id=admin.id, action="TEAM_MEMBER_CREATED", entity_type="ADMIN", entity_id=row.id, new_value={"username": row.username, "role": row.role.value}, ip_address=request.client.host if request.client else None)
    db.commit()
    return safe(row)


@router.patch("/{admin_id}/status")
def set_status(admin_id: int, data: TeamMemberStatus, request: Request, admin: Admin = Depends(require_permission("team:manage")), db: Session = Depends(get_db)):
    row = db.get(Admin, admin_id)
    if not row:
        raise HTTPException(404, "Miembro no encontrado")
    if row.id == admin.id:
        raise HTTPException(400, "No puedes desactivar tu propio acceso")
    if admin.role != AdminRole.SUPER_ADMIN and row.role in {AdminRole.SUPER_ADMIN, AdminRole.ADMIN}:
        raise HTTPException(403, "No puedes cambiar el acceso de un administrador general")
    row.is_active = data.is_active
    revoked = 0
    if not row.is_active:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        sessions = db.scalars(select(AuthSession).where(AuthSession.subject_type == "ADMIN", AuthSession.subject_id == row.id, AuthSession.revoked_at.is_(None))).all()
        for session in sessions:
            session.revoked_at = now
        revoked = len(sessions)
    record_audit(db, actor_admin_id=admin.id, action="TEAM_MEMBER_STATUS_CHANGED", entity_type="ADMIN", entity_id=row.id, new_value={"is_active": row.is_active}, ip_address=request.client.host if request.client else None)
    db.commit()
    return safe(row) | {"revoked_sessions": revoked}
