import re
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from app.core.config import settings
from app.core.deps import require_permission, require_production_license
from app.models.admin import Admin

router = APIRouter(prefix="/media", tags=["media"])

ALLOWED = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}

MAGIC_BYTES = {
    "image/jpeg": lambda data: data.startswith(b"\xff\xd8\xff"),
    "image/png": lambda data: data.startswith(b"\x89PNG\r\n\x1a\n"),
    "image/webp": lambda data: len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP",
}


def media_root() -> Path:
    root = Path(settings.media_dir)
    root.mkdir(parents=True, exist_ok=True)
    return root


@router.post("/images")
async def upload_image(
    file: UploadFile = File(...),
    admin: Admin = Depends(require_permission("raffle:write")),
    license_state=Depends(require_production_license),
):
    content_type = (file.content_type or "").lower()
    suffix = ALLOWED.get(content_type)
    if not suffix:
        raise HTTPException(415, "Usa una imagen JPG, PNG o WEBP")

    data = await file.read(settings.max_image_upload_bytes + 1)
    if len(data) > settings.max_image_upload_bytes:
        raise HTTPException(413, f"La imagen no puede superar {settings.max_image_upload_bytes // (1024 * 1024)} MB")
    if not data:
        raise HTTPException(400, "La imagen está vacía")
    if not MAGIC_BYTES[content_type](data):
        raise HTTPException(415, "El archivo no coincide con el formato de imagen declarado")

    original = Path(file.filename or "imagen").stem
    safe = re.sub(r"[^A-Za-z0-9_-]+", "-", original).strip("-")[:40] or "imagen"
    name = f"{safe}-{uuid.uuid4().hex[:16]}{suffix}"
    path = media_root() / name
    path.write_bytes(data)
    return {"url": f"/media/{name}", "filename": name, "content_type": content_type, "size": len(data)}
