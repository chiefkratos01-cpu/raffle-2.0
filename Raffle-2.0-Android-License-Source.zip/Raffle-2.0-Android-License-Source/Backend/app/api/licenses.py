from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_admin_roles, require_permission
from app.models.admin import Admin
from app.models.enums import AdminRole
from app.models.license import License
from app.services.audit_service import record_audit
from app.services.license_service import activate_license, license_public_status

router = APIRouter(prefix="/license", tags=["license"])


class ActivateLicenseRequest(BaseModel):
    license_key: str = Field(min_length=20, max_length=4096)
    installation_id: str | None = Field(default=None, min_length=8, max_length=128)


class LicenseStatusUpdate(BaseModel):
    status: Literal["ACTIVE", "SUSPENDED", "REVOKED"]
    reason: str | None = Field(default=None, max_length=2000)


@router.get("/status")
def status(db: Session = Depends(get_db), admin: Admin = Depends(require_permission("license:read"))):
    return license_public_status(db)


@router.post("/activate")
def activate(
    data: ActivateLicenseRequest,
    request: Request,
    admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN, AdminRole.ADMIN)),
    db: Session = Depends(get_db),
):
    try:
        row = activate_license(db, data.license_key, data.installation_id)
        record_audit(
            db, actor_admin_id=admin.id, action="LICENSE_ACTIVATED", entity_type="LICENSE",
            entity_id=row.id, new_value={"external_license_id": row.external_license_id, "status": row.status},
            ip_address=request.client.host if request.client else None,
        )
        db.commit()
        db.refresh(row)
        return license_public_status(db) | {"license_id": row.external_license_id or row.id}
    except ValueError as exc:
        db.rollback()
        raise HTTPException(400, str(exc))


@router.post("/{license_id}/status")
def update_status(
    license_id: str,
    data: LicenseStatusUpdate,
    request: Request,
    admin: Admin = Depends(require_admin_roles(AdminRole.SUPER_ADMIN)),
    db: Session = Depends(get_db),
):
    row = db.scalar(select(License).where(License.external_license_id == license_id).with_for_update())
    if not row:
        raise HTTPException(404, "Licencia no encontrada")
    if data.status == "ACTIVE" and row.status == "REVOKED":
        raise HTTPException(409, "Una licencia revocada no puede reactivarse con la misma clave")
    if data.status == "ACTIVE" and row.expires_at is not None:
        from datetime import datetime, timezone
        expires = row.expires_at if row.expires_at.tzinfo else row.expires_at.replace(tzinfo=timezone.utc)
        if expires <= datetime.now(timezone.utc):
            raise HTTPException(409, "Una licencia vencida requiere una nueva emisión")
    old_status = row.status
    row.status = data.status
    from datetime import datetime, timezone
    row.last_checked_at = datetime.now(timezone.utc)
    record_audit(
        db,
        actor_admin_id=admin.id,
        action="LICENSE_STATUS_CHANGED",
        entity_type="LICENSE",
        entity_id=row.id,
        old_value={"status": old_status},
        new_value={"status": data.status, "reason": data.reason},
        ip_address=request.client.host if request.client else None,
    )
    db.commit()
    return {"license_id": row.external_license_id, "license_status": row.status}
