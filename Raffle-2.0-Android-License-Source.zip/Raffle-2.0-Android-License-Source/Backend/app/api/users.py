from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.ticket import Ticket
from app.models.enums import TicketStatus
from app.models.notification import Notification
from app.schemas.notification import NotificationResponse
router=APIRouter(prefix="/users",tags=["users"])
@router.get("/tickets")
def tickets(user:User=Depends(get_current_user),db:Session=Depends(get_db)):
    rows=db.scalars(select(Ticket).where(Ticket.user_id==user.id,Ticket.status==TicketStatus.PAID).order_by(Ticket.paid_at.desc())).all()
    return [{"id":t.id,"raffle_id":t.raffle_id,"number":t.number,"status":t.status,"verification_code":t.verification_code,"paid_at":t.paid_at} for t in rows]
@router.get("/notifications",response_model=list[NotificationResponse])
def notifications(user:User=Depends(get_current_user),db:Session=Depends(get_db)): return db.scalars(select(Notification).where(Notification.user_id==user.id).order_by(Notification.created_at.desc()).limit(100)).all()
@router.post("/notifications/{notification_id}/read")
def read(notification_id:int,user:User=Depends(get_current_user),db:Session=Depends(get_db)):
    n=db.scalar(select(Notification).where(Notification.id==notification_id,Notification.user_id==user.id))
    if not n: raise HTTPException(404,"Notification not found")
    n.is_read=True; db.commit(); return {"ok":True}
