from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.reservation import Reservation
from app.models.raffle import Raffle
from app.schemas.reservation import ReservationCreate, ReservationResponse, PaymentSubmit
from app.services.reservation_service import create_reservation, submit_payment, release_expired
from app.realtime.events import emit_raffle_update

router = APIRouter(prefix="/reservations", tags=["reservations"])

def response(r):
    return ReservationResponse(id=r.id, code=r.code, raffle_id=r.raffle_id, user_id=r.user_id, status=r.status, expires_at=r.expires_at, created_at=r.created_at, tickets=r.tickets, payment_status=r.payment.status if r.payment else None, payment_amount=r.payment.amount if r.payment else None)

@router.post("", response_model=ReservationResponse)
def reserve(data: ReservationCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    raffle = db.get(Raffle, data.raffle_id)
    if not raffle: raise HTTPException(404, "Raffle not found")
    try:
        result = create_reservation(db, raffle, user.id, data.numbers, commit=False)
        db.commit()
        emit_raffle_update(raffle.id, {'type': 'tickets_changed', 'raffle_id': raffle.id})
        return response(result)
    except ValueError as exc: raise HTTPException(409, str(exc))

@router.get("/mine", response_model=list[ReservationResponse])
def mine(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    reservations = db.scalars(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment)).where(Reservation.user_id == user.id).order_by(Reservation.created_at.desc())).all()
    for r in reservations: release_expired(db, r.raffle_id)
    return [response(r) for r in reservations]

@router.post("/{reservation_id}/payment", response_model=ReservationResponse)
def payment(reservation_id: int, data: PaymentSubmit, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.scalar(select(Reservation).options(selectinload(Reservation.tickets), selectinload(Reservation.payment)).where(Reservation.id == reservation_id, Reservation.user_id == user.id))
    if not r: raise HTTPException(404, "Reservation not found")
    try:
        result = submit_payment(db, r, data, commit=False)
        db.commit()
        emit_raffle_update(r.raffle_id, {'type': 'reservation_payment_review', 'raffle_id': r.raffle_id})
        return response(result)
    except ValueError as exc: raise HTTPException(409, str(exc))
