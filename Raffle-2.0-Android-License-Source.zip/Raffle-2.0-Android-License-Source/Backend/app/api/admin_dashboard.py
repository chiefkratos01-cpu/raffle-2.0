from fastapi import APIRouter,Depends
from sqlalchemy import select,func
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.deps import require_permission
from app.models.admin import Admin
from app.models.raffle import Raffle
from app.models.user import User
from app.models.ticket import Ticket
from app.models.payment import Payment
from app.models.enums import TicketStatus,PaymentStatus,RaffleStatus
from app.services.license_service import license_public_status
router=APIRouter(prefix="/admin/dashboard",tags=["admin-dashboard"])
@router.get("/summary")
def summary(admin:Admin=Depends(require_permission("dashboard:read")),db:Session=Depends(get_db)):
    return {"raffles":db.scalar(select(func.count(Raffle.id)).where(Raffle.is_demo.is_(False))) or 0,"open_raffles":db.scalar(select(func.count(Raffle.id)).where(Raffle.is_demo.is_(False), Raffle.status.in_([RaffleStatus.OPEN,RaffleStatus.LOW_TICKETS]))) or 0,"users":db.scalar(select(func.count(User.id))) or 0,"paid_tickets":db.scalar(select(func.count(Ticket.id)).join(Raffle, Ticket.raffle_id == Raffle.id).where(Raffle.is_demo.is_(False), Ticket.status==TicketStatus.PAID)) or 0,"pending_payments":db.scalar(select(func.count(Payment.id)).where(Payment.status==PaymentStatus.PENDING)) or 0}
@router.get("/raffles")
def raffles(admin:Admin=Depends(require_permission("dashboard:read")),db:Session=Depends(get_db)): return db.scalars(select(Raffle).where(Raffle.is_demo.is_(False)).order_by(Raffle.created_at.desc())).all()

@router.get("/license")
def license_status(admin:Admin=Depends(require_permission("dashboard:read")),db:Session=Depends(get_db)): return license_public_status(db)
