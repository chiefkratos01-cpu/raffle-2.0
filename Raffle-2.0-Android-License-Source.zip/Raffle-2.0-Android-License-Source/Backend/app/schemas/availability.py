from pydantic import BaseModel, Field

class TicketAvailabilityResponse(BaseModel):
    raffle_id: int
    total_tickets: int
    start: int
    end: int
    occupied: list[int] = Field(default_factory=list)
