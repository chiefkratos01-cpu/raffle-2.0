from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.enums import TicketStatus

class TicketVerificationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    raffle_title: str
    ticket_number: int
    status: TicketStatus
    verification_code: str
    paid_at: datetime | None
    is_winner: bool
    prize_position: int | None = None
    prize_description: str | None = None
    winner_verification_code: str | None = None
