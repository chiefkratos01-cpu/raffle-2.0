from datetime import datetime
from decimal import Decimal
from pydantic import BaseModel, Field, ConfigDict
from app.models.enums import ReservationStatus, PaymentMethod, PaymentStatus, TicketStatus

class ReservationCreate(BaseModel):
    raffle_id: int
    numbers: list[int] = Field(min_length=1, max_length=1000)

class PaymentSubmit(BaseModel):
    method: PaymentMethod | None = None
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = None

class PaymentDecision(BaseModel):
    method: PaymentMethod | None = None
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = None
    rejection_reason: str | None = Field(default=None, max_length=255)

class TicketResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    number: int
    status: TicketStatus
    verification_code: str | None = None

class ReservationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    raffle_id: int
    user_id: int
    status: ReservationStatus
    expires_at: datetime | None
    created_at: datetime
    tickets: list[TicketResponse]
    payment_status: PaymentStatus | None = None
    payment_amount: Decimal | None = None
