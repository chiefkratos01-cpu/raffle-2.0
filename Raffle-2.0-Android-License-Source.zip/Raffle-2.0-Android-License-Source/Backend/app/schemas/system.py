from datetime import datetime
from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str
    timestamp: datetime
    database: str | None = None
    database_latency_ms: float | None = None


class LivenessResponse(BaseModel):
    status: str
    version: str
    timestamp: datetime
