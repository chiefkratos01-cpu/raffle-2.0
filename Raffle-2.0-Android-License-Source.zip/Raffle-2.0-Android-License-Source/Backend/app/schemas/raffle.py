from datetime import datetime
from decimal import Decimal
import re

from pydantic import BaseModel, Field, ConfigDict, field_validator

from app.models.enums import RaffleStatus


PHONE_RE = re.compile(r"^\+?[0-9][0-9 ()\-]{6,19}$")


class PrizeInput(BaseModel):
    position: int = Field(ge=1)
    title: str = Field(min_length=1, max_length=200)
    description: str | None = None
    image: str | None = None
    value: Decimal | None = None


class RaffleCreate(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    description: str | None = None
    image: str | None = None
    total_tickets: int = Field(gt=0, le=1_000_000)
    ticket_price: Decimal = Field(gt=0)
    currency: str = Field(default="CUP", min_length=1, max_length=10)
    draw_date: datetime | None = None
    winner_count: int = Field(default=1, ge=1, le=100)
    max_tickets_per_user: int | None = Field(default=None, gt=0)
    allow_multiple_wins: bool = False
    auto_release_enabled: bool = False
    reservation_minutes: int | None = Field(default=None, ge=1, le=1440)
    low_ticket_threshold: int = Field(default=10, ge=0)
    rules: str | None = None
    payment_instructions: str | None = None
    organizer_name: str | None = None
    organizer_whatsapp: str | None = None
    organizer_phone: str | None = None
    prizes: list[PrizeInput] = Field(default_factory=list)

    @field_validator("organizer_phone", "organizer_whatsapp")
    @classmethod
    def validate_organizer_phone(cls, value):
        if value is None or not value.strip():
            return None
        value = value.strip()
        if not PHONE_RE.fullmatch(value):
            raise ValueError("Introduce un número de teléfono válido para el organizador.")
        return value


class RaffleUpdate(RaffleCreate):
    pass


class PrizeResponse(PrizeInput):
    model_config = ConfigDict(from_attributes=True)
    id: int


class RaffleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    slug: str
    description: str | None
    image: str | None
    is_demo: bool
    total_tickets: int
    tickets_sold: int
    ticket_price: Decimal
    currency: str
    status: RaffleStatus
    draw_date: datetime | None
    winner_count: int
    max_tickets_per_user: int | None
    allow_multiple_wins: bool
    auto_release_enabled: bool
    reservation_minutes: int | None
    low_ticket_threshold: int
    rules: str | None
    payment_instructions: str | None
    organizer_name: str | None
    organizer_whatsapp: str | None
    organizer_phone: str | None
    prizes: list[PrizeResponse]
