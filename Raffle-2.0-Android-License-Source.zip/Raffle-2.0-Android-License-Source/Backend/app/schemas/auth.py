from pydantic import BaseModel, Field, field_validator
import re

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    phone: str | None = Field(default=None, max_length=40)
    email: str | None = Field(default=None, max_length=255)
    password: str = Field(min_length=12, max_length=128)

    @field_validator("password")
    @classmethod
    def strong_password(cls, value):
        if any(ch.isspace() for ch in value) or len(set(value)) < 5:
            raise ValueError("La contraseña debe tener al menos 12 caracteres variados y no contener espacios.")
        return value

class LoginRequest(BaseModel):
    identifier: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=128)

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=32, max_length=512)

class LogoutRequest(BaseModel):
    refresh_token: str | None = Field(default=None, max_length=512)

class MeResponse(BaseModel):
    id: int
    name: str
    phone: str | None
    email: str | None


class SessionResponse(BaseModel):
    id: int
    subject_type: str
    created_at: str
    expires_at: str
    last_used_at: str | None
    ip_address: str | None
    user_agent: str | None
    current: bool = False


class RevokeAllResponse(BaseModel):
    ok: bool
    revoked: int
