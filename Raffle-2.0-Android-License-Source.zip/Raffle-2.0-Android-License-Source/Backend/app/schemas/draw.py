from datetime import datetime
from pydantic import BaseModel, ConfigDict
from app.models.enums import DrawStatus


class DrawRequest(BaseModel):
    prize_position: int


class DrawResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    raffle_id: int
    status: DrawStatus
    prize_position: int
    winning_ticket_id: int | None
    animation_seed: str | None
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    randomness_commitment: str | None
    eligible_pool_hash: str | None
    result_hash: str | None
    eligible_count: int | None
    selection_algorithm: str | None


class WinnerResponse(BaseModel):
    id: int
    raffle_id: int
    draw_id: int
    ticket_id: int
    user_id: int
    ticket_number: int
    prize_position: int
    prize_description: str | None
    verification_code: str
    created_at: datetime
    animation_seed: str | None = None
    randomness_commitment: str | None = None
    eligible_pool_hash: str | None = None
    result_hash: str | None = None
    eligible_count: int | None = None
    selection_algorithm: str | None = None


class PublicWinnerResponse(BaseModel):
    id: int
    raffle_id: int
    draw_id: int
    ticket_number: int
    prize_position: int
    prize_description: str | None
    verification_code: str
    created_at: datetime
    animation_seed: str | None = None
    randomness_commitment: str | None = None
    eligible_pool_hash: str | None = None
    result_hash: str | None = None
    eligible_count: int | None = None
    selection_algorithm: str | None = None


class PublicDrawResponse(BaseModel):
    id: int
    raffle_id: int
    status: DrawStatus
    prize_position: int
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    randomness_commitment: str | None = None
    eligible_pool_hash: str | None = None
    result_hash: str | None = None
    eligible_count: int | None = None
    selection_algorithm: str | None = None
