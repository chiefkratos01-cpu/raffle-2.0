import socketio
from datetime import datetime, timezone
from jose import JWTError, jwt
from sqlalchemy import select

from app.core.config import settings
from app.core.database import SessionLocal
from app.models.auth_session import AuthSession
from app.models.user import User
from app.models.raffle import Raffle
from app.models.enums import RaffleStatus

sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins=settings.cors_origin_list or ["*"],
)

MAX_RAFFLE_ROOMS_PER_SOCKET = 20


def _authenticated_user(auth):
    """Return the authenticated active user id, or None.

    Socket authentication is tied to the same server-side AuthSession used by
    HTTP requests. A valid JWT alone is not enough after logout/revocation.
    """
    if not isinstance(auth, dict):
        return None
    token = auth.get("token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
        if payload.get("role") != "USER":
            return None
        user_id = int(payload.get("sub"))
        session_id = int(payload.get("sid"))
    except (JWTError, TypeError, ValueError, KeyError):
        return None

    with SessionLocal() as db:
        session = db.scalar(
            select(AuthSession).where(
                AuthSession.id == session_id,
                AuthSession.subject_type == "USER",
                AuthSession.subject_id == user_id,
            )
        )
        now = datetime.now(timezone.utc)
        expires_at = session.expires_at
        if expires_at is not None and expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if not session or session.revoked_at or not expires_at or expires_at <= now:
            return None
        user = db.get(User, user_id)
        if not user or not user.is_active:
            return None
        return user_id


@sio.event
async def connect(sid, environ, auth):
    user_id = _authenticated_user(auth)
    await sio.save_session(sid, {"user_id": user_id, "raffle_rooms": set()})
    if user_id is not None:
        await sio.enter_room(sid, f"user:{user_id}")
    return True


@sio.event
async def join_raffle(sid, data):
    try:
        raffle_id = int(data.get("raffle_id"))
    except (TypeError, ValueError, AttributeError):
        return {"ok": False, "error": "Invalid raffle_id"}
    if raffle_id <= 0:
        return {"ok": False, "error": "Invalid raffle_id"}

    with SessionLocal() as db:
        raffle = db.get(Raffle, raffle_id)
        public_states = {
            RaffleStatus.OPEN,
            RaffleStatus.LOW_TICKETS,
            RaffleStatus.SOLD_OUT,
            RaffleStatus.DRAW_SCHEDULED,
            RaffleStatus.DRAWING,
            RaffleStatus.COMPLETED,
        }
        if not raffle or raffle.is_demo or raffle.status not in public_states:
            return {"ok": False, "error": "Raffle not available"}

    session = await sio.get_session(sid)
    rooms = session.setdefault("raffle_rooms", set())
    key = str(raffle_id)
    if key not in rooms and len(rooms) >= MAX_RAFFLE_ROOMS_PER_SOCKET:
        return {"ok": False, "error": "Too many raffle subscriptions"}

    await sio.enter_room(sid, f"raffle:{raffle_id}")
    rooms.add(key)
    await sio.save_session(sid, session)
    return {"ok": True, "raffle_id": raffle_id}


@sio.event
async def leave_raffle(sid, data):
    try:
        raffle_id = int(data.get("raffle_id"))
    except (TypeError, ValueError, AttributeError):
        return {"ok": False}
    if raffle_id <= 0:
        return {"ok": False}
    await sio.leave_room(sid, f"raffle:{raffle_id}")
    session = await sio.get_session(sid)
    rooms = session.setdefault("raffle_rooms", set())
    rooms.discard(str(raffle_id))
    await sio.save_session(sid, session)
    return {"ok": True}


@sio.event
async def disconnect(sid):
    pass


@sio.event
async def error(sid, data):
    return
