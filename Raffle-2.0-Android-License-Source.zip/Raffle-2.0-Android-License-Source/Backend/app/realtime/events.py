"""Small bridge from synchronous API handlers to the async Socket.IO server."""
from anyio import from_thread
from .socket import sio


def _emit(event: str, payload: dict, room: str):
    async def _send():
        await sio.emit(event, payload, room=room)
    try:
        from_thread.run(_send)
        return True
    except Exception:
        return False


def emit_raffle_update(raffle_id: int, payload: dict):
    """Best-effort realtime update. Database state remains authoritative."""
    return _emit("raffle_update", payload, f"raffle:{raffle_id}")


def emit_user_notification(user_id: int, payload: dict):
    """Deliver a notification only to the authenticated user's private room."""
    return _emit("notification", payload, f"user:{user_id}")


def emit_draw_result(raffle_id: int, payload: dict):
    """Publish an authoritative draw result from synchronous API code."""
    return _emit("draw_result", payload, f"raffle:{raffle_id}")
