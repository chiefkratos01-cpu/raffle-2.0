from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import uuid
import secrets
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from app.core.config import settings
from app.core.database import Base, engine, SessionLocal
from app.core.security import hash_password
from app.models import Admin, Raffle, Prize
from app.models.enums import AdminRole, RaffleStatus
from app.api.system import router as system_router
from app.api.licenses import router as license_router
from app.api.auth import router as auth_router
from app.api.raffles import router as raffle_router
from app.api.reservations import router as reservation_router
from app.api.admin import router as admin_router
from app.api.admin_dashboard import router as dashboard_router
from app.api.users import router as users_router
from app.api.draws import router as draws_router
from app.api.audit import router as audit_router
from app.api.admin_security import router as admin_security_router
from app.api.tickets import router as tickets_router
from app.api.notifications import router as notifications_router
from app.api.organizers import router as organizer_router, admin_router as admin_organizer_router
from app.api.team import router as team_router
from app.api.admin_users import router as admin_users_router
from app.api.media import router as media_router, media_root
from app.api.demo import router as demo_router
from app.services.license_service import ensure_development_trial
from app.realtime.socket import sio
from app.core.rate_limit import limiter, rule_for
import socketio

@asynccontextmanager
async def lifespan(app: FastAPI):
    if settings.environment == "development":
        Base.metadata.create_all(bind=engine)
        with SessionLocal() as db:
            admin_password = settings.demo_admin_password
            if admin_password in {"CHANGE_ME_ADMIN_PASSWORD", "", "change-this-password"}:
                admin_password = secrets.token_urlsafe(12)
                print(f"[Raffle 2.0] Development admin credentials: {settings.demo_admin_username} / {admin_password}")
            admin = db.scalar(select(Admin).where(Admin.username == settings.demo_admin_username))
            if admin is None:
                db.add(Admin(username=settings.demo_admin_username, password_hash=hash_password(admin_password), role=AdminRole.SUPER_ADMIN, is_active=True))
                db.commit()
            elif settings.environment.lower() == "development":
                admin.password_hash = hash_password(admin_password)
                admin.role = AdminRole.SUPER_ADMIN
                admin.is_active = True
                db.commit()
            if settings.environment.lower() == "development":
                ensure_development_trial(db)
            if settings.demo_mode and db.scalar(select(Raffle.id).where(Raffle.is_demo.is_(True))) is None:
                demo = Raffle(
                    title="Rifa de demostración", slug="rifa-de-demostracion", description="Un entorno interactivo para conocer Raffle 2.0 sin afectar ninguna rifa real.",
                    image="/assets/demo/demo-ticket.webp", total_tickets=50, ticket_price=10, currency="CUP", status=RaffleStatus.OPEN, is_demo=True, winner_count=1,
                    max_tickets_per_user=3, allow_multiple_wins=False, auto_release_enabled=True, reservation_minutes=10,
                    low_ticket_threshold=5, rules="Esta rifa es solo de demostración. Los participantes, boletos, pagos y resultados son ficticios.",
                    payment_instructions="Demo interactiva: no realices pagos.", organizer_name="Raffle 2.0"
                )
                demo.prizes.append(Prize(position=1, title="Premio de demostración", description="Un premio ficticio para explorar el recorrido del sorteo.", image="/assets/demo-prize.webp"))
                db.add(demo)
                db.commit()
    yield

app = FastAPI(title=settings.app_name, version=settings.app_version, description="Raffle management platform v2.", docs_url="/docs" if settings.docs_enabled else None, redoc_url="/redoc" if settings.docs_enabled else None, openapi_url="/openapi.json" if settings.docs_enabled else None, lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True, allow_methods=["GET","POST","PUT","PATCH","DELETE","OPTIONS"], allow_headers=["Authorization","Content-Type","X-Request-ID"])
app.include_router(system_router, prefix="/api/v1")
app.include_router(license_router, prefix="/api/v1")
app.include_router(auth_router, prefix="/api/v1")
app.include_router(raffle_router, prefix="/api/v1")
app.include_router(reservation_router, prefix="/api/v1")
app.include_router(admin_router, prefix="/api/v1")
app.include_router(draws_router, prefix="/api/v1")
app.include_router(tickets_router, prefix="/api/v1")
app.include_router(notifications_router, prefix="/api/v1")
app.include_router(organizer_router, prefix="/api/v1")
app.include_router(admin_organizer_router, prefix="/api/v1")
app.include_router(team_router, prefix="/api/v1")
app.include_router(admin_users_router, prefix="/api/v1")
app.include_router(media_router, prefix="/api/v1")
app.include_router(demo_router, prefix="/api/v1")
app.mount("/media", StaticFiles(directory=str(media_root()), check_dir=False), name="media")
app.include_router(users_router, prefix="/api/v1")
app.include_router(dashboard_router, prefix="/api/v1")
app.include_router(audit_router, prefix="/api/v1")
app.include_router(admin_security_router, prefix="/api/v1")
app.mount("/socket.io", socketio.ASGIApp(sio))


@app.middleware("http")
async def abuse_protection(request: Request, call_next):
    # Do not trust X-Forwarded-For here unless a trusted proxy layer is
    # explicitly configured. request.client is the transport peer.
    client_host = request.client.host if request.client else "unknown"
    rule = rule_for(request.url.path, request.method)
    if not settings.rate_limit_enabled:
        response = await call_next(request)
        response.headers.setdefault("X-Request-ID", request.headers.get("X-Request-ID", uuid.uuid4().hex))
        return response
    key = f"{client_host}:{request.method}:{request.url.path.split("?", 1)[0]}"
    allowed, retry_after = limiter.check(key, rule)
    if not allowed:
        return JSONResponse(
            status_code=429,
            content={"detail": "Too many requests. Try again later."},
            headers={"Retry-After": str(retry_after), "Cache-Control": "no-store"},
        )
    limiter.cleanup()
    response = await call_next(request)
    response.headers.setdefault("X-Request-ID", request.headers.get("X-Request-ID", uuid.uuid4().hex))
    response.headers.setdefault("X-RateLimit-Limit", str(rule.limit))
    return response


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if request.url.path.startswith("/api/v1/auth/"):
        response.headers.setdefault("Cache-Control", "no-store")
    if settings.environment.lower() == "production":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; "
            "base-uri 'self'; "
            "object-src 'none'; "
            "frame-ancestors 'none'; "
            "form-action 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob: https:; "
            "font-src 'self' data:; "
            "connect-src 'self' https: wss:;",
        )
    return response


@app.get("/")
def root(): return {"name": settings.app_name, "version": settings.app_version, "status": "running"}
