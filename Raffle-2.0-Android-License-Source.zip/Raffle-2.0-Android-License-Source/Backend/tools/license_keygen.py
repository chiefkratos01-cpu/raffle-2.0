#!/usr/bin/env python3
"""Raffle 2.0 Ed25519 key generator. Never bundle or publish the private signing key."""
import argparse
import base64
import getpass
import json
import os
import secrets
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

TOOL_DIR = Path(__file__).resolve().parent
DEFAULTS_PATH = TOOL_DIR / "license_defaults.json"
STANDARD_LIMITS = (
    "max_active_raffles",
    "max_tickets_per_raffle",
    "max_team_accounts",
    "max_organizers",
)
KEY_FORMAT = "raffle-ed25519-encrypted-v1"


def b64e(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def utc_iso(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_date(value: str | None, field: str) -> datetime | None:
    if value is None or value == "":
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except ValueError as exc:
        raise ValueError(f"Fecha no válida para {field}; utiliza ISO 8601 con zona horaria.") from exc


def _fernet_key(passphrase: str, salt: bytes) -> bytes:
    if len(passphrase) < 12:
        raise ValueError("La frase de desbloqueo debe tener al menos 12 caracteres.")
    derived = Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(passphrase.encode("utf-8"))
    return base64.urlsafe_b64encode(derived)


def encrypt_private_key(private_key: Ed25519PrivateKey, passphrase: str) -> dict:
    salt = os.urandom(16)
    raw = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    ciphertext = Fernet(_fernet_key(passphrase, salt)).encrypt(raw)
    return {"format": KEY_FORMAT, "kdf": "scrypt-n32768-r8-p1", "salt": b64e(salt), "ciphertext": b64e(ciphertext)}


def load_private_key(path: Path | str, passphrase: str | None = None) -> Ed25519PrivateKey:
    path = Path(path)
    content = path.read_text(encoding="utf-8").strip()
    if content.startswith("{"):
        envelope = json.loads(content)
        if envelope.get("format") != KEY_FORMAT:
            raise ValueError("Formato de archivo de clave no compatible.")
        password = passphrase if passphrase is not None else getpass.getpass("Frase para desbloquear la clave privada: ")
        try:
            raw = Fernet(_fernet_key(password, b64d(envelope["salt"]))).decrypt(b64d(envelope["ciphertext"]))
        except (InvalidToken, KeyError, ValueError) as exc:
            raise ValueError("No se pudo desbloquear la clave privada; revisa la frase.") from exc
        return Ed25519PrivateKey.from_private_bytes(raw)
    # Read older plaintext keys for migration; all newly generated keys are encrypted.
    print("ADVERTENCIA: clave privada heredada sin cifrar. Rótala y vuelve a emitir las licencias.", file=sys.stderr)
    return Ed25519PrivateKey.from_private_bytes(b64d(content))


def write_private_key(path: Path | str, private_key: Ed25519PrivateKey, passphrase: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(encrypt_private_key(private_key, passphrase), separators=(",", ":")) + "\n", encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def write_public_key(path: Path | str, private_key: Ed25519PrivateKey) -> str:
    path = Path(path)
    raw = private_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    encoded = b64e(raw)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(encoded + "\n", encoding="utf-8")
    return encoded


def load_defaults(path: Path | str | None = None) -> dict:
    target = Path(path) if path else DEFAULTS_PATH
    if not target.exists():
        return {"product": "raffle", "trial": {}, "limits": {}, "features": {}}
    value = json.loads(target.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("El archivo de configuración Keygen debe ser un objeto JSON.")
    return value


def parse_limit(value, field: str):
    if value is None:
        raise ValueError(f"Falta el valor {field}; cada límite firmado debe ser un entero no negativo.")
    if isinstance(value, str):
        normalized = value.strip().lower()
        if not normalized:
            raise ValueError(f"Falta el valor {field}; cada límite firmado debe ser un entero no negativo.")
        try:
            value = int(normalized)
        except ValueError as exc:
            raise ValueError(f"El límite {field} debe ser un entero no negativo.") from exc
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"El límite {field} debe ser un entero no negativo.")
    return value


def build_payload(*, license_type: str, organization_id: str, private_key_path: Path | str,
                  passphrase: str | None = None, license_id: str | None = None, organizer_id: str | None = None,
                  issued_at: str | None = None, starts_at: str | None = None, expires_at: str | None = None,
                  days: int | None = None, license_status: str = "ACTIVE", limits: dict | None = None,
                  features: dict | None = None, installation_id: str | None = None, product: str = "raffle") -> dict:
    license_type = license_type.upper()
    license_status = license_status.upper()
    if license_type not in {"TRIAL", "COMMERCIAL"}:
        raise ValueError("El tipo debe ser TRIAL o COMMERCIAL.")
    if license_status not in {"ACTIVE", "SUSPENDED", "REVOKED"}:
        raise ValueError("El estado debe ser ACTIVE, SUSPENDED o REVOKED.")
    if not organization_id.strip():
        raise ValueError("organization_id es obligatorio.")
    if days is not None and expires_at:
        raise ValueError("Utiliza --days o --expires-at, no ambos.")
    if license_type == "TRIAL" and days is None and not expires_at:
        raise ValueError("TRIAL requiere --days o --expires-at; la duración no tiene un valor fijo.")
    if license_type == "TRIAL" and days is not None and days <= 0:
        raise ValueError("La duración de TRIAL debe ser de al menos un día.")
    if days is not None and days < 0:
        raise ValueError("--days no puede ser negativo.")

    key = load_private_key(private_key_path, passphrase)
    now = datetime.now(timezone.utc)
    issued = parse_date(issued_at, "issued_at") or now
    starts = parse_date(starts_at, "starts_at") or issued
    expires = parse_date(expires_at, "expires_at")
    if days is not None:
        expires = starts + timedelta(days=days)
    if expires is not None and expires <= starts:
        raise ValueError("expires_at debe ser posterior a starts_at.")

    source = limits or {}
    missing_limits = [name for name in STANDARD_LIMITS if name not in source]
    if missing_limits:
        raise ValueError("Configura explícitamente todos los límites firmados: " + ", ".join(missing_limits))
    normalized_limits = {name: parse_limit(source.get(name), name) for name in STANDARD_LIMITS}
    extra_limits = source.get("limits", {})
    if not isinstance(extra_limits, dict):
        raise ValueError("limits adicionales debe ser un objeto JSON.")
    normalized_extra = {str(name): parse_limit(value, str(name)) for name, value in extra_limits.items()}
    feature_map = features if features is not None else source.get("features", {})
    if not isinstance(feature_map, dict):
        raise ValueError("features debe ser un objeto JSON.")

    payload = {
        "schema_version": 2,
        "license_id": license_id or f"RFL-{secrets.token_hex(8).upper()}",
        "product": product,
        "license_type": license_type,
        "organization_id": organization_id.strip(),
        "organizer_id": organizer_id.strip() if organizer_id else None,
        "issued_at": utc_iso(issued),
        "starts_at": utc_iso(starts),
        "expires_at": utc_iso(expires) if expires else None,
        "license_status": license_status,
        "max_active_raffles": normalized_limits["max_active_raffles"],
        "max_tickets_per_raffle": normalized_limits["max_tickets_per_raffle"],
        "max_team_accounts": normalized_limits["max_team_accounts"],
        "max_organizers": normalized_limits["max_organizers"],
        "limits": normalized_extra,
        "features": feature_map,
        "installation_id": installation_id,
    }
    return payload


def sign_payload(payload: dict, private_key: Ed25519PrivateKey) -> str:
    encoded_payload = b64e(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
    signature = b64e(private_key.sign(encoded_payload.encode("ascii")))
    return encoded_payload + "." + signature


def verify_token(token: str, public_key: Ed25519PublicKey) -> dict:
    parts = token.strip().split(".")
    if len(parts) != 2:
        raise ValueError("Formato de licencia no válido.")
    public_key.verify(b64d(parts[1]), parts[0].encode("ascii"))
    return json.loads(b64d(parts[0]).decode("utf-8"))


def init(args) -> None:
    private_path = Path(args.private_key)
    public_path = Path(args.public_key)
    if private_path.exists() and not args.force:
        raise SystemExit(f"{private_path} ya existe. Usa --force para reemplazarla.")
    if args.passphrase:
        password = args.passphrase
    else:
        password = getpass.getpass("Crea una frase para cifrar la clave privada (mínimo 12 caracteres): ")
        confirmation = getpass.getpass("Repite la frase: ")
        if password != confirmation:
            raise SystemExit("Las frases no coinciden.")
    private_key = Ed25519PrivateKey.generate()
    write_private_key(private_path, private_key, password)
    public_key = write_public_key(public_path, private_key)
    print(f"Clave privada cifrada: {private_path}")
    print(f"Clave pública: {public_path}")
    print(f"Public key (LICENSE_PUBLIC_KEY / REACT_APP_LICENSE_PUBLIC_KEY): {public_key}")
    print("Mantén la frase y la clave privada fuera del proyecto distribuido y de los APK.")


def _issue_limits(args, defaults: dict) -> dict:
    issue_type = args.type.upper()
    configured = {}
    section_name = "trial" if issue_type == "TRIAL" else "commercial"
    section = defaults.get(section_name, {})
    if not isinstance(section, dict):
        raise ValueError(f"La sección {section_name} de license_defaults.json debe ser un objeto.")
    configured.update(section)
    limits_file = Path(args.limits_json) if args.limits_json else None
    if limits_file:
        loaded = json.loads(limits_file.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            raise ValueError("El archivo de límites debe contener un objeto JSON.")
        configured.update(loaded)
    for name in STANDARD_LIMITS:
        value = getattr(args, name)
        if value is not None:
            configured[name] = value
    return configured


def issue(args) -> None:
    defaults = load_defaults(args.defaults)
    configured = _issue_limits(args, defaults)
    password = args.passphrase or getpass.getpass("Frase para desbloquear la clave privada: ")
    duration_days = args.days
    if args.type.upper() == "TRIAL" and duration_days is None and not args.expires_at:
        duration_days = defaults.get("trial_duration_days")
    payload = build_payload(
        license_type=args.type,
        organization_id=args.organization_id,
        private_key_path=args.private_key,
        passphrase=password,
        license_id=args.license_id,
        organizer_id=args.organizer_id,
        issued_at=args.issued_at,
        starts_at=args.starts_at,
        expires_at=args.expires_at,
        days=duration_days,
        license_status=args.status,
        limits=configured,
        features=json.loads(args.features_json) if args.features_json else configured.get("features", defaults.get("features", {})),
        installation_id=args.installation_id,
        product=args.product or defaults.get("product", "raffle"),
    )
    key = load_private_key(args.private_key, password)
    token = sign_payload(payload, key)
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(token + "\n", encoding="utf-8")
        print(f"Licencia firmada guardada en: {args.output}")
    print(token)


def verify(args) -> None:
    public = Ed25519PublicKey.from_public_bytes(b64d(Path(args.public_key).read_text(encoding="utf-8").strip()))
    token = Path(args.license_file).read_text(encoding="utf-8").strip()
    print(json.dumps(verify_token(token, public), ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Raffle 2.0 Ed25519 license key generator")
    commands = parser.add_subparsers(required=True)

    init_parser = commands.add_parser("init", help="Generate an encrypted Ed25519 signing key and public key")
    init_parser.add_argument("--private-key", default="private/license_private.key")
    init_parser.add_argument("--public-key", default="public/license_public.key")
    init_parser.add_argument("--force", action="store_true")
    init_parser.add_argument("--passphrase", help=argparse.SUPPRESS)
    init_parser.set_defaults(fn=init)

    issue_parser = commands.add_parser("issue", help="Issue a schema-v2 signed license")
    issue_parser.add_argument("--private-key", default="private/license_private.key")
    issue_parser.add_argument("--passphrase", help=argparse.SUPPRESS)
    issue_parser.add_argument("--type", choices=["TRIAL", "COMMERCIAL"], required=True)
    issue_parser.add_argument("--organization-id", required=True)
    issue_parser.add_argument("--organizer-id")
    issue_parser.add_argument("--license-id")
    issue_parser.add_argument("--issued-at")
    issue_parser.add_argument("--starts-at")
    issue_parser.add_argument("--expires-at")
    issue_parser.add_argument("--days", type=int, help="Set duration from starts_at; required for TRIAL unless --expires-at is used")
    issue_parser.add_argument("--status", choices=["ACTIVE", "SUSPENDED", "REVOKED"], default="ACTIVE")
    issue_parser.add_argument("--installation-id")
    issue_parser.add_argument("--product")
    issue_parser.add_argument("--defaults", default=str(DEFAULTS_PATH))
    issue_parser.add_argument("--limits-json", help="JSON file with all standard limits and optional custom limits/features")
    issue_parser.add_argument("--features-json", help="JSON object with feature flags")
    for name in STANDARD_LIMITS:
        issue_parser.add_argument("--" + name.replace("_", "-"), dest=name, help="Explicit non-negative integer quota")
    issue_parser.set_defaults(fn=issue)

    verify_parser = commands.add_parser("verify", help="Verify a signed license with the public key")
    verify_parser.add_argument("--public-key", default="public/license_public.key")
    verify_parser.add_argument("--license-file", required=True)
    verify_parser.set_defaults(fn=verify)

    args = parser.parse_args()
    try:
        args.fn(args)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        raise SystemExit(str(exc)) from exc


if __name__ == "__main__":
    main()
