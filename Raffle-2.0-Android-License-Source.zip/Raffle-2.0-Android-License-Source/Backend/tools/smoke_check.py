"""Dependency-light release smoke checks for Raffle 2.0.

This intentionally avoids importing the application package, so it can run in
minimal environments before Python dependencies are installed.
"""
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "Backend"

REQUIRED = [
    ROOT / "README.md",
    ROOT / "RELEASE_CHECKLIST.md",
    BACKEND / "alembic.ini",
    BACKEND / "app/main.py",
    BACKEND / "app/api/auth.py",
    BACKEND / "app/api/organizers.py",
    BACKEND / "app/api/media.py",
    BACKEND / "app/api/draws.py",
    BACKEND / "app/api/raffles.py",
    BACKEND / "app/services/draw_service.py",
    BACKEND / "app/services/reservation_service.py",
    BACKEND / "app/services/draw_proof.py",
    ROOT / "Frontend/src/config.js",
    ROOT / "Frontend/package.json",
]


def fail(msg):
    print(f"Release smoke: FAIL - {msg}")
    raise SystemExit(1)


def check_files():
    for path in REQUIRED:
        if not path.exists():
            fail(f"missing required file: {path.relative_to(ROOT)}")


def check_source_contracts():
    auth = (BACKEND / "app/api/auth.py").read_text()
    if ".with_for_update()" not in auth:
        fail("refresh-token rotation is not row-lock protected")

    config = (ROOT / "Frontend/src/config.js").read_text()
    if "Production API and realtime URLs must use HTTPS." not in config:
        fail("frontend production HTTPS guard missing")

    draw = (BACKEND / "app/services/draw_service.py").read_text()
    for needle in ("randomness_commitment", "eligible_pool_hash", "result_hash", "selection_algorithm"):
        if needle not in draw:
            fail(f"draw proof field missing: {needle}")

    reservation = (BACKEND / "app/services/reservation_service.py").read_text()
    if "PAYMENT_REVIEW" not in reservation or "release_expired" not in reservation:
        fail("reservation expiry/payment-review protections missing")

    users = (BACKEND / "app/api/users.py").read_text()
    notifications = (BACKEND / "app/api/notifications.py").read_text()
    if 'prefix="/notifications"' not in notifications:
        fail("canonical notification router missing")
    if 'prefix="/users"' not in users:
        fail("user router missing")


def check_alembic():
    with tempfile.TemporaryDirectory(prefix="raffle_smoke_") as td:
        db = Path(td) / "smoke.db"
        env = dict(__import__("os").environ)
        env["DATABASE_URL"] = f"sqlite:///{db}"
        proc = subprocess.run(
            [sys.executable, "-m", "alembic", "upgrade", "head"],
            cwd=BACKEND, env=env, capture_output=True, text=True,
        )
        if proc.returncode:
            fail("Alembic upgrade failed: " + (proc.stderr or proc.stdout).strip()[-500:])
        conn = sqlite3.connect(db)
        tables = {r[0] for r in conn.execute("select name from sqlite_master where type='table'")}
        expected = {"admins", "licenses", "raffles", "users", "audit_logs", "prizes", "reservations", "payments", "tickets", "draws", "winners", "notifications", "auth_sessions", "ticket_allocations", "organizer_requests"}
        missing = expected - tables
        if missing:
            fail("migration missing tables: " + ", ".join(sorted(missing)))
        fk_rows = list(conn.execute("PRAGMA foreign_key_list(ticket_allocations)"))
        if not any(row[2] == "tickets" and row[6].upper() == "SET NULL" for row in fk_rows):
            fail("ticket_allocations.ticket_id must use ON DELETE SET NULL")
        conn.close()


def check_version():
    readme = (ROOT / "README.md").read_text()
    if "2.0.0-rc.1" not in readme:
        fail("release version mismatch in README")
    package = (ROOT / "Frontend/package.json").read_text()
    if '"packageManager": "pnpm@10.15.1"' not in package:
        fail("frontend package manager pin missing")


if __name__ == "__main__":
    check_files()
    check_source_contracts()
    check_alembic()
    check_version()
    print("Release smoke: PASS (2.0.0-rc.1)")
