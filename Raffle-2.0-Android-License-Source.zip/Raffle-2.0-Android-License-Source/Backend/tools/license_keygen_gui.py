#!/usr/bin/env python3
"""Windows desktop Keygen for Raffle 2.0 signed licenses."""
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from license_keygen import (
    DEFAULTS_PATH,
    STANDARD_LIMITS,
    b64d,
    b64e,
    build_payload,
    load_defaults,
    load_private_key,
    parse_limit,
    sign_payload,
    verify_token,
    write_private_key,
    write_public_key,
)

LIMIT_LABELS = {
    "max_active_raffles": "Rifas activas simultáneas",
    "max_tickets_per_raffle": "Boletos por rifa",
    "max_team_accounts": "Cuentas de equipo/administración",
    "max_organizers": "Organizadores asociados",
}


def user_config_path() -> Path:
    root = Path(os.environ.get("APPDATA", Path.home() / ".config")) / "Codexia Systems" / "RaffleKeygen"
    return root / "license_defaults.json"


def read_config() -> dict:
    user_path = user_config_path()
    return load_defaults(user_path if user_path.exists() else DEFAULTS_PATH)


class KeygenApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Raffle 2.0 — License Keygen | Codexia Systems")
        self.geometry("920x890")
        self.minsize(820, 720)
        self.config_data = read_config()
        self.limit_vars = {}
        self._build_ui()
        self._apply_type_defaults()

    def _build_ui(self):
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        form = ttk.Frame(canvas)
        form.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=form, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ttk.Label(form, text="Raffle 2.0 License Keygen", font=("Segoe UI", 20, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 2))
        ttk.Label(form, text="Codexia Systems · La clave privada cifrada permanece fuera de la aplicación móvil.").grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 14))

        self.private_path = tk.StringVar(value="private/license_private.key")
        self.passphrase = tk.StringVar()
        self.license_type = tk.StringVar(value="TRIAL")
        self.status = tk.StringVar(value="ACTIVE")
        self.organization_id = tk.StringVar()
        self.organizer_id = tk.StringVar()
        self.license_id = tk.StringVar()
        self.issued_at = tk.StringVar(value=self._now())
        self.starts_at = tk.StringVar(value=self._now())
        self.expires_at = tk.StringVar()
        self.duration_days = tk.StringVar()
        self.custom_limits = tk.StringVar(value="{}")
        self.features = tk.StringVar(value="{}")

        row = 2
        ttk.Label(form, text="Archivo de clave privada cifrada").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.private_path, width=68).grid(row=row, column=1, sticky="ew", padx=6)
        ttk.Button(form, text="Examinar…", command=self._browse_private).grid(row=row, column=2, sticky="ew")
        row += 1
        ttk.Label(form, text="Frase de desbloqueo").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.passphrase, show="•", width=40).grid(row=row, column=1, sticky="ew", padx=6)
        ttk.Button(form, text="Generar par Ed25519…", command=self._generate_keypair).grid(row=row, column=2, sticky="ew")
        row += 1

        ttk.Separator(form).grid(row=row, column=0, columnspan=3, sticky="ew", pady=12)
        row += 1
        ttk.Label(form, text="Tipo de licencia").grid(row=row, column=0, sticky="w", pady=4)
        type_select = ttk.Combobox(form, textvariable=self.license_type, values=("TRIAL", "COMMERCIAL"), state="readonly", width=20)
        type_select.grid(row=row, column=1, sticky="w", padx=6)
        type_select.bind("<<ComboboxSelected>>", lambda _event: self._apply_type_defaults())
        ttk.Label(form, text="Estado inicial firmado").grid(row=row, column=2, sticky="w", pady=4)
        row += 1
        ttk.Combobox(form, textvariable=self.status, values=("ACTIVE", "SUSPENDED", "REVOKED"), state="readonly", width=20).grid(row=row, column=1, sticky="w", padx=6)
        row += 1

        for label, variable in (("Organization ID (obligatorio)", self.organization_id), ("Organizer ID asociado (opcional)", self.organizer_id), ("License ID (vacío = generar)", self.license_id), ("Issued at · ISO 8601 UTC", self.issued_at), ("Starts at · ISO 8601 UTC", self.starts_at), ("Expires at · ISO 8601 UTC (opcional)", self.expires_at), ("Trial duration · días (elige fecha o duración)", self.duration_days)):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=4)
            ttk.Entry(form, textvariable=variable).grid(row=row, column=1, columnspan=2, sticky="ew", padx=6)
            row += 1

        ttk.Label(form, text="Límites firmados (enteros no negativos)", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=3, sticky="w", pady=(10, 3))
        row += 1
        for name, label in LIMIT_LABELS.items():
            variable = tk.StringVar()
            self.limit_vars[name] = variable
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=3)
            ttk.Entry(form, textvariable=variable, width=18).grid(row=row, column=1, sticky="w", padx=6)
            ttk.Label(form, text="Elige explícitamente un entero no negativo para este límite.").grid(row=row, column=2, sticky="w")
            row += 1

        ttk.Label(form, text="Límites adicionales · JSON",).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.custom_limits).grid(row=row, column=1, columnspan=2, sticky="ew", padx=6)
        row += 1
        ttk.Label(form, text="Features · JSON").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(form, textvariable=self.features).grid(row=row, column=1, columnspan=2, sticky="ew", padx=6)
        row += 1

        controls = ttk.Frame(form)
        controls.grid(row=row, column=0, columnspan=3, sticky="ew", pady=10)
        ttk.Button(controls, text="Emitir y firmar", command=self._issue).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Guardar límites como defaults", command=self._save_defaults).pack(side="left", padx=6)
        ttk.Button(controls, text="Copiar clave", command=self._copy_license).pack(side="left", padx=6)
        ttk.Button(controls, text="Guardar .lic…", command=self._save_license).pack(side="left", padx=6)
        row += 1
        ttk.Label(form, text="Licencia firmada / resultado", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=3, sticky="w", pady=(8, 3))
        row += 1
        self.output = tk.Text(form, height=7, wrap="word")
        self.output.grid(row=row, column=0, columnspan=3, sticky="ew")
        row += 1

        ttk.Separator(form).grid(row=row, column=0, columnspan=3, sticky="ew", pady=12)
        row += 1
        ttk.Label(form, text="Administrar estado en servidor", font=("Segoe UI", 12, "bold")).grid(row=row, column=0, columnspan=3, sticky="w")
        row += 1
        self.backend_url = tk.StringVar()
        self.admin_token = tk.StringVar()
        self.manage_license_id = tk.StringVar()
        self.manage_status = tk.StringVar(value="SUSPENDED")
        self.manage_reason = tk.StringVar()
        for label, variable, masked in (("URL del backend (incluye /api/v1 o raíz)", self.backend_url, False), ("License ID registrado en ese servidor", self.manage_license_id, False), ("Token de acceso SUPER_ADMIN (no se guarda)", self.admin_token, True), ("Motivo para auditoría", self.manage_reason, False)):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=4)
            ttk.Entry(form, textvariable=variable, show="•" if masked else "").grid(row=row, column=1, columnspan=2, sticky="ew", padx=6)
            row += 1
        ttk.Label(form, text="Nuevo estado").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(form, textvariable=self.manage_status, values=("ACTIVE", "SUSPENDED", "REVOKED"), state="readonly", width=20).grid(row=row, column=1, sticky="w", padx=6)
        ttk.Button(form, text="Actualizar estado del servidor", command=self._update_server_status).grid(row=row, column=2, sticky="ew", padx=6)
        row += 1
        ttk.Label(form, text="El token solo se usa en memoria. El endpoint exige SUPER_ADMIN y registra la acción en auditoría.", wraplength=780).grid(row=row, column=0, columnspan=3, sticky="w", pady=(6, 2))
        for column in range(3):
            form.columnconfigure(column, weight=1 if column == 1 else 0)

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    def _browse_private(self):
        path = filedialog.askopenfilename(title="Selecciona la clave privada cifrada", filetypes=(("Raffle key", "*.key *.json"), ("All files", "*.*")))
        if path:
            self.private_path.set(path)

    def _generate_keypair(self):
        private_path = filedialog.asksaveasfilename(title="Guardar clave privada cifrada", defaultextension=".key", initialfile="raffle-license-private.key", filetypes=(("Raffle private key", "*.key"),))
        if not private_path:
            return
        password = self.passphrase.get() or simpledialog.askstring("Frase de cifrado", "Crea una frase de al menos 12 caracteres:", show="•", parent=self)
        if not password or len(password) < 12:
            messagebox.showerror("Clave no creada", "La frase de desbloqueo debe tener al menos 12 caracteres.", parent=self)
            return
        public_path = filedialog.asksaveasfilename(title="Guardar clave pública", defaultextension=".key", initialfile="raffle-license-public.key", filetypes=(("Public key", "*.key"),))
        if not public_path:
            return
        private = Ed25519PrivateKey.generate()
        write_private_key(private_path, private, password)
        public_value = write_public_key(public_path, private)
        self.private_path.set(private_path)
        self.passphrase.set(password)
        self.output.delete("1.0", "end")
        self.output.insert("end", f"Public key (copiar a LICENSE_PUBLIC_KEY y REACT_APP_LICENSE_PUBLIC_KEY):\n{public_value}\n\nClave privada cifrada guardada en:\n{private_path}\n\nNo incluyas la clave privada en Android, APK, repositorios ni entregables públicos.")
        messagebox.showinfo("Par Ed25519 generado", "Se creó una clave privada cifrada y una clave pública. Mantén el archivo privado y la frase bajo control del emisor.", parent=self)

    def _apply_type_defaults(self):
        type_key = self.license_type.get().lower()
        defaults = self.config_data.get(type_key, {})
        for name, variable in self.limit_vars.items():
            value = defaults.get(name)
            variable.set(str(value) if value is not None else "")
        self.custom_limits.set(json.dumps(defaults.get("limits", {}), ensure_ascii=False))
        self.features.set(json.dumps(defaults.get("features", {}), ensure_ascii=False))
        duration = self.config_data.get("trial_duration_days") if type_key == "trial" else None
        self.duration_days.set(str(duration) if duration else "")

    def _read_limit_inputs(self) -> dict:
        result = {name: parse_limit(variable.get(), name) for name, variable in self.limit_vars.items()}
        custom = json.loads(self.custom_limits.get() or "{}")
        if not isinstance(custom, dict):
            raise ValueError("Los límites adicionales deben ser un objeto JSON.")
        result["limits"] = custom
        features = json.loads(self.features.get() or "{}")
        if not isinstance(features, dict):
            raise ValueError("Features debe ser un objeto JSON.")
        result["features"] = features
        return result

    def _issue(self):
        try:
            if not self.passphrase.get():
                raise ValueError("Escribe la frase para desbloquear la clave privada.")
            limits = self._read_limit_inputs()
            days_text = self.duration_days.get().strip()
            expires_at = self.expires_at.get().strip() or None
            days = int(days_text) if days_text and not expires_at else None
            payload = build_payload(
                license_type=self.license_type.get(),
                organization_id=self.organization_id.get(),
                private_key_path=self.private_path.get(),
                passphrase=self.passphrase.get(),
                license_id=self.license_id.get().strip() or None,
                organizer_id=self.organizer_id.get().strip() or None,
                issued_at=self.issued_at.get().strip() or None,
                starts_at=self.starts_at.get().strip() or None,
                expires_at=expires_at,
                days=days,
                license_status=self.status.get(),
                limits=limits,
                features=limits.get("features", {}),
                product=self.config_data.get("product", "raffle"),
            )
            private = load_private_key(self.private_path.get(), self.passphrase.get())
            token = sign_payload(payload, private)
            public = private.public_key()
            verified = verify_token(token, public)
            if verified != payload:
                raise ValueError("La verificación posterior a la firma no coincide.")
            self.manage_license_id.set(payload["license_id"])
            self.output.delete("1.0", "end")
            self.output.insert("end", token)
            self.output.insert("end", "\n\n--- Datos firmados ---\n")
            self.output.insert("end", json.dumps(payload, ensure_ascii=False, indent=2))
            self.output.insert("end", "\n\nFirma Ed25519 comprobada localmente.")
        except Exception as error:
            messagebox.showerror("No se pudo emitir la licencia", str(error), parent=self)

    def _save_defaults(self):
        try:
            type_key = self.license_type.get().lower()
            config = read_config()
            defaults = config.setdefault(type_key, {})
            for name, variable in self.limit_vars.items():
                defaults[name] = parse_limit(variable.get(), name)
            custom = json.loads(self.custom_limits.get() or "{}")
            features = json.loads(self.features.get() or "{}")
            if not isinstance(custom, dict) or not isinstance(features, dict):
                raise ValueError("Límites adicionales y features deben ser objetos JSON.")
            defaults["limits"] = custom
            defaults["features"] = features
            days = self.duration_days.get().strip()
            if type_key == "trial":
                config["trial_duration_days"] = int(days) if days else None
            target = user_config_path()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            self.config_data = config
            messagebox.showinfo("Configuración guardada", f"Defaults {self.license_type.get()} guardados en:\n{target}", parent=self)
        except Exception as error:
            messagebox.showerror("No se pudo guardar la configuración", str(error), parent=self)

    def _license_text(self) -> str:
        text = self.output.get("1.0", "end").strip()
        return text.split("\n\n--- Datos firmados ---", 1)[0].strip()

    def _copy_license(self):
        token = self._license_text()
        if "." not in token:
            messagebox.showwarning("Sin licencia", "Primero emite una licencia firmada.", parent=self)
            return
        self.clipboard_clear()
        self.clipboard_append(token)
        self.update()
        messagebox.showinfo("Copiada", "La clave firmada se copió al portapapeles.", parent=self)

    def _save_license(self):
        token = self._license_text()
        if "." not in token:
            messagebox.showwarning("Sin licencia", "Primero emite una licencia firmada.", parent=self)
            return
        path = filedialog.asksaveasfilename(title="Guardar clave de licencia", defaultextension=".lic", initialfile=f"{self.manage_license_id.get() or 'raffle-license'}.lic", filetypes=(("Raffle license", "*.lic"), ("Text", "*.txt")))
        if path:
            Path(path).write_text(token + "\n", encoding="utf-8")
            messagebox.showinfo("Guardada", f"La licencia firmada se guardó en:\n{path}", parent=self)

    def _update_server_status(self):
        try:
            base = self.backend_url.get().strip().rstrip("/")
            if not base:
                raise ValueError("Indica la URL del backend.")
            parsed = urllib.parse.urlsplit(base)
            if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
                raise ValueError("La administración remota de licencias requiere HTTPS.")
            if not parsed.path.endswith("/api/v1"):
                base += "/api/v1"
            license_id = self.manage_license_id.get().strip()
            token = self.admin_token.get().strip()
            if not license_id or not token:
                raise ValueError("Indica el License ID y un token de acceso SUPER_ADMIN.")
            endpoint = f"{base}/license/{urllib.parse.quote(license_id, safe='')}/status"
            body = json.dumps({"status": self.manage_status.get(), "reason": self.manage_reason.get().strip() or None}).encode("utf-8")
            request = urllib.request.Request(endpoint, data=body, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(request, timeout=20) as response:
                result = json.loads(response.read().decode("utf-8"))
            self.admin_token.set("")
            messagebox.showinfo("Estado actualizado", f"{result.get('license_id')} → {result.get('license_status')}", parent=self)
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")[:1200]
            messagebox.showerror("El servidor rechazó el cambio", f"HTTP {error.code}: {detail}", parent=self)
        except Exception as error:
            messagebox.showerror("No se pudo actualizar", str(error), parent=self)


if __name__ == "__main__":
    KeygenApp().mainloop()
