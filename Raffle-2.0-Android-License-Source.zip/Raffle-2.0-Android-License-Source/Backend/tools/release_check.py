"""Static release gate for Raffle 2.0.

This check intentionally does not require application dependencies. It validates
repository structure and release invariants that can be checked in a clean
source archive before installing the full runtime stack.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "Backend"
FRONTEND = ROOT / "Frontend"
EXPECTED_VERSION = "2.0.0-rc.1"

REQUIRED_FILES = [
    "README.md",
    "RELEASE_CHECKLIST.md",
    "Backend/requirements.txt",
    "Backend/alembic.ini",
    "Backend/.env.example",
    "Backend/app/main.py",
    "Backend/tools/license_keygen.py",
    "Frontend/package.json",
    "Frontend/.env.example",
]
FORBIDDEN_PARTS = {".env", "node_modules", "build", "dist", ".pytest_cache", "__pycache__"}
FORBIDDEN_NAMES = {"raffle.db"}


def fail(message: str) -> None:
    raise SystemExit(f"RELEASE CHECK FAILED: {message}")


def main() -> None:
    for relative in REQUIRED_FILES:
        if not (ROOT / relative).is_file():
            fail(f"missing required file: {relative}")

    package = json.loads((FRONTEND / "package.json").read_text(encoding="utf-8"))
    if package.get("version") != EXPECTED_VERSION:
        fail("frontend version is inconsistent")
    if package.get("packageManager") != "pnpm@10.15.1":
        fail("frontend package manager must be pnpm@10.15.1")

    config = (BACKEND / "app/core/config.py").read_text(encoding="utf-8")
    env = (BACKEND / ".env.example").read_text(encoding="utf-8")
    if f'app_version: str = "{EXPECTED_VERSION}"' not in config:
        fail("backend application version is inconsistent")
    if f"APP_VERSION={EXPECTED_VERSION}" not in env:
        fail("backend .env.example version is inconsistent")

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative_parts = set(path.relative_to(ROOT).parts)
        if relative_parts & FORBIDDEN_PARTS:
            fail(f"development/cache artifact present: {path.relative_to(ROOT)}")
        if path.name in FORBIDDEN_NAMES:
            fail(f"local database artifact present: {path.relative_to(ROOT)}")
        if path.name.endswith(".pyc"):
            fail(f"compiled Python artifact present: {path.relative_to(ROOT)}")

    requirements = (BACKEND / "requirements.txt").read_text(encoding="utf-8")
    for dependency in ("python-jose[cryptography]", "python-socketio", "cryptography"):
        if dependency not in requirements:
            fail(f"required runtime dependency missing: {dependency}")

    checklist = (ROOT / "RELEASE_CHECKLIST.md").read_text(encoding="utf-8")
    for phrase in ("complete backend test suite", "frontend production build", "fresh database"):
        if phrase not in checklist:
            fail(f"release checklist lost required gate: {phrase}")

    print(f"Release static gate: PASS ({EXPECTED_VERSION})")
    print("Source archive contains no local env/database/cache artifacts.")
    print("Runtime dependency installation and full integration tests remain required.")


if __name__ == "__main__":
    main()
