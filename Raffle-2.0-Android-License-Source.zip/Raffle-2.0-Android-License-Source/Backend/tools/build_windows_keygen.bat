@echo off
setlocal
cd /d "%~dp0"
py -m pip install --upgrade pip
py -m pip install -r requirements-keygen-windows.txt
py -m PyInstaller --noconfirm --clean --onefile --windowed --name RaffleKeygen --add-data "license_defaults.json;." license_keygen_gui.py
if errorlevel 1 exit /b %errorlevel%
echo.
echo Keygen built at: %CD%\dist\RaffleKeygen.exe
echo Keep the encrypted private key and passphrase outside this folder and never distribute them with the APK.
endlocal
