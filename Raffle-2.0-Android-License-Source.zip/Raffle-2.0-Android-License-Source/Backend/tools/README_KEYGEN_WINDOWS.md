# Raffle 2.0 Windows Keygen

`license_keygen_gui.py` is a Tkinter desktop utility for issuing schema-v2 Ed25519 license tokens and changing the status of a license already activated on a Raffle backend. The tool source is platform-independent; `build_windows_keygen.bat` packages it as `dist\RaffleKeygen.exe` on Windows with Python 3.11+ installed.

## Create the signing keys

Open the Keygen, choose **Generar par Ed25519**, and choose separate locations for the encrypted private key and public key. Use a unique passphrase of at least 12 characters. Back up the private key and passphrase using the issuer's protected key-management process. The encrypted private key is never bundled in the APK, the public project ZIP, or the executable. The public key may be copied to backend `LICENSE_PUBLIC_KEY` and frontend build variable `REACT_APP_LICENSE_PUBLIC_KEY`.

A CLI alternative is:

```powershell
py license_keygen.py init --private-key private\license_private.key --public-key public\license_public.key
```

New key files use Scrypt-derived encryption and Fernet authenticated encryption. Legacy plaintext private-key files can be read for migration, but the CLI warns; rotate such a key and reissue affected licenses rather than leaving an unencrypted key in routine use.

## Issue a license

The GUI asks for an organization ID, optional organizer association, signed status, issuance/start/expiry dates, the four signed quotas, custom limits and features. Trial quotas initially load from `license_defaults.json`: 3 simultaneous active raffles, 100 tickets per raffle, 2 team/administration accounts, and 1 associated organizer. Blank Trial duration is intentional: enter an expiry date or a number of days; no fixed Trial duration is embedded in Android. Commercial defaults start blank; after choosing explicit values, **Guardar límites como defaults** saves type-specific defaults in the per-user Keygen configuration under `%APPDATA%\Codexia Systems\RaffleKeygen\license_defaults.json`.

A Commercial license requires an explicit non-negative integer for each of the four standard quotas. No Commercial quota values or unlimited policy are silently assigned; set the values chosen for that license before signing. The signed payload contains `schema_version`, `license_id`, `product`, `license_type`, `organization_id`, optional `organizer_id`, `issued_at`, `starts_at`, `expires_at`, `license_status`, each standard maximum, an extensible numeric `limits` object, and `features`. The tool verifies the token with its derived public key before displaying it. It can copy the signed token or save it as a `.lic` file.

CLI example:

```powershell
py license_keygen.py issue --type TRIAL --organization-id ORG-001 --days 14 --private-key private\license_private.key --max-active-raffles 3 --max-tickets-per-raffle 100 --max-team-accounts 2 --max-organizers 1 --output issued\ORG-001.lic
```

Use the editable `commercial` section in `license_defaults.json` or `--limits-json` for Commercial licenses and any custom numeric limits. The four standard values are not preselected; the issuer must configure them explicitly. Schema-v2 validation rejects missing/null/non-numeric standard quotas. Use `--expires-at` instead of `--days` to set a specific UTC or offset timestamp. Trial issuance requires one of those duration choices.

## Suspend or revoke a license

After the license is activated on the server, the Keygen **Administrar estado en servidor** section can call `POST /api/v1/license/{license_id}/status` over HTTPS. It requires a current `SUPER_ADMIN` bearer access token for that backend. The token is held only in the running window, cleared after success, and not written into Keygen configuration. Each server-side transition is recorded in the audit log. A revoked key cannot be reactivated; a suspended key can be set active again if it has not expired. A license that has naturally expired needs a new signed issuance.

Status changes are server-authoritative and do not alter the immutable signed payload. The signed `license_status` records the issuance status; the backend's protected license row records later suspension/revocation. Keep the backend online-check cadence, offline grace and suspended policy in backend configuration. Production startup requires an explicit `LICENSE_OFFLINE_GRACE_HOURS` value.

## Build the Windows executable

On Windows, open PowerShell in this directory and run:

```powershell
.\build_windows_keygen.bat
```

The script includes only the GUI, code, Python dependencies and editable public defaults. Do not copy a private key, passphrase, backend token or issued customer license into `dist` before distributing the executable.
