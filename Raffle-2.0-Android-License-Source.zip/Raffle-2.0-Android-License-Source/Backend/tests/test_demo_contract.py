from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_demo_mode_has_a_single_test_raffle_path():
    main = read('Backend/app/main.py')
    demo = read('Backend/app/api/demo.py')
    assert 'is_demo=True' in main
    assert 'Raffle.is_demo.is_(True)' in main
    assert '@router.post("/prepare")' in demo
    assert '@router.post("/draw")' in demo


def test_expired_license_can_reach_draw_route_for_existing_raffles():
    source = read('Backend/app/api/draws.py')
    license_service = read('Backend/app/services/license_service.py')
    assert 'require_license_for_existing_raffle' in source
    assert 'may_complete_existing_raffle(license_state, raffle.status.value)' in source
    assert 'state.get("mode") == "EXPIRED"' in license_service


def test_development_trial_is_created_at_startup_but_demo_remains_separate():
    main = read('Backend/app/main.py')
    license_service = read('Backend/app/services/license_service.py')
    assert 'ensure_development_trial(db)' in main
    assert 'LicenseType.TRIAL' in license_service
