from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.core.database import Base
from app.models.notification import Notification
from app.services.notification_service import mine, notify


def make_db():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    return engine


def test_notifications_are_user_scoped_and_ordered():
    with Session(make_db()) as db:
        notify(db, 1, "Primera", "Uno")
        db.commit()
        notify(db, 2, "Otra", "Dos")
        db.commit()
        notify(db, 1, "Segunda", "Dos")
        db.commit()
        items = mine(db, 1)
        assert [item.title for item in items] == ["Segunda", "Primera"]
        assert all(item.user_id == 1 for item in items)


def test_notification_read_flag_can_be_changed():
    with Session(make_db()) as db:
        item = Notification(user_id=1, title="Pago", message="Confirmado")
        db.add(item)
        db.commit()
        db.refresh(item)
        assert item.is_read is False
        item.is_read = True
        db.commit()
        db.refresh(item)
        assert item.is_read is True
