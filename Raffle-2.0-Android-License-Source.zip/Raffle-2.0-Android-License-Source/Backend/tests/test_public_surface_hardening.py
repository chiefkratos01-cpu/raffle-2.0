from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_public_raffles_exclude_unpublished_and_cancelled_states():
    service = read("Backend/app/services/raffle_service.py")
    assert "PUBLIC_RAFFLE_STATUSES" in service
    assert "Raffle.status.in_(PUBLIC_RAFFLE_STATUSES)" in service
    for state in ("RaffleStatus.DRAFT", "RaffleStatus.CANCELLED"):
        assert state not in service.split("PUBLIC_RAFFLE_STATUSES =", 1)[1].split(")", 1)[0]


def test_public_draw_views_reject_non_public_raffles():
    source = read("Backend/app/api/draws.py")
    assert source.count("if not get_public(db, raffle_id):") >= 2


def test_image_upload_checks_declared_type_and_file_signature():
    source = read("Backend/app/api/media.py")
    assert "MAGIC_BYTES" in source
    assert "El archivo no coincide con el formato de imagen declarado" in source


def test_development_admin_password_is_not_shipped_as_a_fixed_secret():
    config = read("Backend/app/core/config.py")
    docs = read("docs/MILESTONE_35.md")
    assert 'demo_admin_password: str = "CHANGE_ME_ADMIN_PASSWORD"' in config


def test_public_verification_contract_avoids_internal_ticket_ids():
    schema = read("Backend/app/schemas/ticket.py")
    assert "ticket_id:" not in schema
    assert "raffle_id:" not in schema


def test_realtime_raffle_rooms_use_the_same_public_visibility_boundary():
    source = read("Backend/app/realtime/socket.py")
    assert "if not raffle or raffle.is_demo or raffle.status not in public_states:" in source
    assert "expires_at.tzinfo is None" in source
