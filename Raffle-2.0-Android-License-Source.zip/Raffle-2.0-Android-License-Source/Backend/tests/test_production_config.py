import pytest
from pydantic import ValidationError
from app.core.config import Settings


def base_production(**overrides):
    values = dict(
        environment="production", debug=False, jwt_secret_key="x" * 64,
        demo_mode=False, docs_enabled=False, cors_origins="https://raffle.example",
        rate_limit_enabled=True, demo_admin_password="a-real-admin-password",
        license_public_key="public-key", license_offline_grace_hours=0,
    )
    values.update(overrides)
    return Settings(**values)


def test_production_settings_accept_explicit_secure_values():
    settings = base_production()
    assert settings.environment == "production"
    assert settings.rate_limit_enabled is True


@pytest.mark.parametrize("override", [
    {"rate_limit_enabled": False},
    {"license_public_key": ""},
    {"demo_admin_password": "change-this-password"},
])
def test_production_rejects_insecure_defaults(override):
    with pytest.raises(ValidationError):
        base_production(**override)
