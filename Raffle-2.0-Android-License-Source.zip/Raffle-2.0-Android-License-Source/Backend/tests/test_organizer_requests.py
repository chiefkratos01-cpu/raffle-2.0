from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_organizer_request_model_has_expected_fields():
    from app.models.organizer_request import OrganizerRequest
    fields = set(OrganizerRequest.__table__.columns.keys())
    assert {'user_id', 'desired_username', 'password_hash', 'status', 'admin_id', 'reviewed_by_admin_id', 'rejection_reason'} <= fields


def test_organizer_routes_are_present():
    text = read('Backend/app/api/organizers.py')
    assert 'post("/requests")' in text
    assert 'get("/requests/mine")' in text
    assert 'requests/{request_id}/approve' in text
    assert 'requests/{request_id}/reject' in text


def test_team_restricts_non_super_admin_targets():
    source = read('Backend/app/api/team.py')
    assert 'AdminRole.SUPER_ADMIN, AdminRole.ADMIN' in source
    assert 'AdminRole.OPERATOR, AdminRole.FINANCE, AdminRole.VIEWER' in source
