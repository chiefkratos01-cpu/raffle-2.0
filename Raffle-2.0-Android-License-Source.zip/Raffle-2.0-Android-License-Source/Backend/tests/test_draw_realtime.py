from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_sync_draw_service_uses_thread_to_async_realtime_bridge():
    service = read("Backend/app/services/draw_service.py")
    events = read("Backend/app/realtime/events.py")
    assert "emit_draw_result(raffle.id, payload)" in service
    assert 'return _emit("draw_result", payload, f"raffle:{raffle_id}")' in events
    assert "get_running_loop" not in service
