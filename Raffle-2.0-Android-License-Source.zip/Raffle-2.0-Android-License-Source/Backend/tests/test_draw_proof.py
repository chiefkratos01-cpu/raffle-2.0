from app.services.draw_proof import choose_index, result_hash, SELECTION_ALGORITHM


def test_draw_selection_is_reproducible():
    seed = "ab" * 32
    pool_hash = "12" * 32
    a = choose_index(seed, pool_hash, 137)
    b = choose_index(seed, pool_hash, 137)
    assert a == b
    assert 0 <= a < 137


def test_draw_result_proof_changes_when_winner_changes():
    seed = "ab" * 32
    pool_hash = "12" * 32
    first = result_hash(seed=seed, pool_hash=pool_hash, ticket_number=17, prize_position=1)
    second = result_hash(seed=seed, pool_hash=pool_hash, ticket_number=18, prize_position=1)
    assert first != second
    assert len(first) == 64
    assert SELECTION_ALGORITHM == "SHA256_REJECTION_V1"
