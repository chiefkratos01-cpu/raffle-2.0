from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_admin_has_team_permissions_but_not_global_admin_management():
    source = read('Backend/app/core/deps.py')
    assert '"team:read"' in source
    assert '"team:manage"' in source
    security = read('Backend/app/api/admin_security.py')
    assert 'require_admin_roles(AdminRole.SUPER_ADMIN)' in security
