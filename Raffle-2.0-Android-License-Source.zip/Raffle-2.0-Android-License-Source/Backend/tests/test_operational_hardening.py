from datetime import datetime, timedelta, timezone
from app.models.auth_session import AuthSession


def test_session_activity_can_be_stale_without_being_expired():
    now = datetime.now(timezone.utc)
    session = AuthSession(
        subject_type="USER", subject_id=1, refresh_token_hash="d" * 64,
        created_at=now - timedelta(days=1),
        expires_at=now + timedelta(days=1),
        last_used_at=now - timedelta(minutes=6),
    )
    assert session.last_used_at < now - timedelta(minutes=5)
    assert session.expires_at > now


def test_health_contract_fields_are_optional_for_degraded_state():
    from app.schemas.system import HealthResponse
    response = HealthResponse(
        status="degraded", version="2.0.0-dev", environment="development",
        timestamp=datetime.now(timezone.utc), database="error", database_latency_ms=None,
    )
    assert response.status == "degraded"
    assert response.database == "error"
