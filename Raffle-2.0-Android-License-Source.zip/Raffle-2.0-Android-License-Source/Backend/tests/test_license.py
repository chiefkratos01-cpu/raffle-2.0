import base64, json
from datetime import datetime, timedelta, timezone
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

def b64e(v): return base64.urlsafe_b64encode(v).decode().rstrip('=')
def test_license_signature_roundtrip(monkeypatch):
    from app.core import config
    private=Ed25519PrivateKey.generate()
    monkeypatch.setattr(config.settings,'license_public_key',b64e(private.public_key().public_bytes_raw()))
    from app.services.license_service import verify_license_token
    payload={'license_id':'RFL-TEST','product':'raffle','license_type':'TRIAL','issued_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'expires_at':(datetime.now(timezone.utc)+timedelta(days=7)).isoformat().replace('+00:00','Z'),'installation_id':None}
    raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode(); part=b64e(raw); token=part+'.'+b64e(private.sign(part.encode()))
    assert verify_license_token(token)['license_id']=='RFL-TEST'

def test_tampered_license_rejected(monkeypatch):
    from app.core import config
    private=Ed25519PrivateKey.generate(); monkeypatch.setattr(config.settings,'license_public_key',b64e(private.public_key().public_bytes_raw()))
    from app.services.license_service import verify_license_token
    payload=b64e(b'{"license_id":"RFL-X","product":"raffle","license_type":"TRIAL","issued_at":"2026-01-01T00:00:00Z","expires_at":null}')
    token=payload+'.'+b64e(private.sign(payload.encode()))
    tampered=b64e(b'{\"license_id\":\"RFL-Y\",\"product\":\"raffle\",\"license_type\":\"TRIAL\",\"issued_at\":\"2026-01-01T00:00:00Z\",\"expires_at\":null}')+'.'+token.split('.')[1]
    try: verify_license_token(tampered)
    except ValueError: return
    assert False, 'tampered token should fail'
