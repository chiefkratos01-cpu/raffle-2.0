from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_refresh_rejects_inactive_subjects_and_revokes_session():
    source = read("app/api/auth.py")
    assert 'if session.subject_type == "USER"' in source
    assert 'elif session.subject_type == "ADMIN"' in source
    assert 'if not subject or not subject.is_active:' in source
    assert 'session.revoked_at = now' in source


def test_admin_deactivation_revokes_existing_sessions():
    source = read("app/api/admin_security.py")
    assert 'from app.models.auth_session import AuthSession' in source
    assert 'if not data.is_active:' in source
    assert 'AuthSession.subject_type == "ADMIN"' in source
    assert 'AuthSession.subject_id == target.id' in source
    assert 'session.revoked_at = now' in source


def test_production_security_headers_include_csp():
    source = read("app/main.py")
    assert "Content-Security-Policy" in source
    assert "frame-ancestors 'none'" in source
    assert "object-src 'none'" in source
