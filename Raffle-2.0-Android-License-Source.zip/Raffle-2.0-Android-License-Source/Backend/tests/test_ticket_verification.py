from app.models.ticket import Ticket
from app.models.enums import TicketStatus


def test_ticket_has_verification_code_field():
    assert "verification_code" in Ticket.__table__.columns
    assert Ticket.__table__.c.verification_code.unique is True
    assert TicketStatus.PAID.value == "PAID"
