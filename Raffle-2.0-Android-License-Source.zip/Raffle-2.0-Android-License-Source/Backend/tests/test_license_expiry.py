from datetime import datetime, timedelta, timezone


def test_license_public_status_marks_expired_license_as_limited(monkeypatch):
    from app.core import config
    from app.core.database import Base, Session
    from app.models.license import License, LicenseType
    from app.services.license_service import license_public_status

    monkeypatch.setattr(config.settings, 'demo_mode', False)
    engine = __import__('sqlalchemy').create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        db.add(License(product='raffle', license_type=LicenseType.COMMERCIAL, license_key='expired', status='ACTIVE', expires_at=datetime.now(timezone.utc) - timedelta(minutes=1)))
        db.commit()
        state = license_public_status(db)
    assert state['active'] is False
    assert state['mode'] == 'EXPIRED'
    assert state['limited'] is True
    assert state['days_remaining'] == 0


def test_license_public_status_allows_demo_when_unlicensed(monkeypatch):
    from app.core import config
    from app.core.database import Base, Session
    from app.services.license_service import license_public_status
    from sqlalchemy import create_engine

    monkeypatch.setattr(config.settings, 'demo_mode', True)
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        state = license_public_status(db)
    assert state['active'] is True
    assert state['mode'] == 'DEMO'
