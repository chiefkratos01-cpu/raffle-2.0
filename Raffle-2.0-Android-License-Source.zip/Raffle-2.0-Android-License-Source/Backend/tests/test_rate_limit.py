from app.core.rate_limit import InMemoryRateLimiter, RateLimitRule, rule_for


def test_sliding_window_blocks_after_limit():
    limiter = InMemoryRateLimiter()
    rule = RateLimitRule(2, 60)
    assert limiter.check("ip:path", rule)[0]
    assert limiter.check("ip:path", rule)[0]
    allowed, retry_after = limiter.check("ip:path", rule)
    assert not allowed
    assert retry_after >= 1


def test_rules_prioritize_sensitive_endpoints():
    assert rule_for("/api/v1/auth/login", "POST").limit == 10
    assert rule_for("/api/v1/auth/register", "POST").limit == 5
    assert rule_for("/api/v1/auth/refresh", "POST").limit == 30
    assert rule_for("/api/v1/draws/1", "POST").limit == 10
    assert rule_for("/api/v1/reservations", "POST").limit == 30
    assert rule_for("/api/v1/draws/verify/abc", "GET").limit == 60
