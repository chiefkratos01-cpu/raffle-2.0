from datetime import datetime, timedelta, timezone
from app.models.auth_session import AuthSession


def test_session_metadata_fields_are_optional():
    now = datetime.now(timezone.utc)
    session = AuthSession(
        subject_type="USER", subject_id=1, refresh_token_hash="b" * 64,
        created_at=now, expires_at=now + timedelta(days=1),
        ip_address="127.0.0.1", user_agent="Android Chrome"
    )
    assert session.ip_address == "127.0.0.1"
    assert session.user_agent == "Android Chrome"


def test_session_expiry_is_distinct_from_last_use():
    now = datetime.now(timezone.utc)
    session = AuthSession(
        subject_type="USER", subject_id=1, refresh_token_hash="c" * 64,
        created_at=now, expires_at=now + timedelta(days=1), last_used_at=now
    )
    assert session.expires_at > session.last_used_at
