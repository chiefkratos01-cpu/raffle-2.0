import json
from argparse import Namespace

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from tools.license_keygen import (
    _issue_limits,
    build_payload,
    load_private_key,
    sign_payload,
    verify_token,
    write_private_key,
)


LIMITS = {
    "max_active_raffles": 3,
    "max_tickets_per_raffle": 100,
    "max_team_accounts": 2,
    "max_organizers": 1,
}


def test_encrypted_private_key_roundtrip_and_wrong_passphrase(tmp_path):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    write_private_key(path, private, "test-passphrase-long-enough")
    assert json.loads(path.read_text())["format"] == "raffle-ed25519-encrypted-v1"
    loaded = load_private_key(path, "test-passphrase-long-enough")
    assert loaded.private_bytes_raw() == private.private_bytes_raw()
    with pytest.raises(ValueError, match="desbloquear"):
        load_private_key(path, "incorrect-passphrase-long")


def test_schema_v2_trial_payload_is_signed_and_verifiable(tmp_path):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    write_private_key(path, private, "test-passphrase-long-enough")
    payload = build_payload(
        license_type="TRIAL", organization_id="ORG-001", private_key_path=path,
        passphrase="test-passphrase-long-enough", starts_at="2026-01-01T00:00:00Z",
        expires_at="2026-01-15T00:00:00Z", limits=LIMITS,
    )
    token = sign_payload(payload, private)
    assert verify_token(token, private.public_key()) == payload
    assert payload["schema_version"] == 2
    assert payload["license_type"] == "TRIAL"
    assert payload["organization_id"] == "ORG-001"
    assert payload["max_active_raffles"] == 3
    assert payload["max_tickets_per_raffle"] == 100
    assert payload["max_team_accounts"] == 2
    assert payload["max_organizers"] == 1


def test_trial_duration_must_be_configured(tmp_path):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    write_private_key(path, private, "test-passphrase-long-enough")
    with pytest.raises(ValueError, match="requiere --days o --expires-at"):
        build_payload(
            license_type="TRIAL", organization_id="ORG-002", private_key_path=path,
            passphrase="test-passphrase-long-enough", limits=LIMITS,
        )


def test_commercial_license_requires_explicit_standard_limits(tmp_path):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    write_private_key(path, private, "test-passphrase-long-enough")
    with pytest.raises(ValueError, match="todos los límites firmados"):
        build_payload(
            license_type="COMMERCIAL", organization_id="ORG-003", private_key_path=path,
            passphrase="test-passphrase-long-enough", limits={"max_active_raffles": 10},
        )


def test_commercial_signs_explicit_configured_quotas(tmp_path):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    configured = {
        "max_active_raffles": 10,
        "max_tickets_per_raffle": 500,
        "max_team_accounts": 5,
        "max_organizers": 3,
    }
    write_private_key(path, private, "test-passphrase-long-enough")
    payload = build_payload(
        license_type="COMMERCIAL", organization_id="ORG-004", private_key_path=path,
        passphrase="test-passphrase-long-enough", limits=configured,
    )
    assert {name: payload[name] for name in configured} == configured


def test_commercial_defaults_are_loaded_from_keygen_configuration(tmp_path):
    configured = {
        "max_active_raffles": 12,
        "max_tickets_per_raffle": 800,
        "max_team_accounts": 6,
        "max_organizers": 4,
    }
    defaults_path = tmp_path / "license_defaults.json"
    defaults_path.write_text(json.dumps({"commercial": configured}), encoding="utf-8")
    args = Namespace(type="COMMERCIAL", limits_json=None, **{name: None for name in LIMITS})
    from tools.license_keygen import load_defaults

    assert _issue_limits(args, load_defaults(defaults_path)) == configured


@pytest.mark.parametrize("value", [None, "unlimited", "sin límite"])
def test_commercial_rejects_unspecified_unlimited_quota_values(tmp_path, value):
    path = tmp_path / "private.key"
    private = Ed25519PrivateKey.generate()
    write_private_key(path, private, "test-passphrase-long-enough")
    configured = {**LIMITS, "max_organizers": value}
    with pytest.raises(ValueError, match="entero no negativo"):
        build_payload(
            license_type="COMMERCIAL", organization_id="ORG-005", private_key_path=path,
            passphrase="test-passphrase-long-enough", limits=configured,
        )
