from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.core.database import Base
from app.models import Admin, Payment, Prize, Raffle, Reservation, Ticket, User
from app.models.enums import RaffleStatus, ReservationStatus, TicketStatus
from app.services.reservation_service import create_reservation, release_expired


def make_db():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    Base.metadata.create_all(engine)
    return engine


def seed(db):
    user = User(email="u@example.com", phone="555", password_hash="x", name="User")
    raffle = Raffle(
        title="Test", slug="test", description=None, total_tickets=5,
        ticket_price=Decimal("10.00"), currency="CUP", status=RaffleStatus.OPEN,
        winner_count=1, auto_release_enabled=True, reservation_minutes=10,
    )
    db.add_all([user, raffle])
    db.flush()
    db.add(Prize(raffle_id=raffle.id, position=1, title="Prize", description="Prize"))
    db.commit()
    return user, raffle


def test_released_number_can_be_reserved_again_and_history_remains():
    engine = make_db()
    with Session(engine) as db:
        user, raffle = seed(db)
        first = create_reservation(db, raffle, user.id, [1])
        first.status = ReservationStatus.ACTIVE
        first.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
        release_expired(db, raffle.id)
        assert db.get(Reservation, first.id).status == ReservationStatus.EXPIRED
        second = create_reservation(db, raffle, user.id, [1])
        assert second.id != first.id
        assert second.tickets[0].number == 1
        assert db.get(Reservation, first.id).release_reason == "Automatic reservation timeout"
        assert second.status == ReservationStatus.ACTIVE


def test_payment_review_is_not_released_by_timeout():
    engine = make_db()
    with Session(engine) as db:
        user, raffle = seed(db)
        reservation = create_reservation(db, raffle, user.id, [2])
        reservation.status = ReservationStatus.PAYMENT_REVIEW
        reservation.expires_at = datetime.now(timezone.utc) - timedelta(minutes=30)
        db.commit()
        release_expired(db, raffle.id)
        refreshed = db.get(Reservation, reservation.id)
        assert refreshed.status == ReservationStatus.PAYMENT_REVIEW
        assert refreshed.released_at is None


def test_released_ticket_keeps_immutable_allocation_history():
    from app.models import TicketAllocation

    engine = make_db()
    with Session(engine) as db:
        user, raffle = seed(db)
        first = create_reservation(db, raffle, user.id, [3])
        first.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
        release_expired(db, raffle.id)
        history = db.scalars(select(TicketAllocation).where(TicketAllocation.reservation_id == first.id)).all()
        assert len(history) == 1
        assert history[0].number == 3
        assert history[0].verification_code == first.tickets[0].verification_code
        assert history[0].status == TicketStatus.RELEASED
        second = create_reservation(db, raffle, user.id, [3])
        assert second.tickets[0].number == 3
        assert second.tickets[0].verification_code != history[0].verification_code


def test_ticket_delete_does_not_destroy_allocation_history():
    from app.models import TicketAllocation
    from sqlalchemy import event

    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    event.listen(engine, "connect", lambda dbapi, _: dbapi.execute("PRAGMA foreign_keys=ON"))
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        user, raffle = seed(db)
        reservation = create_reservation(db, raffle, user.id, [4])
        ticket = reservation.tickets[0]
        allocation = TicketAllocation(
            raffle_id=raffle.id, reservation_id=reservation.id, ticket_id=ticket.id,
            user_id=user.id, number=ticket.number, verification_code=ticket.verification_code,
            status=TicketStatus.RELEASED, allocated_at=ticket.created_at,
            released_at=datetime.now(timezone.utc), release_reason="test",
        )
        db.add(allocation)
        db.commit()
        allocation_id = allocation.id
        db.delete(ticket)
        db.commit()
        history = db.get(TicketAllocation, allocation_id)
        assert history is not None
        assert history.ticket_id is None
        assert history.number == 4
