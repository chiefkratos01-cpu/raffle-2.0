from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_real_raffle_creation_requires_production_license():
    source = read('Backend/app/api/raffles.py')
    deps = read('Backend/app/core/deps.py')
    assert 'require_production_license' in source
    assert 'state["mode"] not in {"TRIAL", "COMMERCIAL"}' in deps


def test_demo_has_isolated_endpoints_and_demo_users():
    source = read('Backend/app/api/demo.py')
    user = read('Backend/app/models/user.py')
    assert '@router.get("/state")' in source
    assert '@router.post("/prepare")' in source
    assert '@router.post("/draw")' in source
    assert 'is_demo=True' in source
    assert 'is_demo' in user


def test_demo_is_hidden_from_normal_catalog_and_dashboard():
    raffle_service = read('Backend/app/services/raffle_service.py')
    dashboard = read('Backend/app/api/admin_dashboard.py')
    assert 'Raffle.is_demo.is_(False)' in raffle_service
    assert 'Raffle.is_demo.is_(False)' in dashboard


def test_admin_sessions_and_global_admin_management_are_super_admin_only():
    admin_page = read('Frontend/src/pages/AdminPage.js')
    security = read('Backend/app/api/admin_security.py')
    assert "['sessions', 'Sesiones', 'SUPER_ADMIN']" in admin_page
    assert "['admins', 'Administradores', 'SUPER_ADMIN']" in admin_page
    assert 'require_admin_roles(AdminRole.SUPER_ADMIN)' in security


def test_demo_is_available_to_super_admin_and_admin_only():
    app = read('Frontend/src/App.js')
    admin_page = read('Frontend/src/pages/AdminPage.js')
    assert "adminRole !== 'SUPER_ADMIN' && adminRole !== 'ADMIN'" in app
    assert "permission === 'DEMO'" in admin_page
    assert "adminRole === 'SUPER_ADMIN' || adminRole === 'ADMIN'" in admin_page


def test_mobile_navigation_keeps_theme_and_logout_controls():
    app = read('Frontend/src/App.js')
    assert '<ThemeSelector />' in app
    assert 'className="logout-button"' in app
    assert 'className="mobile-nav"' in app


def test_mobile_theme_is_cyclic_not_a_select():
    source = read('Frontend/src/components/ThemeSelector.js')
    compact = ''.join(source.split())
    assert '<select' not in source
    assert "mode==='system'?'light':mode==='light'?'dark':'system'" in compact
    assert "mode==='dark'?'light':mode==='light'?'dark':'system'" in compact


def test_login_uses_neutral_identifier_and_svg_password_control():
    source = read('Frontend/src/pages/LoginPage.js')
    assert 'Correo, teléfono o usuario' in source
    assert 'password-icon' in source
    assert '👁️' not in source
    assert '🙈' not in source


def test_raffle_editor_uses_one_phone_whatsapp_field():
    source = read('Frontend/src/components/RaffleEditor.js')
    assert 'Teléfono / WhatsApp' in source
    assert 'organizer_whatsapp: f.organizer_phone.trim()' in source


def test_password_and_contact_validation_exists_in_frontend_and_backend():
    login = read('Frontend/src/pages/LoginPage.js')
    auth = read('Backend/app/schemas/auth.py')
    auth_api = read('Backend/app/api/auth.py')
    validation = read('Backend/app/core/validation.py')
    raffle_api = read('Backend/app/api/raffles.py')
    assert 'form.password.length < 12' in login
    assert r'/\s/.test(form.password)' in login
    raffle_schema = read('Backend/app/schemas/raffle.py')
    assert 'validate_organizer_phone' in raffle_schema
    assert 'PHONE_RE.fullmatch(value)' in raffle_schema
