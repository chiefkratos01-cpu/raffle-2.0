from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / 'Backend'
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))
