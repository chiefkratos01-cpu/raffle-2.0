import base64
import json
from datetime import datetime, timedelta, timezone

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from sqlalchemy import create_engine


def b64e(value):
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def signed_token(private, payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    part = b64e(raw)
    return part + "." + b64e(private.sign(part.encode()))


def payload(status="ACTIVE"):
    now = datetime.now(timezone.utc)
    return {
        "schema_version": 2,
        "license_id": "RFL-V2-TEST",
        "product": "raffle",
        "license_type": "TRIAL",
        "organization_id": "ORG-V2",
        "organizer_id": "ORGUSER-1",
        "issued_at": now.isoformat().replace("+00:00", "Z"),
        "starts_at": (now - timedelta(minutes=1)).isoformat().replace("+00:00", "Z"),
        "expires_at": (now + timedelta(days=30)).isoformat().replace("+00:00", "Z"),
        "license_status": status,
        "max_active_raffles": 3,
        "max_tickets_per_raffle": 100,
        "max_team_accounts": 2,
        "max_organizers": 1,
        "limits": {"max_exports": 5},
        "features": {"raffle_export": True},
        "installation_id": None,
    }


def test_v2_license_signature_and_organization_claims(monkeypatch):
    from app.core import config
    from app.services.license_service import verify_license_token

    private = Ed25519PrivateKey.generate()
    monkeypatch.setattr(config.settings, "license_public_key", b64e(private.public_key().public_bytes_raw()))
    result = verify_license_token(signed_token(private, payload()))
    assert result["schema_version"] == 2
    assert result["organization_id"] == "ORG-V2"
    assert result["max_active_raffles"] == 3
    assert result["limits"] == {"max_exports": 5}


def test_v2_claim_tampering_is_rejected(monkeypatch):
    from app.core import config
    from app.services.license_service import verify_license_token

    private = Ed25519PrivateKey.generate()
    monkeypatch.setattr(config.settings, "license_public_key", b64e(private.public_key().public_bytes_raw()))
    token = signed_token(private, payload())
    encoded, signature = token.split(".")
    changed = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
    changed["max_team_accounts"] = 999
    changed_part = b64e(json.dumps(changed, sort_keys=True, separators=(",", ":")).encode())
    with pytest.raises(ValueError, match="Firma"):
        verify_license_token(changed_part + "." + signature)


def test_v2_rejects_null_standard_quota(monkeypatch):
    from app.core import config
    from app.services.license_service import verify_license_token

    private = Ed25519PrivateKey.generate()
    monkeypatch.setattr(config.settings, "license_public_key", b64e(private.public_key().public_bytes_raw()))
    claims = payload()
    claims["license_type"] = "COMMERCIAL"
    claims["max_active_raffles"] = None
    with pytest.raises(ValueError, match="Límite no válido: max_active_raffles"):
        verify_license_token(signed_token(private, claims))


def test_activation_stores_license_id_and_organization(monkeypatch):
    from app.core import config
    from app.core.database import Base
    from app.services.license_service import activate_license
    from sqlalchemy.orm import Session

    private = Ed25519PrivateKey.generate()
    monkeypatch.setattr(config.settings, "license_public_key", b64e(private.public_key().public_bytes_raw()))
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        row = activate_license(db, signed_token(private, payload()))
        assert row.external_license_id == "RFL-V2-TEST"
        assert row.organization_id == "ORG-V2"
        assert row.schema_version == 2
        assert row.status == "ACTIVE"


def test_server_license_status_honors_suspension_and_revocation(monkeypatch):
    from app.core import config
    from app.core.database import Base
    from app.models.license import License, LicenseType
    from app.services.license_service import license_public_status
    from sqlalchemy.orm import Session

    monkeypatch.setattr(config.settings, "demo_mode", False)
    monkeypatch.setattr(config.settings, "license_suspended_policy", "READ_ONLY")
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        suspended_claims = payload("SUSPENDED")
        db.add(License(
            external_license_id="RFL-SUSPENDED", organization_id="ORG-V2", schema_version=2,
            product="raffle", license_type=LicenseType.TRIAL, license_key="RFL-SUSPENDED",
            status="SUSPENDED", expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            metadata_json=json.dumps(suspended_claims), installation_id="test-install",
        ))
        db.commit()
        suspended = license_public_status(db)
        revoked_claims = payload("REVOKED")
        db.add(License(
            external_license_id="RFL-REVOKED", organization_id="ORG-V2", schema_version=2,
            product="raffle", license_type=LicenseType.TRIAL, license_key="RFL-REVOKED",
            status="REVOKED", expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            metadata_json=json.dumps(revoked_claims), installation_id="test-install-2",
        ))
        db.commit()
        revoked = license_public_status(db)
    assert suspended["mode"] == "SUSPENDED"
    assert suspended["active"] is False
    assert suspended["suspended_policy"] == "READ_ONLY"
    assert revoked["mode"] == "REVOKED"
    assert revoked["active"] is False
    assert revoked["license_status"] == "REVOKED"


def test_check_license_limit_keeps_legacy_unconfigured_limit_compatibility():
    from app.services.license_service import check_license_limit

    state = {"limits": {"max_active_raffles": 3}}
    check_license_limit(state, "max_active_raffles", 2, 1)
    check_license_limit(state, "max_tickets_per_raffle", 100000, 1)
    with pytest.raises(ValueError, match="max_active_raffles"):
        check_license_limit(state, "max_active_raffles", 3, 1)


def test_expired_revoked_and_suspended_existing_raffle_policies_are_distinct():
    from app.services.license_service import may_complete_existing_raffle

    active = {"active": True, "mode": "TRIAL"}
    expired = {"active": False, "mode": "EXPIRED"}
    revoked = {"active": False, "mode": "REVOKED"}
    suspended_read_only = {"active": False, "mode": "SUSPENDED", "suspended_policy": "READ_ONLY"}
    suspended_completion = {"active": False, "mode": "SUSPENDED", "suspended_policy": "ALLOW_EXISTING_COMPLETION"}

    assert may_complete_existing_raffle(active, "OPEN")
    assert may_complete_existing_raffle(expired, "DRAW_SCHEDULED")
    assert not may_complete_existing_raffle(expired, "DRAFT")
    assert not may_complete_existing_raffle(revoked, "OPEN")
    assert not may_complete_existing_raffle(suspended_read_only, "OPEN")
    assert may_complete_existing_raffle(suspended_completion, "OPEN")
    assert not may_complete_existing_raffle(suspended_completion, "DRAFT")
