from datetime import datetime, timedelta, timezone
from app.core.security import create_access_token, hash_refresh_token, new_refresh_token
from app.models.auth_session import AuthSession


def test_refresh_tokens_are_opaque_and_hashed():
    token = new_refresh_token()
    assert len(token) > 40
    assert hash_refresh_token(token) != token
    assert len(hash_refresh_token(token)) == 64


def test_access_token_contains_session_id():
    token = create_access_token("7", "USER", "42")
    from app.core.security import decode_access_token
    claims = decode_access_token(token)
    assert claims["sid"] == "42"
    assert claims["role"] == "USER"
    assert claims["sub"] == "7"


def test_session_expiry_and_revocation_fields():
    now = datetime.now(timezone.utc)
    session = AuthSession(subject_type="USER", subject_id=1, refresh_token_hash="a" * 64, created_at=now,
                          expires_at=now + timedelta(days=1))
    assert session.revoked_at is None


def test_logout_revokes_server_session_authoritatively():
    now = datetime.now(timezone.utc)
    session = AuthSession(subject_type="ADMIN", subject_id=9, refresh_token_hash="b" * 64, created_at=now,
                          expires_at=now + timedelta(days=1))
    session.revoked_at = now
    assert session.revoked_at == now


def test_session_response_never_requires_refresh_token_value():
    from app.schemas.auth import SessionResponse
    row = SessionResponse(id=1, subject_type="USER", created_at="now", expires_at="later",
                          last_used_at=None, ip_address="127.0.0.1", user_agent="Test", current=True)
    assert not hasattr(row, "refresh_token")
