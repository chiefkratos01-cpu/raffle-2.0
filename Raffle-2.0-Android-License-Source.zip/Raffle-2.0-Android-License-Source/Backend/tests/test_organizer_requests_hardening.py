from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_organizer_request_password_hash_is_cleared_after_decision():
    source = read("Backend/app/api/organizers.py")
    assert 'row.password_hash = "CLEARED_AFTER_APPROVAL"' in source
    assert 'row.password_hash = "CLEARED_AFTER_REJECTION"' in source
