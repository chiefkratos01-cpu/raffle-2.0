from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


def test_admin_responses_do_not_depend_on_public_visibility_filter():
    source = read("Backend/app/api/raffles.py")
    assert "def _admin_response(raffle: Raffle) -> RaffleResponse" in source
    assert "return _admin_response(raffle)" in source


def test_cancel_blocks_paid_raffles_and_releases_unpaid_reservations():
    source = read("Backend/app/api/raffles.py")
    assert "if raffle.tickets_sold > 0:" in source
    assert "Gestiona primero los reembolsos correspondientes." in source
    assert 'reservation.status = ReservationStatus.RELEASED' in source
    assert 'ticket.status = TicketStatus.RELEASED' in source
    assert 'reservation.payment.status = PaymentStatus.REJECTED' in source


def test_low_ticket_status_is_recomputed_from_confirmed_sales():
    service = read("Backend/app/services/raffle_service.py")
    reservation = read("Backend/app/services/reservation_service.py")
    assert "def refresh_sales_status(raffle: Raffle) -> None" in service
    assert "raffle.tickets_sold" in service
    assert "RaffleStatus.LOW_TICKETS" in service
    assert "refresh_sales_status(reservation.raffle)" in reservation


def test_publish_only_allows_draft_raffles():
    source = read("Backend/app/api/raffles.py")
    assert 'if raffle.status != RaffleStatus.DRAFT:' in source
