from app.models.draw import Draw


def test_draw_has_unique_raffle_prize_constraint():
    constraints = {c.name for c in Draw.__table__.constraints}
    assert "uq_draw_raffle_prize_position" in constraints
