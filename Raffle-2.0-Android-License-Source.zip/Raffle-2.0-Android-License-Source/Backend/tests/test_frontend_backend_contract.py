from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / 'Backend'
FRONTEND = ROOT / 'Frontend' / 'src'


def _backend_routes():
    routes = set()
    for path in (BACKEND / 'app' / 'api').glob('*.py'):
        text = path.read_text(encoding='utf-8')
        prefixes = re.findall(r'(?:router|admin_router)\s*=\s*APIRouter\(prefix=["\']([^"\']*)', text)
        prefixes = prefixes or ['']
        for router_name, prefix in [('router', p) for p in prefixes]:
            for m in re.finditer(r'@router\.(get|post|put|patch|delete)\(\s*["\']([^"\']*)', text):
                method, route = m.groups()
                full = (prefix.rstrip('/') + '/' + route.lstrip('/')) or '/'
                routes.add((method.upper(), full))
        # Support files that define more than one router object.
        for mrouter, prefix in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*APIRouter\(prefix=["\']([^"\']*)', text):
            if mrouter == 'router':
                continue
            for m in re.finditer(r'@' + re.escape(mrouter) + r'\.(get|post|put|patch|delete)\(\s*["\']([^"\']*)', text):
                method, route = m.groups()
                full = (prefix.rstrip('/') + '/' + route.lstrip('/')) or '/'
                routes.add((method.upper(), full))
    return routes


def test_frontend_referenced_fixed_api_endpoints_exist():
    routes = _backend_routes()
    js = '\n'.join(p.read_text(encoding='utf-8') for p in FRONTEND.rglob('*.js'))
    refs = set()
    for m in re.finditer(r"api\.(get|post|put|patch|delete)\(\s*[`\"']([^`\"']+)", js):
        method, path = m.groups()
        path = path.split('?', 1)[0]
        if '${' not in path:
            refs.add((method.upper(), path.rstrip('/') or '/'))
    # Frontend API_URL already contains /api/v1, so compare against router-level paths.
    router_routes = {(method, path.rstrip('/') or '/') for method, path in routes}
    missing = sorted(ref for ref in refs if ref not in router_routes)
    assert not missing, f'Frontend endpoints missing in backend: {missing}'


def test_required_production_contract_files_exist():
    for relative in [
        'Frontend/src/config.js',
        'Frontend/src/services/api.js',
        'Frontend/src/services/socket.js',
        'Backend/app/core/config.py',
    ]:
        assert (ROOT / relative).is_file(), relative
