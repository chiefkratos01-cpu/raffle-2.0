from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAFFLES = (ROOT / "app/api/raffles.py").read_text()


def test_update_blocks_core_changes_after_sales():
    assert "Core raffle settings cannot change after tickets have been sold" in RAFFLES
    assert "data.total_tickets < raffle.tickets_sold" in RAFFLES


def test_cancel_rejects_terminal_or_in_progress_states():
    assert "RaffleStatus.DRAWING" in RAFFLES
    assert "RaffleStatus.COMPLETED" in RAFFLES
    assert "RaffleStatus.CANCELLED" in RAFFLES
    assert "Raffle cannot be cancelled in its current state" in RAFFLES


def test_update_validates_prize_positions():
    assert "Duplicate prize position" in RAFFLES
    assert "Prize position exceeds winner count" in RAFFLES
