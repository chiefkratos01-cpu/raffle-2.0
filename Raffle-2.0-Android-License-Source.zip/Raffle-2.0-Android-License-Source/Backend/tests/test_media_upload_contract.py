from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


def test_media_upload_contract_is_device_friendly():
    text = read('Backend/app/api/media.py')
    assert 'UploadFile' in text
    assert 'image/jpeg' in text
    assert 'image/png' in text
    assert 'image/webp' in text
    assert 'max_image_upload_bytes' in text


def test_demo_raffle_is_not_public_catalog_content():
    source = read('Backend/app/services/raffle_service.py')
    assert 'Raffle.is_demo.is_(False)' in source


def test_expired_license_is_distinct_from_demo_mode():
    source = read('Backend/app/services/license_service.py')
    assert 'effective_status = "EXPIRED"' in source
    assert 'if settings.demo_mode' in source
