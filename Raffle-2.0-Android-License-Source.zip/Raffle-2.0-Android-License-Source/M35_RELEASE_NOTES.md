# Raffle 2.0 - Milestone 35

Esta entrega integra la siguiente ronda funcional después de M34.

## Incluye
- Demo interactiva aislada.
- Participantes y boletos ficticios para demo.
- Sorteo demo sin compras reales.
- Imágenes demo proporcionadas por el proyecto con animación web por capas.
- Trial de desarrollo de 30 días.
- Separación entre administración de instalación y habilitación comercial.
- RBAC corregido en navegación y endpoints.
- Sesiones administrativas exclusivas de SUPER_ADMIN.
- Contraseña de SUPER_ADMIN de desarrollo actualizada.
- Selector de tema cíclico con SVG.
- Control de contraseña refinado sin emojis.
- Validaciones reforzadas.
- Teléfono/WhatsApp unificado en el editor de rifas.
- Navegación móvil refinada.
- Migración para usuarios demo.

## Validación del paquete
- `python -m compileall` de backend y migraciones: PASS.
- Cadena de migraciones revisada: head `f1c2d3e4b5a6`.
- Las suites completas requieren ejecutar el entorno del proyecto con sus dependencias instaladas, por lo que deben ejecutarse en el Codespace antes de fusionar M35 a `main`.
