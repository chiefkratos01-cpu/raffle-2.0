# Raffle 2.0

Reconstrucción del sistema de gestión de rifas con arquitectura modular, pagos manuales, reservas tolerantes a conectividad limitada, sorteos autoritativos en backend, realtime, QR y licenciamiento.

## Estado

**V2 · Release Candidate · 2.0.0-rc.1**

Milestone 36: integración Android con Capacitor 8, almacenamiento nativo cifrado, enlaces compartibles, firma local Ed25519 y límites/licencias configurables en backend y Keygen.

La versión antigua se conserva como referencia histórica. No se modifica ni se usa como base de producción.

## Desarrollo local

### Backend

```bash
cd Backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/Termux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env  # Windows
# cp .env.example .env  # Linux/Termux
uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd Frontend
pnpm install
pnpm start
```

## Arquitectura funcional

- Usuario y autenticación segura
- Rifas con premios configurables
- Tickets con unicidad por rifa
- Reservas con expiración opcional por rifa
- Confirmación manual de pagos
- Historial y auditoría
- Sorteos decididos por backend
- Socket.IO para estado del sorteo
- QR de verificación
- Licencia DEMO/TRIAL/COMMERCIAL con modo limitado tras vencimiento
- Solicitudes de organizador y gestión de equipo
- Carga de imágenes desde el dispositivo
- Temas Sistema/Claro/Oscuro
- Preparación PWA y despliegue local

## Regla de conectividad

La liberación automática de reservas es opcional por rifa. Si está desactivada, una reserva no se libera automáticamente por el simple paso del tiempo. Las reglas visibles de cada rifa deben informar la política seleccionada por el organizador.

## Seguridad

Nunca subir `.env`, claves privadas, contraseñas reales o credenciales de base de datos al repositorio.


## Desarrollo frontend

Este proyecto usa **pnpm** para el frontend. La versión esperada es `pnpm@10.15.1`.

```bash
cd Frontend
pnpm install
pnpm start
```

Para generar el build de producción:

```bash
pnpm build
```

## Seguridad

Consulta `docs/SECURITY_AND_ROLES.md` para permisos, auditoría y requisitos de producción. Nunca subir `.env`, claves privadas, contraseñas reales o credenciales de base de datos.

## Estado actual

**Milestone 36 · Android/licencias implementados; ver `docs/PROJECT_STATUS.md` y el informe de entrega para pruebas automáticas y requisitos de configuración manual.**

Antes de una entrega comercial deben completarse todos los puntos de `RELEASE_CHECKLIST.md` en un entorno limpio con todas las dependencias instaladas. El chequeo estático reproducible puede ejecutarse con `python Backend/tools/release_check.py`.

## Licencias

El sistema incorpora licencias firmadas Ed25519. Consulta `docs/LICENSING.md`. La clave privada del desarrollador no forma parte del proyecto distribuible.

## Aplicación Android local

El cliente Android usa Capacitor 8, empaqueta el bundle React local y usa plugins nativos; no descarga una página desde Chrome. Requiere Android Studio/JDK 21, Android SDK/API 36 y pnpm 10.15.1. Antes de compilar, configura en `Frontend` el API y Socket.IO HTTPS reales, la clave pública Ed25519 y la URL web pública para enlaces/QR:

```bash
cd Frontend
pnpm install --frozen-lockfile
export REACT_APP_API_URL=https://api.example.com/api/v1
export REACT_APP_SOCKET_URL=https://api.example.com
export REACT_APP_PUBLIC_URL=https://raffle.example.com
export REACT_APP_LICENSE_PUBLIC_KEY='<public-ed25519-key>'
pnpm android:debug
```

El APK de depuración aparece en `Frontend/android/app/build/outputs/apk/debug/app-debug.apk`. Para distribución configura la firma release y ejecuta `pnpm android:release` para generar el AAB. No compiles ni distribuyas con las URLs de ejemplo. La app guarda tokens y caché GET cifrados con Android Keystore, verifica localmente la firma de licencia y limpia la caché privada al cerrar sesión. Instrucciones y fuentes de las integraciones nativas: `docs/CAPACITOR_ANDROID_NOTES.md`.

## Keygen de Windows

El generador gráfico está en `Backend/tools/license_keygen_gui.py`; su configuración inicial y empaquetado están en `Backend/tools/README_KEYGEN_WINDOWS.md`. En Windows, ejecuta `Backend/tools/build_windows_keygen.bat` para crear `RaffleKeygen.exe`. No distribuyas la clave privada cifrada, su frase de desbloqueo, ni claves `.lic` con la aplicación.
