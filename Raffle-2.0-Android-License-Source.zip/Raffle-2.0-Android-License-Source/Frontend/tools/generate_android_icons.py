#!/usr/bin/env python3
"""Generate Android icons and Capacitor splash assets from the shipped Raffle logo."""
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android" / "app" / "src" / "main" / "res"
LOGO_PATH = ROOT / "public" / "assets" / "logo-icon.webp"
BACKGROUND = (8, 11, 28, 255)


def contained_logo(max_size: tuple[int, int]) -> Image.Image:
    logo = Image.open(LOGO_PATH).convert("RGBA")
    alpha = logo.getchannel("A")
    bounds = alpha.getbbox()
    if bounds:
        logo = logo.crop(bounds)
    logo.thumbnail(max_size, Image.Resampling.LANCZOS)
    return logo


def centered(size: tuple[int, int], *, transparent: bool, scale: float, monochrome: bool = False) -> Image.Image:
    width, height = size
    canvas = Image.new("RGBA", size, (0, 0, 0, 0) if transparent else BACKGROUND)
    limit = max(1, int(min(size) * scale))
    logo = contained_logo((limit, limit))
    x, y = (width - logo.width) // 2, (height - logo.height) // 2
    if monochrome:
        alpha = logo.getchannel("A")
        logo = Image.new("RGBA", logo.size, (255, 255, 255, 0))
        logo.putalpha(alpha)
    canvas.alpha_composite(logo, (x, y))
    return canvas


def main() -> None:
    # Adaptive-icon foreground uses the Android 108 dp canvas and a conservative
    # inner safe-zone mark so standard masks do not clip the logo.
    foreground_sizes = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
    legacy_sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
    for density, size in foreground_sizes.items():
        target = ANDROID / f"mipmap-{density}"
        target.mkdir(parents=True, exist_ok=True)
        centered((size, size), transparent=True, scale=0.58).save(target / "ic_launcher_foreground.png", optimize=True)
        centered((size, size), transparent=True, scale=0.58, monochrome=True).save(target / "ic_launcher_monochrome.png", optimize=True)

    for density, size in legacy_sizes.items():
        target = ANDROID / f"mipmap-{density}"
        target.mkdir(parents=True, exist_ok=True)
        icon = centered((size, size), transparent=False, scale=0.68)
        icon.save(target / "ic_launcher.png", optimize=True)
        icon.save(target / "ic_launcher_round.png", optimize=True)

    for folder in [ANDROID / "drawable", *ANDROID.glob("drawable-land-*"), *ANDROID.glob("drawable-port-*")]:
        splash = folder / "splash.png"
        if not splash.exists():
            continue
        old = Image.open(splash)
        size = old.size
        centered(size, transparent=False, scale=0.56).save(splash, optimize=True)

    for name in ("ic_launcher.xml", "ic_launcher_round.xml"):
        folder = ANDROID / "mipmap-anydpi-v26"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / name).write_text(
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
            '    <background android:drawable="@color/ic_launcher_background"/>\n'
            '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
            '    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>\n'
            '</adaptive-icon>\n', encoding="utf-8")

    values = ANDROID / "values"
    values.mkdir(parents=True, exist_ok=True)
    (values / "ic_launcher_background.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<resources>\n    <color name="ic_launcher_background">#080B1C</color>\n</resources>\n',
        encoding="utf-8")
    print(f"Generated Raffle adaptive icons and branded splash assets under {ANDROID}")


if __name__ == "__main__":
    main()
