import fs from 'fs';
import path from 'path';

const publicRoot = path.resolve(__dirname, '../public/assets');

test('Raffle 2.0 visual assets are included in the release', () => {
  [
    'logo-light.png',
    'logo-dark.png',
    'favicon.png',
    'logo-icon.webp',
    'home-illustration.webp',
    'empty-raffle.webp',
  ].forEach((name) => {
    expect(fs.existsSync(path.join(publicRoot, name))).toBe(true);
  });
});

test('home uses the supplied visual assets', () => {
  const home = fs.readFileSync(path.resolve(__dirname, 'pages/HomePage.js'), 'utf8');
  const app = fs.readFileSync(path.resolve(__dirname, 'App.js'), 'utf8');

  expect(home).toContain('/assets/home-illustration.webp');
  expect(home).toContain('/assets/empty-raffle.webp');
  expect(app).toContain('/assets/logo-icon.webp');
  const login = fs.readFileSync(path.resolve(__dirname, 'pages/LoginPage.js'), 'utf8');
  expect(login).toContain('/assets/logo-light.png');
  expect(login).toContain('/assets/logo-dark.png');
  ['demo/demo-ticket.webp','demo/demo-prize.webp','demo/demo-winner.webp','demo/demo-verified.webp'].forEach(name => expect(fs.existsSync(path.join(publicRoot, name))).toBe(true));

});
