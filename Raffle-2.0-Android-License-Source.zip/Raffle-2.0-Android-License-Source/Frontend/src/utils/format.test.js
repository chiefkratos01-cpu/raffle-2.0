import { assetUrl, money, statusLabel } from './format';

test('money formats amount and currency', () => expect(money(250, 'CUP')).toBe('250 CUP'));
test('money defaults to CUP', () => expect(money(100)).toBe('100 CUP'));
test('assetUrl keeps absolute URLs', () => expect(assetUrl('https://example.com/a.jpg')).toBe('https://example.com/a.jpg'));
test('assetUrl keeps relative media URLs in development', () => expect(assetUrl('/media/a.jpg')).toBe('/media/a.jpg'));
test('all raffle statuses have labels', () => expect(Object.keys(statusLabel)).toEqual(expect.arrayContaining(['DRAFT','OPEN','LOW_TICKETS','SOLD_OUT','DRAW_SCHEDULED','DRAWING','COMPLETED','CANCELLED'])));
