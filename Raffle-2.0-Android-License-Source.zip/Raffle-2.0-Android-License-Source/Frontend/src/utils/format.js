import { API_URL } from '../config';

export const money = (v, c) => `${Number(v || 0).toLocaleString()} ${c || 'CUP'}`;

export const statusLabel = {
  DRAFT: 'Borrador',
  OPEN: 'Abierta',
  LOW_TICKETS: 'Pocos boletos',
  SOLD_OUT: 'Agotada',
  DRAW_SCHEDULED: 'Sorteo programado',
  DRAWING: 'Sorteando',
  COMPLETED: 'Completada',
  CANCELLED: 'Cancelada',
};

export const assetUrl = (value) => {
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith('/media/')) {
    if (API_URL.startsWith('http')) return `${API_URL.replace(/\/api\/v1\/?$/, '')}${value}`;
    return value;
  }
  return value;
};
