import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { ThemeProvider } from './context/ThemeContext';
import './styles/tokens.css';
import './App.css';

createRoot(document.getElementById('root')).render(<ThemeProvider><App /></ThemeProvider>);
