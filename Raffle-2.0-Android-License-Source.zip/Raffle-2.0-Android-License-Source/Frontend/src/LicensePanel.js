import { useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import api from './services/api';
import { getSecureItem, setSecureItem } from './services/secureStorage';
import { evaluateOfflineLicense, verifySignedLicense } from './services/localLicense';

const QUOTA_LABELS = {
  max_active_raffles: 'Rifas activas simultáneas',
  max_tickets_per_raffle: 'Boletos por rifa',
  max_team_accounts: 'Cuentas de equipo/administración',
  max_organizers: 'Organizadores asociados',
};

function modeTitle(mode) {
  return ({
    DEMO: 'Modo demo', EXPIRED: 'Licencia vencida', UNLICENSED: 'Licencia no activada',
    SUSPENDED: 'Licencia suspendida', REVOKED: 'Licencia revocada', NOT_STARTED: 'Licencia aún no vigente',
    OFFLINE_GRACE: 'Modo sin conexión', OFFLINE_STALE: 'Verificación pendiente', OFFLINE_UNVERIFIED: 'Licencia no verificada sin conexión',
  })[mode] || (mode === 'TRIAL' ? 'Licencia de prueba' : mode === 'COMMERCIAL' ? 'Licencia comercial activa' : 'Estado de licencia');
}

export default function LicensePanel() {
  const [data, setData] = useState(null);
  const [key, setKey] = useState('');
  const [msg, setMsg] = useState('');

  const load = async () => {
    try {
      const response = await api.get('/license/status');
      let next = { ...response.data, offlineCached: response.headers?.['x-raffle-offline-cache'] === 'true' };
      const savedToken = await getSecureItem('raffle_license_token').catch(() => null);
      if (savedToken) {
        let verified = await verifySignedLicense(savedToken);
        if (verified.verified && next.license_id && verified.claims.license_id && String(next.license_id) !== String(verified.claims.license_id)) {
          verified = { verified: false, reason: 'La licencia guardada no coincide con el ID confirmado por el servidor.' };
        }
        if (verified.verified && next.organization_id && verified.claims.organization_id && String(next.organization_id) !== String(verified.claims.organization_id)) {
          verified = { verified: false, reason: 'La licencia guardada pertenece a otra organización.' };
        }
        next.signatureVerified = verified.verified;
        next.signatureError = verified.reason || '';
        if (next.offlineCached) {
          const offline = await evaluateOfflineLicense(savedToken, next);
          next = { ...next, ...offline, limits: verified.claims ? {
            max_active_raffles: verified.claims.max_active_raffles,
            max_tickets_per_raffle: verified.claims.max_tickets_per_raffle,
            max_team_accounts: verified.claims.max_team_accounts,
            max_organizers: verified.claims.max_organizers,
            ...(verified.claims.limits || {}),
          } : next.limits };
        }
      } else if (next.license_type && next.license_type !== 'DEMO') {
        next.signatureVerified = false;
      }
      setData(next);
      setMsg('');
      return response.data;
    } catch (error) {
      setMsg(error.response?.data?.detail || 'No se pudo consultar la licencia. Si estás sin conexión, se conservarán los datos guardados en este dispositivo.');
      return null;
    }
  };

  useEffect(() => {
    let timer;
    let cancelled = false;
    load().then((status) => {
      if (cancelled || !status) return;
      const interval = Math.max(3600, Number(status.check_interval_seconds) || 24 * 60 * 60);
      timer = window.setInterval(load, interval * 1000);
    });
    return () => { cancelled = true; if (timer) window.clearInterval(timer); };
  }, []);

  const activate = async (event) => {
    event.preventDefault();
    setMsg('');
    const candidate = key.trim();
    try {
      if (Capacitor.isNativePlatform()) {
        const verification = await verifySignedLicense(candidate);
        if (!verification.verified) throw new Error(verification.reason || 'No se pudo validar localmente la firma de la licencia.');
      }
      await api.post('/license/activate', { license_key: candidate });
      await setSecureItem('raffle_license_token', candidate);
      setKey('');
      setMsg('Licencia recibida y firma validada.');
      await load();
    } catch (error) {
      setMsg(error.response?.data?.detail || error.message || 'No se pudo activar la licencia.');
    }
  };

  const mode = data?.mode;
  const currentTitle = modeTitle(mode);
  const stateLabel = data?.active ? 'ACTIVA' : mode === 'EXPIRED' ? 'VENCIDA' : mode === 'SUSPENDED' ? 'SUSPENDIDA' : mode === 'REVOKED' ? 'REVOCADA' : mode === 'OFFLINE_GRACE' ? 'SIN CONEXIÓN · GRACIA' : mode === 'OFFLINE_STALE' ? 'VERIFICAR EN LÍNEA' : 'NO ACTIVA';
  const limits = data?.limits || {};

  return <section className="panel license-panel">
    <div className="section-title"><div><span className="eyebrow">LICENCIA</span><h2>{currentTitle}</h2></div><span className={`status-chip ${data?.active ? 'good' : 'bad'}`}>{stateLabel}</span></div>
    {mode === 'DEMO' && <div className="callout"><b>Estás probando Raffle 2.0</b><span>Puedes explorar y probar las funciones de demostración. Para crear y publicar rifas reales necesitas una licencia.</span></div>}
    {mode === 'EXPIRED' && <div className="callout warning"><b>Tu licencia venció</b><span>Las nuevas operaciones sujetas a licencia están limitadas. La información ya existente permanece disponible y las rifas activas conservan sus datos.</span></div>}
    {mode === 'SUSPENDED' && <div className="callout warning"><b>Licencia suspendida temporalmente</b><span>La política actual es de solo lectura. Los datos existentes se conservan; las operaciones nuevas requieren que la licencia vuelva a estar activa.</span></div>}
    {mode === 'REVOKED' && <div className="callout warning"><b>Licencia revocada</b><span>La revocación fue confirmada por el servidor. No se permiten nuevas operaciones licenciadas; los datos existentes permanecen intactos.</span></div>}
    {mode === 'NOT_STARTED' && <div className="callout warning"><b>La vigencia todavía no comenzó</b><span>La fecha de inicio configurada para esta licencia aún no ha llegado.</span></div>}
    {mode === 'OFFLINE_GRACE' && <div className="callout"><b>Sin conexión</b><span>Firma Ed25519 validada localmente. Se usa el último estado confirmado por el servidor dentro del período de gracia; los datos existentes permanecen disponibles.</span></div>}
    {(mode === 'OFFLINE_STALE' || mode === 'OFFLINE_UNVERIFIED') && <div className="callout warning"><b>No se pudo confirmar el estado en línea</b><span>La firma local {data?.verified ? 'es válida' : 'no está disponible o no se pudo validar'}. Puedes consultar datos guardados; para nuevas operaciones se requiere volver a conectar con el servidor.</span></div>}
    {mode === 'UNLICENSED' && <div className="callout warning"><b>Activa una licencia para comenzar</b><span>Si ya tienes una clave, pégala aquí. La firma se validará localmente en Android y en el servidor.</span></div>}
    {data?.offlineCached && !['OFFLINE_GRACE', 'OFFLINE_STALE', 'OFFLINE_UNVERIFIED'].includes(mode) && <div className="callout"><b>Datos guardados</b><span>Se muestra el último estado de licencia confirmado antes de perder la conexión.</span></div>}

    {data?.license_type && <p>Tipo: <b>{data.license_type}</b>{data.organization_id && <> · Organización: <b>{data.organization_id}</b></>}</p>}
    {data?.issued_at && <p>Emitida: <b>{new Date(data.issued_at).toLocaleString()}</b></p>}
    {data?.expires_at && <p>Vencimiento: <b>{new Date(data.expires_at).toLocaleString()}</b>{data.days_remaining != null && <> · {data.days_remaining} días restantes</>}</p>}
    {data?.installation_id && <p className="muted">Esta licencia está vinculada a esta instalación.</p>}
    {data?.signatureVerified && <p className="muted">Firma Ed25519 verificada localmente.</p>}
    {data?.signatureVerified === false && data?.signatureError && <p className="muted">{data.signatureError}</p>}
    {data?.last_verified_at && <p className="muted">Última verificación del servidor: {new Date(data.last_verified_at).toLocaleString()}{data.offline_grace_hours != null && <> · Gracia offline: {data.offline_grace_hours} h</>}</p>}

    {Object.entries(QUOTA_LABELS).some(([name]) => limits[name] !== undefined && limits[name] !== null) && <div className="license-limits">
      <h3>Límites incluidos en la licencia</h3>
      {Object.entries(QUOTA_LABELS).map(([name, label]) => limits[name] === undefined || limits[name] === null ? null : <div className="row" key={name}><span>{label}</span><b>{Number(limits[name]).toLocaleString()}</b></div>)}
    </div>}
    {data?.features && Object.keys(data.features).length > 0 && <div className="license-limits"><h3>Funciones habilitadas</h3>{Object.entries(data.features).map(([feature, enabled]) => <div className="row" key={feature}><span>{feature}</span><b>{enabled ? 'Sí' : 'No'}</b></div>)}</div>}

    <form onSubmit={activate}><label className="stacked-field"><span>Clave de licencia</span><textarea value={key} onChange={(event) => setKey(event.target.value)} placeholder="Pega aquí tu clave de licencia" rows="4" required /></label><button className="primary" type="submit">Activar licencia</button></form>
    {msg && <p className="muted">{msg}</p>}
  </section>;
}
