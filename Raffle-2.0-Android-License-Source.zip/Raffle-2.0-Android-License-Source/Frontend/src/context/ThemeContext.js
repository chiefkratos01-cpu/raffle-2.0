import { createContext, useContext, useEffect, useMemo, useState } from 'react';
const ThemeContext = createContext(null);
export function ThemeProvider({ children }) {
  const [mode, setMode] = useState(() => localStorage.getItem('raffle_theme') || 'system');
  useEffect(() => {
    localStorage.setItem('raffle_theme', mode);
    const root = document.documentElement;
    root.dataset.theme = mode;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => root.dataset.resolvedTheme = mode === 'system' ? (media.matches ? 'dark' : 'light') : mode;
    apply(); media.addEventListener?.('change', apply);
    return () => media.removeEventListener?.('change', apply);
  }, [mode]);
  const value = useMemo(() => ({ mode, setMode }), [mode]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}
export const useTheme = () => useContext(ThemeContext);
