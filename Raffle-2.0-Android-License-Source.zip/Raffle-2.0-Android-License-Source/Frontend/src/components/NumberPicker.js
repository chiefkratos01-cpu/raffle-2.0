import {useMemo,useState} from 'react';
import useRaffleAvailability from '../hooks/useRaffleAvailability';
import { selectionHaptic } from '../services/nativeFeatures';

export default function NumberPicker({r,selected,setSelected}){
  const pageSize=100;
  const totalPages=Math.max(1,Math.ceil(r.total_tickets/pageSize));
  const [page,setPage]=useState(0);
  const [jump,setJump]=useState('');
  const [notice,setNotice]=useState('');
  const start=page*pageSize+1;
  const end=Math.min(r.total_tickets,start+pageSize-1);
  const {occupied,loading,error}=useRaffleAvailability(r.id,start,pageSize);
  const nums=useMemo(()=>Array.from({length:end-start+1},(_,i)=>start+i),[start,end]);

  const goToNumber=(value)=>{
    const n=Number(value);
    if(!Number.isInteger(n)||n<1||n>r.total_tickets){setNotice(`Escribe un número entre 1 y ${r.total_tickets.toLocaleString()}.`);return;}
    setPage(Math.floor((n-1)/pageSize));
    setNotice('');
    setJump(String(n));
  };
  const toggle=(n)=>{
    if(occupied.has(n)) return;
    selectionHaptic();
    if(selected.includes(n)){
      setSelected(s=>s.filter(x=>x!==n));
      setNotice('');
      return;
    }
    if(r.max_tickets_per_user&&selected.length>=r.max_tickets_per_user){
      setNotice(`Has alcanzado el máximo de ${r.max_tickets_per_user} boleto${r.max_tickets_per_user===1?'':'s'} por cliente.`);
      return;
    }
    setNotice('');
    setSelected(s=>[...s,n]);
  };
  return <>
    <div className="picker-tools">
      <form className="number-search" onSubmit={e=>{e.preventDefault();goToNumber(jump)}}>
        <label>Buscar número
          <input inputMode="numeric" pattern="[0-9]*" value={jump} onChange={e=>setJump(e.target.value.replace(/\D/g,''))} placeholder={`1–${r.total_tickets.toLocaleString()}`} aria-label="Buscar número de boleto"/>
        </label>
        <button type="submit">Ir</button>
      </form>
      <div className="picker-toolbar">
        <div><span>{r.total_tickets.toLocaleString()} números</span>{loading&&<span role="status" className="muted">actualizando…</span>}{error&&<span role="alert" className="availability-error">{error}</span>}</div>
        <div><button disabled={page===0} onClick={()=>setPage(p=>p-1)}>Anterior</button><b>Página {page+1}/{totalPages}</b><button disabled={page===totalPages-1} onClick={()=>setPage(p=>p+1)}>Siguiente</button></div>
      </div>
    </div>
    {notice&&<p className="picker-notice" role="status">{notice}</p>}
    <div className="legend"><span><i className="dot available"/>Disponible</span><span><i className="dot occupied"/>Ocupado</span><span><i className="dot chosen"/>Elegido</span></div>
    <div className="number-grid" aria-label={`Números ${start} a ${end}`}>
      {nums.map(n=><button key={n} disabled={occupied.has(n)} className={`number ${selected.includes(n)?'selected':''} ${occupied.has(n)?'occupied':''}`} onClick={()=>toggle(n)} aria-pressed={selected.includes(n)}>{n}</button>)}
    </div>
    <div className="picker-footer"><span className="muted">Mostrando {start.toLocaleString()}–{end.toLocaleString()}</span>{r.max_tickets_per_user&&<span className="muted">Máximo: {r.max_tickets_per_user} · Seleccionados: {selected.length}</span>}</div>
  </>;
}
