import { fireEvent, render, screen } from '@testing-library/react';
import NumberPicker from './NumberPicker';

jest.mock('../hooks/useRaffleAvailability', () => ({ __esModule: true, default: jest.fn() }));
import useRaffleAvailability from '../hooks/useRaffleAvailability';

beforeEach(() => useRaffleAvailability.mockReturnValue({ occupied: new Set(), loading: false, error: '' }));

const raffle = { id: 1, total_tickets: 250, max_tickets_per_user: 2 };

function renderPicker(selected = [], setSelected = jest.fn()) {
  render(<NumberPicker r={raffle} selected={selected} setSelected={setSelected} />);
  return setSelected;
}

test('shows first page of 100 numbers', () => { renderPicker(); expect(screen.getByRole('button', { name: '1' })).toBeInTheDocument(); expect(screen.getByRole('button', { name: '100' })).toBeInTheDocument(); expect(screen.getByText('Página 1/3')).toBeInTheDocument(); });
test('occupied numbers are disabled', () => { useRaffleAvailability.mockReturnValue({ occupied: new Set([7]), loading: false, error: '' }); renderPicker(); expect(screen.getByRole('button', { name: '7' })).toBeDisabled(); });
test('selects and deselects available numbers', () => { const setSelected = renderPicker(); fireEvent.click(screen.getByRole('button', { name: '4' })); expect(setSelected).toHaveBeenCalled(); });
test('does not select occupied number', () => { useRaffleAvailability.mockReturnValue({ occupied: new Set([7]), loading: false, error: '' }); const setSelected = renderPicker(); fireEvent.click(screen.getByRole('button', { name: '7' })); expect(setSelected).not.toHaveBeenCalled(); });
test('enforces maximum per user', () => { const setSelected = renderPicker([1, 2]); fireEvent.click(screen.getByRole('button', { name: '3' })); expect(screen.getByRole('status')).toHaveTextContent('máximo de 2'); expect(setSelected).not.toHaveBeenCalled(); });
test('jumps to number 150', () => { renderPicker(); fireEvent.change(screen.getByLabelText('Buscar número de boleto'), { target: { value: '150' } }); fireEvent.click(screen.getByRole('button', { name: 'Ir' })); expect(screen.getByText('Página 2/3')).toBeInTheDocument(); expect(screen.getByRole('button', { name: '150' })).toBeInTheDocument(); });
test('shows invalid jump notice', () => { renderPicker(); fireEvent.change(screen.getByLabelText('Buscar número de boleto'), { target: { value: '999' } }); fireEvent.click(screen.getByRole('button', { name: 'Ir' })); expect(screen.getByRole('status')).toHaveTextContent('entre 1 y 250'); });
test('pagination works', () => { renderPicker(); fireEvent.click(screen.getByRole('button', { name: 'Siguiente' })); expect(screen.getByText('Página 2/3')).toBeInTheDocument(); fireEvent.click(screen.getByRole('button', { name: 'Anterior' })); expect(screen.getByText('Página 1/3')).toBeInTheDocument(); });
test('shows loading state', () => { useRaffleAvailability.mockReturnValue({ occupied: new Set(), loading: true, error: '' }); renderPicker(); expect(screen.getByText('actualizando…')).toBeInTheDocument(); });
test('shows availability error', () => { useRaffleAvailability.mockReturnValue({ occupied: new Set(), loading: false, error: 'No disponible' }); renderPicker(); expect(screen.getByText('No disponible')).toBeInTheDocument(); });
