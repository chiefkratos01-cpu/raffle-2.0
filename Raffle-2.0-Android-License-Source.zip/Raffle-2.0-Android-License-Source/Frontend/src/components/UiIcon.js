export default function UiIcon({ name, size = 20, strokeWidth = 1.7, className = '' }) {
  const paths = {
    search: <><circle cx="9" cy="9" r="5.5" /><path d="m13.2 13.2 4 4" /></>,
    plus: <><path d="M10 4v12M4 10h12" /></>,
    share: <><circle cx="15" cy="5" r="2" /><circle cx="5" cy="10" r="2" /><circle cx="15" cy="15" r="2" /><path d="m6.8 9 6.4-3M6.8 11l6.4 3" /></>,
    ticket: <><path d="M4 6.5h12v3a2 2 0 0 0 0 4v3H4v-3a2 2 0 0 0 0-4z" /><path d="M8 7.5v5M12 7.5v5" /></>,
    payment: <><rect x="3" y="5" width="14" height="10" rx="2" /><path d="M3 9h14M6 12h3" /></>,
    draw: <><circle cx="10" cy="10" r="6.5" /><path d="m10 5 1.5 3.5L15 10l-3.5 1.5L10 15l-1.5-3.5L5 10l3.5-1.5z" /></>,
    chevronDown: <path d="m6.5 8 3.5 3.5L13.5 8" />,
    chevronRight: <path d="m8 6.5 3.5 3.5L8 13.5" />,
    check: <path d="m5 10 3.2 3.2L15 6.8" />,
    trophy: <><path d="M6 4h8v3.5a4 4 0 0 1-8 0z" /><path d="M6 5H3.5v1.5A3.5 3.5 0 0 0 7 10M14 5h2.5v1.5A3.5 3.5 0 0 1 13 10M10 11v4M7.5 17h5" /></>,
    user: <><circle cx="10" cy="7" r="3" /><path d="M4 17a6 6 0 0 1 12 0" /></>,
  };
  return (
    <svg className={`ui-icon ${className}`.trim()} width={size} height={size} viewBox="0 0 20 20"
      fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}
