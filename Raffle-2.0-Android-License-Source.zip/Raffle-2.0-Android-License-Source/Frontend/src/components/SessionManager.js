import {useCallback,useEffect,useState} from 'react';
import api from '../services/api';
import Toast from './Toast';

function browserLabel(ua=''){
 const value=ua.toLowerCase();
 const mobile=/android|iphone|ipad|mobile/.test(value);
 const browser=value.includes('edg/')?'Edge':value.includes('firefox/')?'Firefox':value.includes('chrome/')?'Chrome':value.includes('safari/')?'Safari':'Navegador';
 return `${mobile?'Móvil':'Escritorio'} · ${browser}`;
}
function fmt(value){try{return new Date(value).toLocaleString()}catch{return value||'—'}}

export default function SessionManager(){
 const[sessions,setSessions]=useState([]),[msg,setMsg]=useState(''),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false);
 const load=useCallback(async()=>{try{setLoading(true);const r=await api.get('/auth/sessions');setSessions(r.data)}catch(e){setMsg(e.response?.data?.detail||'No se pudieron cargar las sesiones')}finally{setLoading(false)}},[]);
 useEffect(()=>{load()},[load]);
 const revoke=async id=>{if(!window.confirm('¿Cerrar esta sesión?'))return;try{setBusy(true);await api.delete(`/auth/sessions/${id}`);setSessions(x=>x.filter(s=>s.id!==id));setMsg('Sesión cerrada.')}catch(e){setMsg(e.response?.data?.detail||'No se pudo cerrar la sesión')}finally{setBusy(false)}};
 const revokeOthers=async()=>{if(!window.confirm('Se cerrarán todas las demás sesiones activas. Esta sesión seguirá abierta. ¿Continuar?'))return;try{setBusy(true);const r=await api.post('/auth/sessions/revoke-others');setSessions(x=>x.filter(s=>s.current));setMsg(`${r.data.revoked} sesión(es) cerrada(s).`)}catch(e){setMsg(e.response?.data?.detail||'No se pudieron cerrar las demás sesiones')}finally{setBusy(false)}};
 return <div className="panel session-panel"><Toast message={msg} onClose={()=>setMsg('')}/><div className="section-title"><div><span className="eyebrow">SEGURIDAD</span><h2>Sesiones activas</h2><span className="muted">Controla dónde está abierta tu cuenta.</span></div><button onClick={load} disabled={loading||busy}>Actualizar</button></div>
 {loading?<div className="empty">Cargando sesiones…</div>:sessions.length===0?<div className="empty">No hay sesiones activas.</div>:<>
 <div className="session-list">{sessions.map(s=><div className={`session-row ${s.current?'current':''}`} key={s.id}><div className="session-icon">{s.current?'✓':'•'}</div><div className="session-main"><div><b>{browserLabel(s.user_agent)}</b>{s.current&&<span className="badge session-current">Esta sesión</span>}</div><span>IP: {s.ip_address||'No disponible'}</span><span>Inicio: {fmt(s.created_at)} · Último uso: {fmt(s.last_used_at)}</span><small>Expira: {fmt(s.expires_at)}</small></div><div className="row-actions">{!s.current&&<button disabled={busy} onClick={()=>revoke(s.id)}>Cerrar</button>}</div></div>)}</div>
 {sessions.some(s=>!s.current)&&<div className="session-footer"><span className="muted">Si reconoces una actividad extraña, puedes cerrar todas las demás sesiones.</span><button disabled={busy} onClick={revokeOthers}>Cerrar las demás</button></div>}
 </>}
 </div>
}
