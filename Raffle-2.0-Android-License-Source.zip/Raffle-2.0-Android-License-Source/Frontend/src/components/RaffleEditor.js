import { useEffect, useState } from 'react';
import api from '../services/api';
import Toast from './Toast';
import ImagePicker from './ImagePicker';

const emptyForm = {
  title: '', description: '', image: '', total_tickets: 100, ticket_price: 100, currency: 'CUP', draw_date: '',
  winner_count: 1, max_tickets_per_user: 5, allow_multiple_wins: false, auto_release_enabled: false,
  reservation_minutes: 20, low_ticket_threshold: 10, rules: '', payment_instructions: '', organizer_name: '',
  organizer_phone: '',
  prizes: [{ position: 1, title: 'Primer premio', description: '', value: '' }],
};

function cleanNumber(value) {
  return Number(value);
}

function RaffleEditor({ initial, onDone, onCancel }) {
  const [f, setF] = useState(initial ? { ...emptyForm, ...initial, organizer_phone: initial.organizer_phone || initial.organizer_whatsapp || '', prizes: initial.prizes?.map(p => ({ ...p, value: p.value || '' })) || emptyForm.prizes } : emptyForm);
  const [err, setErr] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (initial) setF({ ...emptyForm, ...initial, organizer_phone: initial.organizer_phone || initial.organizer_whatsapp || '', prizes: initial.prizes?.map(p => ({ ...p, value: p.value || '' })) || emptyForm.prizes });
  }, [initial]);

  const set = (key, value) => setF(x => ({ ...x, [key]: value }));
  const winners = Math.max(1, Math.min(100, cleanNumber(f.winner_count) || 1));

  const setWinners = (value) => {
    const n = Math.max(1, Math.min(100, cleanNumber(value) || 1));
    setF(x => ({
      ...x,
      winner_count: n,
      prizes: Array.from({ length: n }, (_, i) => x.prizes[i] || { position: i + 1, title: `Premio #${i + 1}`, description: '', value: '' }),
    }));
  };

  const validate = () => {
    const title = f.title.trim();
    const total = cleanNumber(f.total_tickets);
    const price = cleanNumber(f.ticket_price);
    const max = f.max_tickets_per_user === '' ? null : cleanNumber(f.max_tickets_per_user);
    const low = cleanNumber(f.low_ticket_threshold);
    const reservation = cleanNumber(f.reservation_minutes);

    if (!title || title.length < 2) return 'Escribe un nombre válido para la rifa.';
    if (!Number.isInteger(total) || total < 1 || total > 1000000) return 'La cantidad de boletos debe estar entre 1 y 1,000,000.';
    if (!Number.isFinite(price) || price <= 0) return 'Escribe un precio válido para el boleto.';
    if (max !== null && (!Number.isInteger(max) || max < 1)) return 'El máximo por cliente debe ser un número entero mayor que cero.';
    if (!Number.isInteger(low) || low < 0) return 'El aviso de pocos boletos debe ser cero o un número entero positivo.';
    if (f.auto_release_enabled && (!Number.isInteger(reservation) || reservation < 1 || reservation > 1440)) return 'Indica cuántos minutos puede durar una reserva.';
    if (f.prizes.length < winners || f.prizes.some((p, i) => !p?.title?.trim())) return 'Escribe el nombre de cada premio.';
    if (f.organizer_phone && !/^\+?[0-9][0-9 ()-]{6,19}$/.test(f.organizer_phone.trim())) return 'Escribe un número de teléfono válido para el organizador.';
    return '';
  };

  const save = async (event) => {
    event.preventDefault();
    setErr('');
    const validation = validate();
    if (validation) {
      setErr(validation);
      return;
    }
    setSaving(true);
    try {
      const body = {
        ...f,
        organizer_phone: f.organizer_phone.trim(),
        organizer_whatsapp: f.organizer_phone.trim(),
        title: f.title.trim(),
        total_tickets: cleanNumber(f.total_tickets),
        ticket_price: cleanNumber(f.ticket_price),
        winner_count: winners,
        max_tickets_per_user: f.max_tickets_per_user === '' ? null : cleanNumber(f.max_tickets_per_user),
        reservation_minutes: f.auto_release_enabled ? cleanNumber(f.reservation_minutes) : null,
        low_ticket_threshold: cleanNumber(f.low_ticket_threshold),
        draw_date: f.draw_date ? new Date(f.draw_date).toISOString() : null,
        prizes: f.prizes.slice(0, winners).map((p, i) => ({ ...p, position: i + 1, title: p.title.trim(), value: p.value ? cleanNumber(p.value) : null })),
      };
      const response = initial ? await api.put(`/raffles/${initial.id}`, body) : await api.post('/raffles', body);
      onDone(response.data);
    } catch (e) {
      const detail = e.response?.data?.detail;
      setErr(Array.isArray(detail) ? detail.map(x => x.msg || 'Revisa este campo.').join(' ') : detail || 'No se pudo guardar la rifa. Revisa los datos e inténtalo de nuevo.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="editor" onSubmit={save} noValidate>
      <div className="form-intro">
        <strong>{initial ? 'Edita tu rifa' : 'Crea una nueva rifa'}</strong>
        <span>Completa los datos que verán las personas que participen.</span>
      </div>

      <div className="form-grid">
        <label>Título de la rifa<input required maxLength="200" value={f.title} onChange={e => set('title', e.target.value)} placeholder="Ej. Gran sorteo de verano" /></label>
        <label>Precio por boleto<input required type="number" min="0.01" step="0.01" inputMode="decimal" value={f.ticket_price} onChange={e => set('ticket_price', e.target.value)} /></label>
        <label>Moneda<select value={f.currency} onChange={e => set('currency', e.target.value)}><option value="CUP">CUP</option><option value="USD">USD</option><option value="EUR">EUR</option></select></label>
        <label className="wide">Descripción<textarea maxLength="4000" value={f.description || ''} onChange={e => set('description', e.target.value)} placeholder="Cuenta brevemente de qué trata la rifa." /></label>
        <label>Boletos totales<input type="number" min="1" max="1000000" step="1" value={f.total_tickets} onChange={e => set('total_tickets', e.target.value)} /><small>Es la cantidad total de números que tendrá la rifa.</small></label>
        <label>Máximo por cliente<input type="number" min="1" step="1" value={f.max_tickets_per_user} onChange={e => set('max_tickets_per_user', e.target.value)} /><small>Evita que una sola persona reserve más boletos de los que permitas.</small></label>
        <label>Fecha y hora del sorteo<input type="datetime-local" value={f.draw_date ? String(f.draw_date).slice(0, 16) : ''} onChange={e => set('draw_date', e.target.value)} /><small>Déjalo vacío si todavía no quieres fijar una fecha.</small></label>
        <label>Avisar cuando queden pocos boletos<input type="number" min="0" step="1" value={f.low_ticket_threshold} onChange={e => set('low_ticket_threshold', e.target.value)} /><small>Cuando queden esta cantidad, la rifa mostrará un aviso.</small></label>
        <div className="wide"><ImagePicker value={f.image} onChange={value => set('image', value)} /></div>
      </div>

      <div className="panel inner form-section">
        <div className="section-title"><div><span className="eyebrow">SORTEO</span><h3>¿Cuántos ganadores habrá?</h3></div><span className="count-pill">{winners}</span></div>
        <label className="inline-field">Cantidad de ganadores<input type="number" min="1" max="100" step="1" value={winners} onChange={e => setWinners(e.target.value)} /></label>
        <label className="check"><input type="checkbox" checked={f.allow_multiple_wins} onChange={e => set('allow_multiple_wins', e.target.checked)} /> Permitir que una misma persona gane más de una vez</label>
        <small className="help-text">Si lo desactivas, una persona que ya ganó no podrá volver a ganar en esta misma rifa.</small>
      </div>

      <div className="panel inner form-section">
        <div className="section-title"><div><span className="eyebrow">RESERVAS</span><h3>Tiempo para completar el pago</h3></div></div>
        <label className="check"><input type="checkbox" checked={f.auto_release_enabled} onChange={e => set('auto_release_enabled', e.target.checked)} /> Liberar automáticamente los boletos si no se completa el pago</label>
        <small className="help-text">Si lo activas, una reserva sin completar el pago volverá a estar disponible después del tiempo que elijas. Si lo dejas apagado, la reserva no se libera solo por pasar el tiempo.</small>
        {f.auto_release_enabled && <label className="inline-field">Minutos para completar el pago<input type="number" min="1" max="1440" step="1" value={f.reservation_minutes} onChange={e => set('reservation_minutes', e.target.value)} /></label>}
      </div>

      <div className="panel inner form-section">
        <div className="section-title"><div><span className="eyebrow">PREMIOS</span><h3>Premios de la rifa</h3></div></div>
        {Array.from({ length: winners }, (_, i) => (
          <div className="prize-edit" key={i}>
            <b>#{i + 1}</b>
            <input required maxLength="200" placeholder="Nombre del premio" value={f.prizes[i]?.title || ''} onChange={e => setF(x => ({ ...x, prizes: x.prizes.map((p, j) => j === i ? { ...p, title: e.target.value } : p) }))} />
            <input maxLength="2000" placeholder="Descripción del premio (opcional)" value={f.prizes[i]?.description || ''} onChange={e => setF(x => ({ ...x, prizes: x.prizes.map((p, j) => j === i ? { ...p, description: e.target.value } : p) }))} />
          </div>
        ))}
      </div>

      <div className="form-grid">
        <label className="wide">Reglas de esta rifa<textarea maxLength="8000" value={f.rules || ''} onChange={e => set('rules', e.target.value)} placeholder="Explica de forma clara las condiciones particulares de esta rifa." /></label>
        <label className="wide">Cómo realizar el pago<textarea maxLength="4000" value={f.payment_instructions || ''} onChange={e => set('payment_instructions', e.target.value)} placeholder="Indica dónde y cómo debe pagar la persona. No pidas contraseñas ni datos privados." /></label>
        <label>Nombre del organizador<input maxLength="160" value={f.organizer_name || ''} onChange={e => set('organizer_name', e.target.value)} /></label>
        <label>Teléfono / WhatsApp<input maxLength="40" inputMode="tel" value={f.organizer_phone || ''} onChange={e => set('organizer_phone', e.target.value)} placeholder="Ej. +53 5XXXXXXX" /><small>Usaremos este mismo número para contacto y WhatsApp.</small></label>
      </div>

      <Toast message={err} error onClose={() => setErr('')} />
      <div className="editor-actions"><button type="button" onClick={onCancel}>Cancelar</button><button className="primary" type="submit" disabled={saving}>{saving ? 'Guardando…' : initial ? 'Guardar cambios' : 'Guardar rifa'}</button></div>
    </form>
  );
}

export default RaffleEditor;
