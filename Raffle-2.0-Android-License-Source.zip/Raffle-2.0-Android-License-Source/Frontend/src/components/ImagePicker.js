import { useEffect, useState } from 'react';
import api from '../services/api';
import { assetUrl } from '../utils/format';

export default function ImagePicker({ value, onChange, label = 'Imagen de la rifa' }) {
  const [preview, setPreview] = useState(value || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => setPreview(value || ''), [value]);

  const choose = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setError('');
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setError('Elige una imagen JPG, PNG o WEBP.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('La imagen no puede superar 5 MB.');
      return;
    }
    const localPreview = URL.createObjectURL(file);
    setPreview(localPreview);
    setBusy(true);
    try {
      const body = new FormData();
      body.append('file', file);
      const response = await api.post('/media/images', body);
      onChange(response.data.url);
      setPreview(response.data.url);
    } catch (e) {
      setPreview(value || '');
      setError(e.response?.data?.detail || 'No se pudo subir la imagen.');
    } finally {
      URL.revokeObjectURL(localPreview);
      setBusy(false);
    }
  };

  return (
    <div className="image-picker">
      <span className="image-picker-label">{label}</span>
      {preview ? (
        <div className="image-preview">
          <img src={assetUrl(preview)} alt="Vista previa" />
          <div className="image-preview-actions">
            <label className="button-like">
              Cambiar imagen
              <input type="file" accept="image/jpeg,image/png,image/webp" onChange={choose} hidden />
            </label>
            <button type="button" onClick={() => { onChange(''); setPreview(''); setError(''); }} disabled={busy}>Quitar</button>
          </div>
        </div>
      ) : (
        <label className="image-dropzone">
          <span className="image-icon">✦</span>
          <strong>{busy ? 'Subiendo…' : 'Agregar imagen'}</strong>
          <small>Selecciona una imagen desde tu dispositivo</small>
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={choose} hidden disabled={busy} />
        </label>
      )}
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  );
}
