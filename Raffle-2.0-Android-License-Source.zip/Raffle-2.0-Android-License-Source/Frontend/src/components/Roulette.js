import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchLatestDraw, fetchRaffleWinners } from '../services/raffles';
import useDrawRealtime from '../hooks/useDrawRealtime';

const SPIN_DURATION = 7200;
const FULL_TURNS = 7;
const MAX_VISIBLE_LABELS = 32;
const MAX_VISUAL_SEGMENTS = 60;

function targetAngleFor(ticketNumber, totalTickets, seed) {
  const ticket = Number(ticketNumber);
  const total = Math.max(1, Number(totalTickets) || 1);
  if (!ticket || !seed) return 0;

  let seedOffset = 0;
  try {
    seedOffset = Number(BigInt(`0x${seed.slice(0, 16)}`) % 360n);
  } catch {
    seedOffset = parseInt(seed.slice(0, 16), 16) % 360;
  }

  return ((ticket - 0.5) / total) * 360 + seedOffset;
}

function buildLabels(total, winnerNumber) {
  const safeTotal = Math.max(1, Number(total) || 1);
  const step = Math.max(1, Math.ceil(safeTotal / MAX_VISIBLE_LABELS));
  const numbers = [];

  for (let number = 1; number <= safeTotal; number += step) numbers.push(number);
  if (winnerNumber && !numbers.includes(winnerNumber)) numbers.push(winnerNumber);

  return numbers.sort((a, b) => a - b);
}

function Roulette({ raffle, onClose }) {
  const [draw, setDraw] = useState(null);
  const [winner, setWinner] = useState(null);
  const [spinning, setSpinning] = useState(false);

  const load = useCallback(async () => {
    try {
      const [drawResponse, winnersResponse] = await Promise.all([
        fetchLatestDraw(raffle.id),
        fetchRaffleWinners(raffle.id),
      ]);

      const latest = drawResponse.data ? { ...drawResponse.data } : null;
      const found = latest
        ? winnersResponse.data.find((item) => item.draw_id === latest.id) || null
        : null;

      if (latest && found) {
        latest.target_angle = targetAngleFor(
          found.ticket_number,
          raffle.total_tickets,
          latest.animation_seed,
        );
      }

      setWinner(found);
      setDraw(latest);

      // A viewer can enter after the realtime event. If the server is still in
      // ANIMATION, replay the reveal locally so every viewer sees the result.
      if (latest?.status === 'ANIMATION') setSpinning(true);
    } catch {
      // Polling is a recovery path. The realtime channel remains authoritative.
    }
  }, [raffle.id, raffle.total_tickets]);

  const onRealtime = useMemo(
    () => (payload) => {
      setDraw(payload);
      setWinner(null);
      setSpinning(true);
      load();
    },
    [load],
  );

  useDrawRealtime(raffle.id, onRealtime);

  useEffect(() => {
    load();
    const timer = setInterval(load, 1500);
    return () => clearInterval(timer);
  }, [load]);

  useEffect(() => {
    if (!spinning) return undefined;
    const timer = setTimeout(() => setSpinning(false), SPIN_DURATION);
    return () => clearTimeout(timer);
  }, [spinning]);

  const totalTickets = Math.max(1, Number(raffle.total_tickets) || 1);
  const winnerNumber = winner?.ticket_number || null;
  const labels = buildLabels(totalTickets, winnerNumber);
  const visibleWinnerNumber = spinning ? null : winnerNumber;
  const targetAngle = Number(draw?.target_angle) || 0;
  const rotation = spinning
    ? -(targetAngle + FULL_TURNS * 360)
    : -targetAngle;

  const labelSegmentSize = 360 / totalTickets;
  const visualSegments = Math.min(totalTickets, MAX_VISUAL_SEGMENTS);
  const visualSegmentSize = 360 / visualSegments;
  const wheelBackground = useMemo(() => {
    const palette = ['#6f35d7', '#ec3f9f', '#f2a53a', '#178fd4', '#17b9ad', '#e44e67'];
    const stops = [];

    for (let index = 0; index < visualSegments; index += 1) {
      const start = index * visualSegmentSize;
      const end = (index + 1) * visualSegmentSize;
      const color = palette[index % palette.length];
      stops.push(`${color} ${start}deg ${end}deg`);
    }

    return `conic-gradient(from -90deg, ${stops.join(', ')})`;
  }, [visualSegmentSize, visualSegments]);

  return (
    <div
      className="roulette-overlay"
      role="dialog"
      aria-modal="true"
      aria-label={`Sorteo de ${raffle.title}`}
    >
      <div className="roulette-modal">
        <div className="section-title">
          <div>
            <span className="eyebrow">SORTEO EN TIEMPO REAL</span>
            <h2>{raffle.title}</h2>
          </div>
          <button onClick={onClose} aria-label="Cerrar sorteo" type="button">×</button>
        </div>

        <div className="roulette-stage">
          <div className="wheel-wrap">
            <div className="pointer" aria-hidden="true" />
            <div
              className={`wheel ${spinning ? 'wheel-spinning' : 'wheel-stopped'}`}
              style={{
                '--wheel-background': wheelBackground,
                transform: `rotate(${rotation}deg)`,
              }}
            >
              <div className="wheel-labels" aria-hidden="true">
                {labels.map((number) => {
                  const angle = (number - 0.5) * labelSegmentSize;
                  const radians = (angle * Math.PI) / 180;
                  const x = 50 + Math.sin(radians) * 41;
                  const y = 50 - Math.cos(radians) * 41;
                  const isWinner = visibleWinnerNumber === number;

                  return (
                    <span
                      className={isWinner ? 'wheel-label winner' : 'wheel-label'}
                      key={number}
                      style={{ left: `${x}%`, top: `${y}%` }}
                    >
                      {number}
                    </span>
                  );
                })}
              </div>
              <div className="wheel-grid" aria-hidden="true" />
              <div className="wheel-core" aria-hidden="true">
                <span>Raffle 2.0</span>
              </div>
            </div>
          </div>
        </div>

        <div className={`roulette-status ${spinning ? 'active' : ''}`}>
          <span>{spinning ? 'SORTEANDO...' : winner ? `GANADOR #${winner.prize_position}` : 'LISTO'}</span>
          <strong>
            {spinning
              ? 'La suerte está girando'
              : winner
                ? `Ticket #${winner.ticket_number}`
                : 'Preparando el sorteo'}
          </strong>
          {spinning && (
            <small>
              El resultado ya fue seleccionado de forma segura. La rueda lo revela para todos.
            </small>
          )}
        </div>

        {winner && !spinning && (
          <div className="winner-banner">
            <span>GANADOR #{winner.prize_position}</span>
            <strong>Ticket #{winner.ticket_number}</strong>
            <small>{winner.prize_description}</small>
            <code>{winner.verification_code}</code>
          </div>
        )}

        {draw?.status === 'ANIMATION' && spinning && (
          <p className="muted center">La animación se reproduce de forma sincronizada para los espectadores.</p>
        )}
      </div>
    </div>
  );
}

export default Roulette;
