import {useEffect,useState} from 'react';
import api from '../services/api';

const money=(v,c)=>`${Number(v||0).toLocaleString()} ${c||'CUP'}`;
const statusLabel={DRAFT:'Borrador',OPEN:'Abierta',LOW_TICKETS:'Pocos boletos',SOLD_OUT:'Agotada',DRAW_SCHEDULED:'Sorteo programado',DRAWING:'Sorteando',COMPLETED:'Completada',CANCELLED:'Cancelada'};

function Results({r}){
 const[w,setW]=useState([]),[loading,setLoading]=useState(true),[err,setErr]=useState('');
 const load=()=>{setLoading(true);api.get(`/draws/${r.id}/winners`).then(x=>setW(x.data)).catch(e=>setErr(e.response?.data?.detail||'No se pudieron cargar los resultados')).finally(()=>setLoading(false))};
 useEffect(()=>{load()},[r.id]);
 if(loading)return <div className="panel"><h2>Resultados</h2><p className="muted">Cargando resultados…</p></div>;
 return <div className="panel results-panel"><div className="section-title"><div><span className="eyebrow">RESULTADOS</span><h2>Ganadores</h2></div><span className="count-pill">{w.length}/{r.winner_count}</span></div>{err?<p className="availability-error">{err}</p>:w.length?<div className="winner-list">{w.map(x=><article className="winner-row" key={x.id}><div className="winner-position">#{x.prize_position}</div><div><b>Ticket #{x.ticket_number}</b><span>{x.prize_description||'Premio'}</span></div><a className="link-btn" href={`/verify/winner/${encodeURIComponent(x.verification_code)}`}>Verificar</a></article>)}</div>:<div className="empty">Todavía no hay ganadores publicados.</div>}</div>
}
export default Results;
