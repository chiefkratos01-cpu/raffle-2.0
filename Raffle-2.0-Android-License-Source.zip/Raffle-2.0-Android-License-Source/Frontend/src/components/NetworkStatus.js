import { useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Network } from '@capacitor/network';

export default function NetworkStatus() {
  const [connected, setConnected] = useState(true);

  useEffect(() => {
    let listener;
    let active = true;
    const updateFromBrowser = () => setConnected(window.navigator.onLine);

    if (Capacitor.isNativePlatform()) {
      Network.getStatus().then((status) => {
        if (active) setConnected(status.connected);
      }).catch(() => {});
      Network.addListener('networkStatusChange', (status) => {
        setConnected(status.connected);
      }).then((handle) => { listener = handle; }).catch(() => {});
    } else {
      window.addEventListener('online', updateFromBrowser);
      window.addEventListener('offline', updateFromBrowser);
      updateFromBrowser();
    }

    return () => {
      active = false;
      listener?.remove();
      if (!Capacitor.isNativePlatform()) {
        window.removeEventListener('online', updateFromBrowser);
        window.removeEventListener('offline', updateFromBrowser);
      }
    };
  }, []);

  if (connected) return null;
  return <div className="network-status" role="status" aria-live="polite">
    Sin conexión. Algunas funciones no estarán disponibles hasta reconectar.
  </div>;
}
