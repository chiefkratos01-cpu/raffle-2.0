import fs from 'fs';
import path from 'path';

const css = () => fs.readFileSync(path.resolve(__dirname, 'App.css'), 'utf8');
const admin = () => fs.readFileSync(path.resolve(__dirname, 'pages/AdminPage.js'), 'utf8');
const roulette = () => fs.readFileSync(path.resolve(__dirname, 'components/Roulette.js'), 'utf8');

test('M36 mobile navigation keeps theme and logout accessible', () => {
  const source = css();
  expect(source).toContain('.topbar nav > .theme-button');
  expect(source).toContain('.topbar nav > .logout-button');
  expect(source).toContain('display: grid !important');
  expect(source).toContain('env(safe-area-inset-bottom)');
});

test('M36 administration uses grouped navigation instead of an endless tab strip', () => {
  expect(admin()).toContain('admin-menu-group');
  expect(admin()).toContain('admin-group-toggle');
  expect(admin()).toContain('General');
  expect(admin()).toContain('Operaciones');
  expect(admin()).toContain('Organización');
  expect(css()).toContain('.admin-tabs');
  expect(css()).toContain('display: none !important');
});

test('M36 roulette has a real multi-turn reveal and server-target recovery', () => {
  const source = roulette();
  expect(source).toContain('const FULL_TURNS = 7;');
  expect(source).toContain('const SPIN_DURATION = 7200;');
  expect(source).toContain('targetAngleFor');
  expect(source).toContain('latest.target_angle');
  expect(source).toContain('visibleWinnerNumber = spinning ? null : winnerNumber');
  expect(css()).toContain('transition: transform 7.2s cubic-bezier(.09,.78,.12,1)');
  expect(css()).toContain('conic-gradient(from -90deg');
});
