import fs from 'fs';
import path from 'path';

const read = (rel) => fs.readFileSync(path.resolve(__dirname, rel), 'utf8');

test('public-facing verification and guide use the icon system instead of emoji UI', () => {
  const files = [
    'pages/HomePage.js',
    'pages/GuidePage.js',
    'pages/TicketVerifyPage.js',
    'pages/OrganizerRequestPage.js',
  ];
  files.forEach((file) => {
    const source = read(file);
    expect(source).not.toMatch(/[🎟🏆🎉🧑💼]/);
  });
  expect(read('pages/HomePage.js')).toContain('UiIcon');
  expect(read('pages/TicketVerifyPage.js')).toContain('verification-winner');
});

test('admin navigation uses consistent vector icons for disclosure controls', () => {
  const source = read('pages/AdminPage.js');
  expect(source).toContain('name="chevronDown"');
  expect(source).toContain('name="chevronRight"');
  expect(read('App.css')).toContain('.admin-chevron-open');
});


test('catalog distinguishes loading, empty, and network-error states', () => {
  const app = read('App.js');
  const home = read('pages/HomePage.js');
  expect(app).toContain("catalogState");
  expect(home).toContain("catalogState === 'error'");
  expect(home).toContain("catalogState === 'loading'");
  expect(home).toContain('Intentar de nuevo');
});


test('public raffle details have a stable shareable URL', () => {
  const app = read('App.js');
  const detail = read('pages/RaffleDetailPage.js');
  expect(app).toMatch(/\/\^\\\/raffle\\\/\\d\+\$\//);
  expect(detail).toContain('raffleShareUrl(r.id)');
  expect(detail).toContain('shareContent({');
});


test('main navigation has stable browser routes', () => {
  const app = read('App.js');
  expect(app).toContain('const routeMap = {');
  ["'/guide': 'guide'", "'/rules': 'rules'", "'/account': 'mine'", "'/admin': 'admin'", "'/login': 'login'", "'/login-organizer': 'login-organizer'"].forEach((route) => expect(app).toContain(route));
});


test('protected routes redirect instead of leaving an empty shell', () => {
  const app = read('App.js');
  expect(app).toMatch(/if\s*\(!auth\s*&&\s*\['mine',\s*'organizer',\s*'admin',\s*'demo'\]\.includes\(view\)\)/);
  expect(app).toMatch(/if\s*\(auth\s*&&\s*admin\s*&&\s*\['mine',\s*'organizer'\]\.includes\(view\)\)/);
});


test('product and developer attribution is visible in the app shell', () => {
  const app = read('App.js');
  expect(app).toContain('© Codexia Systems');
  expect(app).toContain('Developed by Carlos Alejandro Arcia Miranda');
  expect(app).toContain('<ProductAttribution />');
});

test('Android WhatsApp contact uses the native external-link resolver', () => {
  const detail = read('pages/RaffleDetailPage.js');
  const native = read('services/nativeFeatures.js');
  expect(detail).toContain('openExternalUrl(whatsappUrl, event)');
  expect(native).toContain('AppLauncher.openUrl({ url })');
});
