const isProduction = process.env.NODE_ENV === 'production';

const apiUrl = process.env.REACT_APP_API_URL || '';
const configuredSocketUrl = process.env.REACT_APP_SOCKET_URL || '';

const isLocal = (value) =>
  /(^|\/\/)(localhost|127\.0\.0\.1)(:|\/|$)/i.test(value);

const isHttp = (value) => /^http:\/\//i.test(value);

if (isProduction && (!apiUrl || isLocal(apiUrl))) {
  throw new Error('REACT_APP_API_URL must point to the deployed API in production.');
}

const socketUrl =
  configuredSocketUrl ||
  (apiUrl ? apiUrl.replace(/\/api\/v1\/?$/, '') : '');

if (isProduction && (!socketUrl || isLocal(socketUrl))) {
  throw new Error('REACT_APP_SOCKET_URL must point to the deployed realtime server in production.');
}

if (isProduction && (isHttp(apiUrl) || isHttp(socketUrl))) {
  throw new Error('Production API and realtime URLs must use HTTPS.');
}

export const API_URL = isProduction ? apiUrl : '/api/v1';
export const SOCKET_URL = isProduction ? socketUrl : '';
export const LICENSE_PUBLIC_KEY = process.env.REACT_APP_LICENSE_PUBLIC_KEY || '';
export const LICENSE_PRODUCT = process.env.REACT_APP_LICENSE_PRODUCT || 'raffle';
