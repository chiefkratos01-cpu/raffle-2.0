import { fireEvent, render, screen } from '@testing-library/react';
import LoginPage from './LoginPage';

jest.mock('../services/api', () => ({ __esModule: true, default: { post: jest.fn() } }));
import api from '../services/api';

test('password fields can be shown and hidden', () => {
  render(<LoginPage done={jest.fn()} />);
  const input = screen.getByLabelText('Contraseña');
  fireEvent.change(input, { target: { value: 'secret123' } });
  expect(input).toHaveAttribute('type', 'password');
  fireEvent.click(screen.getByRole('button', { name: 'Mostrar contraseña' }));
  expect(input).toHaveAttribute('type', 'text');
  fireEvent.click(screen.getByRole('button', { name: 'Ocultar contraseña' }));
  expect(input).toHaveAttribute('type', 'password');
});

test('registration requires matching password confirmation', () => {
  api.post.mockReset();
  render(<LoginPage done={jest.fn()} />);
  fireEvent.click(screen.getByRole('button', { name: 'Crear una cuenta' }));
  fireEvent.change(screen.getByPlaceholderText('Contraseña'), { target: { value: 'abcdefghijkl' } });
  fireEvent.change(screen.getByPlaceholderText('Repite tu contraseña'), { target: { value: 'different123' } });
  fireEvent.change(screen.getByPlaceholderText('Nombre'), { target: { value: 'Test User' } });
  fireEvent.click(screen.getByRole('button', { name: 'Registrarme' }));
  expect(screen.getByText('Las contraseñas no coinciden.')).toBeInTheDocument();
  expect(api.post).not.toHaveBeenCalled();
});

test('login uses neutral identifier wording and professional password icon markup', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(path.resolve(__dirname, 'LoginPage.js'), 'utf8');
  expect(source).toContain('Correo, teléfono o usuario');
  expect(source).not.toContain('👁️');
  expect(source).not.toContain('🙈');
  expect(source).toContain('password-icon');
});
