import { useEffect, useState } from 'react';
import api from '../services/api';
import NumberPicker from '../components/NumberPicker';
import Results from '../components/Results';
import Toast from '../components/Toast';
import { assetUrl, money, statusLabel } from '../utils/format';
import UiIcon from '../components/UiIcon';
import { openExternalUrl, raffleShareUrl, shareContent } from '../services/nativeFeatures';

function RaffleDetailPage({ r, back, logged, onLogin }) {
  const [sel, setSel] = useState([]), [msg, setMsg] = useState(''), [err, setErr] = useState(''), [res, setRes] = useState(null), [paymentOpen, setPaymentOpen] = useState(false), [payment, setPayment] = useState({ method: '', reference: '', notes: '' }), [payLoading, setPayLoading] = useState(false);
  useEffect(() => {
    const onBack = (event) => {
      if (!paymentOpen) return;
      event.preventDefault();
      setPaymentOpen(false);
    };
    window.addEventListener('raffle:before-back', onBack);
    return () => window.removeEventListener('raffle:before-back', onBack);
  }, [paymentOpen]);
  const reserve = async () => { if (!logged) { onLogin?.(); return; } if (!sel.length) return; try { const x = await api.post('/reservations', { raffle_id: r.id, numbers: sel }); setRes(x.data); setSel([]); setMsg('Reserva creada. Revisa las instrucciones de pago.'); } catch (e) { setErr(e.response?.data?.detail || 'No se pudo reservar.'); } };
  const submitPayment = async () => { if (!res) return; setPayLoading(true); try { const x = await api.post(`/reservations/${res.id}/payment`, { method: payment.method || null, reference: payment.reference || null, notes: payment.notes || null }); setRes(x.data); setPaymentOpen(false); setMsg('Pago enviado a revisión. El organizador debe confirmarlo.'); } catch (e) { setErr(e.response?.data?.detail || 'No se pudo enviar el pago.'); } finally { setPayLoading(false); } };
  const percent = Math.min(100, (r.tickets_sold / r.total_tickets) * 100);
  const shareRaffle = async () => {
    const url = raffleShareUrl(r.id);
    try {
      await shareContent({ title: r.title, text: `Consulta esta rifa: ${r.title}`, url });
      setMsg('Enlace de la rifa listo para compartir.');
    } catch (e) {
      if (e?.name !== 'AbortError') setErr('No pudimos compartir el enlace. Puedes copiarlo desde la barra del navegador.');
    }
  };
  const whatsappUrl = r.organizer_whatsapp
    ? `https://wa.me/${r.organizer_whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(`Hola, quiero información sobre la rifa ${r.title}.` )}`
    : null;

  return <>
    <div className="detail-toolbar"><button className="link-btn" onClick={back}>Volver</button><button className="share-button" onClick={shareRaffle}><UiIcon name="share" size={16} /> Compartir</button></div>
    <div className="raffle-detail-hero">{r.image && <img src={assetUrl(r.image)} alt="Imagen de la rifa" />}<div className="detail-head"><div><span className="small-badge">{statusLabel[r.status] || r.status}</span><h1 className="safe-title">{r.title}</h1><p>{r.description}</p></div><div className="price">{money(r.ticket_price, r.currency)}<small>por boleto</small></div></div></div>
    <div className="panel raffle-progress-panel"><div className="section-title"><div><span className="eyebrow">PARTICIPACIÓN</span><h2>Boletos disponibles</h2></div><b>{r.tickets_sold.toLocaleString()} / {r.total_tickets.toLocaleString()}</b></div><div className="progress large"><span style={{ width: `${percent}%` }} /></div><small className="muted">{Math.max(0, r.total_tickets - r.tickets_sold).toLocaleString()} números todavía disponibles</small></div>
    <div className="panel"><div className="section-title"><div><span className="eyebrow">SELECCIÓN</span><h2>Tus números</h2></div><span className="count-pill">{sel.length}</span></div><NumberPicker r={r} selected={sel} setSelected={setSel} /><div className="reserve-bar"><b>{sel.length} · {money(sel.length * Number(r.ticket_price), r.currency)}</b><button className="primary" disabled={!sel.length || !['OPEN', 'LOW_TICKETS'].includes(r.status)} onClick={reserve}>{logged ? 'Reservar boletos' : 'Entrar para reservar'}</button></div></div>
    {r.rules && <div className="panel"><h2>Reglas de la rifa</h2><p className="preline">{r.rules}</p></div>}
    {(r.status === 'COMPLETED' || r.status === 'DRAWING' || r.tickets_sold > 0) && <Results r={r} />}
    {(r.organizer_name || r.organizer_whatsapp || r.organizer_phone) && <div className="panel"><span className="eyebrow">ORGANIZADOR</span><h2>{r.organizer_name || 'Organizador'}</h2>{whatsappUrl && <a className="primary as-button" target="_blank" rel="noreferrer" href={whatsappUrl} onClick={(event) => { void openExternalUrl(whatsappUrl, event); }}>Contactar por WhatsApp</a>}</div>}
    <Toast message={err} error onClose={() => setErr('')} /><Toast message={msg} onClose={() => setMsg('')} />
    {res && <div className="success-card"><span className="eyebrow">RESERVA {res.status}</span><h2>{res.code}</h2><p>Números: {res.tickets.map(t => '#' + t.number).join(', ')}</p><p>{r.payment_instructions || 'Contacta al organizador para acordar el pago.'}</p>{res.status !== 'PAYMENT_REVIEW' && res.status !== 'CONFIRMED' && <button className="primary" onClick={() => setPaymentOpen(true)}>Ya pagué</button>}{res.status === 'PAYMENT_REVIEW' && <p className="muted">Tu pago está pendiente de revisión por el organizador.</p>}{res.status === 'CONFIRMED' && <p className="success-text">Pago confirmado. Tus boletos ya están asegurados.</p>}</div>}
    {paymentOpen && <div className="modal-backdrop"><div className="modal-card"><div className="section-title"><div><span className="eyebrow">PAGO</span><h2>Enviar información del pago</h2></div><button onClick={() => setPaymentOpen(false)}>×</button></div><p className="muted">Indica cómo realizaste el pago. Esto no confirma el pago por sí solo.</p><div className="form-grid single"><label>Método<select value={payment.method} onChange={e => setPayment({ ...payment, method: e.target.value })}><option value="">Seleccionar</option><option value="CASH">Efectivo</option><option value="BANK_TRANSFER">Transferencia bancaria</option><option value="MOBILE_TRANSFER">Transferencia móvil</option><option value="OTHER">Otro</option></select></label><label>Referencia (opcional)<input value={payment.reference} onChange={e => setPayment({ ...payment, reference: e.target.value })} maxLength="120" placeholder="Referencia de la operación" /></label><label>Nota (opcional)<textarea value={payment.notes} onChange={e => setPayment({ ...payment, notes: e.target.value })} placeholder="Información adicional" /></label></div><div className="editor-actions"><button onClick={() => setPaymentOpen(false)}>Cancelar</button><button className="primary" disabled={payLoading} onClick={submitPayment}>{payLoading ? 'Enviando…' : 'Enviar información'}</button></div></div></div>}
  </>;
}
export default RaffleDetailPage;
