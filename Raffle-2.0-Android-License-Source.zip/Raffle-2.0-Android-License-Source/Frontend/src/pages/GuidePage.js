import { useState } from 'react';
import UiIcon from '../components/UiIcon';

const customer = [
  ['1', 'Crea tu cuenta', 'Regístrate gratis para poder reservar boletos y consultar tus participaciones.'],
  ['2', 'Elige una rifa', 'Explora las rifas disponibles y revisa sus detalles y reglas.'],
  ['3', 'Selecciona tus boletos', 'Toca los números que quieras. Los que ya estén ocupados no podrán seleccionarse.'],
  ['4', 'Haz tu reserva', 'Confirma los boletos elegidos y revisa las instrucciones para realizar el pago.'],
  ['5', 'Realiza el pago', 'Paga al organizador por el medio indicado.'],
  ['6', 'Envía la información del pago', 'Si la rifa lo solicita, indica cómo realizaste el pago y añade la referencia correspondiente.'],
  ['7', 'Espera la confirmación', 'El organizador revisará el pago. Cuando lo confirme, tus boletos quedarán asegurados.'],
  ['8', 'Consulta tus boletos', 'Desde Mi cuenta puedes ver tus boletos pagados y su código de verificación.'],
  ['9', 'Verifica', 'Puedes abrir o escanear el código para comprobar la información del boleto.'],
  ['10', 'Consulta el resultado', 'Después del sorteo podrás consultar los ganadores y verificar el resultado.'],
];

const admin = [
  ['1', 'Conoce el panel', 'El panel reúne tus rifas, reservas, pagos, sorteos y herramientas de administración.'],
  ['2', 'Crea una rifa', 'Añade el nombre, precio, cantidad de boletos, fecha, premios y las condiciones que quieras mostrar.'],
  ['3', 'Configura las reservas', 'Decide si las reservas tendrán liberación automática y cuánto tiempo tendrán para completar el pago.'],
  ['4', 'Publica', 'Revisa los datos y publica la rifa cuando esté lista para recibir participantes.'],
  ['5', 'Revisa pagos', 'Comprueba los pagos enviados por los participantes y confirma o rechaza cada uno.'],
  ['6', 'Realiza el sorteo', 'Cuando llegue el momento, inicia el sorteo desde el panel. La plataforma se encarga de seleccionar el resultado.'],
  ['7', 'Consulta ganadores', 'Revisa el resultado y su comprobación para compartirlo con los participantes.'],
  ['8', 'Gestiona tu equipo', 'Si trabajas con otras personas, puedes darles el acceso que corresponda según sus tareas.'],
  ['9', 'Gestiona tu licencia', 'Consulta el estado de la licencia y renueva cuando sea necesario.'],
];

function Steps({ items }) { return <div className="guide-steps">{items.map(([n, title, text]) => <article className="guide-step" key={n}><span>{n}</span><div><h3>{title}</h3><p>{text}</p></div></article>)}</div>; }

export default function GuidePage() {
  const [mode, setMode] = useState('customer');
  return <div className="info-page"><div className="page-title"><div><span className="badge">GUÍA</span><h1>Aprende a usar Raffle 2.0</h1><p className="muted">Pasos cortos para empezar sin tener que leer un manual interminable.</p></div></div><div className="guide-switch"><button className={mode === 'customer' ? 'active' : ''} onClick={() => setMode('customer')}><><UiIcon name="ticket" size={17} /> Soy cliente</></button><button className={mode === 'admin' ? 'active' : ''} onClick={() => setMode('admin')}><><UiIcon name="user" size={17} /> Soy administrador</></button></div><div className="panel"><h2>{mode === 'customer' ? 'Cómo participar en una rifa' : 'Cómo administrar tus rifas'}</h2><Steps items={mode === 'customer' ? customer : admin} /></div></div>;
}
