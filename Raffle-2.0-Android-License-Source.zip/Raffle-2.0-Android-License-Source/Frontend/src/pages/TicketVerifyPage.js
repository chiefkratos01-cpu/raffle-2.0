import {useEffect,useState} from 'react';
import api from '../services/api';
import UiIcon from '../components/UiIcon';

const ticketStatus = {
  RESERVED: 'Reservado',
  PAID: 'Pago confirmado',
  CANCELLED: 'Cancelado',
  RELEASED: 'Liberado',
};

function TicketVerifyPage({code}){const[data,setData]=useState(null),[err,setErr]=useState('');useEffect(()=>{api.get(`/tickets/verify/${encodeURIComponent(code)}`).then(x=>setData(x.data)).catch(e=>setErr(e.response?.data?.detail||'Código no válido'))},[code]);if(err)return <div className="verify-card"><span className="badge">VERIFICACIÓN</span><h1>Código no válido</h1><p>{err}</p></div>;if(!data)return <div className="verify-card"><span className="badge">VERIFICACIÓN</span><h1>Verificando…</h1></div>;return <div className="verify-card"><span className="badge">BOLETO AUTÉNTICO</span><h1 className="safe-title">#{data.ticket_number}</h1><h2>{data.raffle_title}</h2><div className="verify-status"><b>{ticketStatus[data.status] || data.status}</b>{data.is_winner&&<strong className="verification-winner"><UiIcon name="trophy" size={18}/> Ganador · Premio #{data.prize_position}</strong>}</div>{data.is_winner&&<p>{data.prize_description}</p>}<code>{data.verification_code}</code><p className="muted">Este código permite comprobar que el boleto pertenece a esta rifa.</p></div>}
export default TicketVerifyPage;
