import { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import api from '../services/api';
import Toast from '../components/Toast';
import { subscribeToNotifications } from '../services/socket';
import SessionManager from '../components/SessionManager';
import { verificationUrl } from '../services/nativeFeatures';

function AccountPage() {
  const [reservations, setReservations] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [message, setMessage] = useState('');

  const load = async () => {
    try {
      const [reservationResponse, ticketResponse, notificationResponse] = await Promise.all([
        api.get('/reservations/mine'), api.get('/users/tickets'), api.get('/notifications/mine'),
      ]);
      setReservations(reservationResponse.data);
      setTickets(ticketResponse.data);
      setNotifications(notificationResponse.data);
    } catch (error) {
      setMessage(error.response?.data?.detail || 'No se pudo cargar tu cuenta.');
    }
  };

  useEffect(() => {
    load();
    let stop;
    subscribeToNotifications((notification) => setNotifications((previous) => previous.some((item) => item.id === notification.id)
      ? previous
      : [notification, ...previous].slice(0, 100))).then((unsubscribe) => { stop = unsubscribe; }).catch(() => {});
    return () => stop?.();
  }, []);

  const reportPayment = async (id) => {
    try {
      await api.post(`/reservations/${id}/payment`, { notes: 'Cliente indicó que ya realizó el pago' });
      setMessage('Pago enviado a revisión.');
      await load();
    } catch (error) {
      setMessage(error.response?.data?.detail || 'No se pudo enviar.');
    }
  };

  const markRead = async (id) => {
    try {
      const response = await api.post(`/notifications/${id}/read`);
      setNotifications((previous) => previous.map((notification) => notification.id === id ? response.data : notification));
    } catch {
      setMessage('No se pudo actualizar la notificación.');
    }
  };

  const markAllRead = async () => {
    try {
      await api.post('/notifications/read-all');
      setNotifications((previous) => previous.map((notification) => ({ ...notification, is_read: true })));
    } catch {
      setMessage('No se pudieron marcar como leídas.');
    }
  };

  const unread = notifications.filter((notification) => !notification.is_read).length;

  return <>
    <div className="page-title"><div><span className="eyebrow">CLIENTE</span><h1>Mi cuenta</h1></div>{unread > 0 && <span className="badge">{unread} sin leer</span>}</div>
    <Toast message={message} onClose={() => setMessage('')} />
    <div className="panel"><h2>Mis reservas</h2>{reservations.length ? reservations.map((reservation) => <div className="row" key={reservation.id}>
      <div><b>{reservation.code}</b><span>{reservation.tickets.map((ticket) => `#${ticket.number}`).join(', ')}</span></div>
      <div className="row-actions"><span className="small-badge">{reservation.status}</span>{['ACTIVE', 'PAYMENT_REVIEW'].includes(reservation.status) && <button onClick={() => reportPayment(reservation.id)}>Ya pagué</button>}</div>
    </div>) : <div className="empty">Todavía no tienes reservas.</div>}</div>
    <div className="panel"><h2>Boletos pagados</h2><div className="ticket-list">{tickets.map((ticket) => {
      const verifyUrl = verificationUrl('ticket', ticket.verification_code);
      return <div className="ticket-card" key={ticket.id}>
        <div className="ticket-info"><span className="eyebrow">BOLETO VERIFICADO</span><b>#{ticket.number}</b><small>{ticket.paid_at ? `Pagado · ${new Date(ticket.paid_at).toLocaleString()}` : 'Pago confirmado'}</small><code>{ticket.verification_code}</code><a className="link-btn" href={verifyUrl}>Abrir verificación</a></div>
        <div className="ticket-qr"><QRCodeSVG value={verifyUrl} size={128} includeMargin level="M" /><small>Escanear para verificar</small></div>
      </div>;
    })}</div></div>
    <SessionManager />
    <div className="panel"><div className="section-title"><div><h2>Notificaciones</h2><span className="muted">Avisos importantes de tus reservas y rifas.</span></div>{unread > 0 && <button onClick={markAllRead}>Marcar todo como leído</button>}</div>
      {notifications.length ? notifications.map((notification) => <div className={`notification ${notification.is_read ? 'read' : 'unread'}`} key={notification.id}>
        <div className="notification-head"><b>{notification.title}</b><small>{notification.created_at ? new Date(notification.created_at).toLocaleString() : ''}</small></div><p>{notification.message}</p>{!notification.is_read && <button className="link-btn" onClick={() => markRead(notification.id)}>Marcar como leído</button>}
      </div>) : <div className="empty">Sin notificaciones.</div>}
    </div>
  </>;
}

export default AccountPage;
