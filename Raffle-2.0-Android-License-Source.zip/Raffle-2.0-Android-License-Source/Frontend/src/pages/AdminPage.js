import { useEffect, useMemo, useState } from 'react';
import api from '../services/api';
import Toast from '../components/Toast';
import LicensePanel from '../LicensePanel';
import RaffleEditor from '../components/RaffleEditor';
import Roulette from '../components/Roulette';
import { statusLabel } from '../utils/format';
import SessionManager from '../components/SessionManager';
import UiIcon from '../components/UiIcon';

const PERMS = {
  ADMIN: ['dashboard:read', 'raffle:write', 'draw:write', 'draw:read', 'reservation:read', 'customer:read', 'audit:read', 'license:read', 'team:read', 'team:manage'],
  OPERATOR: ['reservation:read', 'reservation:write', 'draw:write', 'customer:read', 'raffle:read'],
  FINANCE: ['reservation:read', 'payment:write', 'customer:read'],
  VIEWER: ['raffle:read', 'draw:read', 'reservation:read', 'customer:read', 'audit:read', 'license:read'],
};

const can = (role, permission) => role === 'SUPER_ADMIN' || (PERMS[role] || []).includes(permission);

function AdminIcon({ name }) {
  const paths = {
    general: <path d="M3 9.5 10 3l7 6.5v7a1 1 0 0 1-1 1h-4v-5H8v5H4a1 1 0 0 1-1-1z" />,
    raffles: <><path d="M4 4h12v12H4z" /><path d="M7 7h6M7 10h6M7 13h3" /></>,
    operations: <><path d="M5 3h10v14H5z" /><path d="M7.5 7h5M7.5 10h5M7.5 13h3" /></>,
    draws: <><circle cx="10" cy="10" r="6.5" /><path d="m10 5 1.5 3.5L15 10l-3.5 1.5L10 15l-1.5-3.5L5 10l3.5-1.5z" /></>,
    organization: <><circle cx="10" cy="7" r="2.5" /><path d="M5 17a5 5 0 0 1 10 0M3 18h14" /></>,
    security: <><path d="M10 2.8 16 5v4.5c0 3.7-2.4 6.4-6 7.7-3.6-1.3-6-4-6-7.7V5z" /><path d="m7.3 10 1.8 1.8 3.8-4" /></>,
    license: <><path d="M5 3h10v14H5z" /><path d="M7.5 7h5M7.5 10h5M7.5 13h2.5" /></>,
    demo: <><circle cx="10" cy="10" r="6.5" /><path d="m10 6 1.3 2.7L14 10l-2.7 1.3L10 14l-1.3-2.7L6 10l2.7-1.3z" /></>,
  };
  return <svg className="admin-group-svg" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

const GROUPS = [
  {
    id: 'general',
    label: 'General',
    description: 'Vista general y actividad de la plataforma.',
    items: [['dashboard', 'Resumen', 'dashboard:read']],
  },
  {
    id: 'raffles',
    label: 'Rifas',
    description: 'Crea, publica y administra tus rifas.',
    items: [['raffles', 'Mis rifas', 'raffle:read']],
  },
  {
    id: 'operations',
    label: 'Operaciones',
    description: 'Reservas, pagos y clientes.',
    items: [['payments', 'Pagos', 'reservation:read'], ['users', 'Clientes', 'customer:read']],
  },
  {
    id: 'draws',
    label: 'Sorteos',
    description: 'Ejecuta sorteos y consulta resultados.',
    items: [['draws', 'Centro de sorteos', 'draw:read']],
  },
  {
    id: 'organization',
    label: 'Organización',
    description: 'Equipo y solicitudes de nuevos organizadores.',
    items: [['team', 'Equipo', 'team:read'], ['admins', 'Administradores', 'SUPER_ADMIN'], ['organizers', 'Solicitudes', 'SUPER_ADMIN']],
  },
  {
    id: 'security',
    label: 'Seguridad',
    description: 'Trazabilidad y sesiones administrativas.',
    items: [['audit', 'Auditoría', 'audit:read'], ['sessions', 'Sesiones', 'SUPER_ADMIN']],
  },
  {
    id: 'license',
    label: 'Licencia',
    description: 'Estado y administración de la licencia.',
    items: [['license', 'Estado de licencia', 'license:read']],
  },
  {
    id: 'demo',
    label: 'Demostración',
    description: 'Experiencia aislada para mostrar la plataforma.',
    items: [['demo', 'Probar demo', 'DEMO']],
  },
];

export default function AdminPage({ refreshPublic, adminRole, openDemo }) {
  const [summary, setSummary] = useState(null);
  const [raffles, setRaffles] = useState([]);
  const [payments, setPayments] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [users, setUsers] = useState([]);
  const [team, setTeam] = useState([]);
  const [requests, setRequests] = useState([]);
  const [audits, setAudits] = useState([]);
  const [history, setHistory] = useState([]);
  const [msg, setMsg] = useState('');
  const [edit, setEdit] = useState(undefined);
  const [tab, setTab] = useState('dashboard');
  const [openGroup, setOpenGroup] = useState('general');
  const [roulette, setRoulette] = useState(null);
  const [busy, setBusy] = useState(false);
  const [license, setLicense] = useState(null);
  const [credentialDialog, setCredentialDialog] = useState(null);

  const allowed = useMemo(() => {
    const result = new Map();
    GROUPS.forEach((group) => {
      group.items.forEach(([id, title, permission]) => {
        const visible = permission === 'SUPER_ADMIN'
          ? adminRole === 'SUPER_ADMIN'
          : permission === 'DEMO'
            ? adminRole === 'SUPER_ADMIN' || adminRole === 'ADMIN'
            : can(adminRole, permission);
        if (visible) result.set(id, { id, title, group: group.id });
      });
    });
    return result;
  }, [adminRole]);

  const visibleGroups = useMemo(
    () => GROUPS.map((group) => ({ ...group, items: group.items.filter(([id]) => allowed.has(id)) })).filter((group) => group.items.length),
    [allowed],
  );

  const load = async () => {
    try {
      const [a, b, c, l] = await Promise.all([
        api.get('/admin/dashboard/summary'),
        api.get('/admin/dashboard/raffles'),
        api.get('/admin/reservations/pending'),
        api.get('/license/status'),
      ]);
      setSummary(a.data);
      setRaffles(b.data);
      setPayments(c.data);
      setLicense(l.data);
    } catch (e) {
      setMsg(e.response?.data?.detail || 'No se pudo cargar el panel.');
    }
  };

  const loadAdmins = async () => {
    try { setAdmins((await api.get('/admin/security/admins')).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudieron cargar los administradores.'); }
  };

  const loadUsers = async () => {
    try { setUsers((await api.get('/admin/users')).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudieron cargar los clientes.'); }
  };

  const loadTeam = async () => {
    try { setTeam((await api.get('/admin/team')).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cargar el equipo.'); }
  };

  const loadRequests = async () => {
    try { setRequests((await api.get('/admin/organizers/requests')).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudieron cargar las solicitudes.'); }
  };

  const loadAudits = async () => {
    try { setAudits((await api.get('/admin/audit?limit=80')).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cargar la auditoría.'); }
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    const onBack = (event) => {
      if (credentialDialog) {
        event.preventDefault();
        setCredentialDialog(null);
        return;
      }
      if (roulette) {
        event.preventDefault();
        setRoulette(null);
        return;
      }
      if (edit !== undefined) {
        event.preventDefault();
        setEdit(undefined);
      }
    };
    window.addEventListener('raffle:before-back', onBack);
    return () => window.removeEventListener('raffle:before-back', onBack);
  }, [credentialDialog, roulette, edit]);

  useEffect(() => {
    if (tab === 'admins') loadAdmins();
    if (tab === 'users') loadUsers();
    if (tab === 'team') loadTeam();
    if (tab === 'organizers') loadRequests();
    if (tab === 'audit') loadAudits();
  }, [tab]);

  useEffect(() => {
    if (!allowed.has(tab)) {
      const first = visibleGroups[0]?.items[0]?.[0] || 'dashboard';
      setTab(first);
      setOpenGroup(visibleGroups[0]?.id || 'general');
    } else {
      setOpenGroup(allowed.get(tab)?.group || 'general');
    }
  }, [allowed, tab, visibleGroups]);

  const selectTab = (id) => {
    if (id === 'demo') {
      openDemo();
      return;
    }
    setTab(id);
  };

  const loadHistory = async (id) => {
    try { setHistory((await api.get(`/draws/${id}/history`)).data); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cargar el historial.'); }
  };

  const pay = async (id, yes) => {
    let reason = '';
    if (!yes) {
      reason = window.prompt('Motivo del rechazo:', 'Pago no verificado') || '';
      if (!reason.trim()) return;
    }
    try {
      setBusy(true);
      await api.post(`/admin/reservations/${id}/${yes ? 'confirm' : 'reject'}`, yes ? {} : { rejection_reason: reason.trim() });
      setMsg(yes ? 'Pago confirmado y boletos asegurados.' : 'Pago rechazado y boletos liberados.');
      load();
    } catch (e) {
      setMsg(e.response?.data?.detail || 'No se pudo actualizar el pago.');
    } finally { setBusy(false); }
  };

  const publish = async (id) => {
    try { await api.post(`/raffles/${id}/publish`); setMsg('Rifa publicada.'); load(); refreshPublic(); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo publicar la rifa.'); }
  };

  const cancel = async (id) => {
    if (!window.confirm('¿Cancelar esta rifa?')) return;
    try { await api.post(`/raffles/${id}/cancel`); setMsg('Rifa cancelada.'); load(); refreshPublic(); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cancelar la rifa.'); }
  };

  const draw = async (id, pos) => {
    try {
      await api.post(`/draws/${id}`, { prize_position: pos });
      setMsg(`Sorteo iniciado para el premio #${pos}.`);
      setRoulette(raffles.find((r) => r.id === id) || null);
      load();
    } catch (e) { setMsg(e.response?.data?.detail || 'No se pudo iniciar el sorteo.'); }
  };

  const openCredentialDialog = (kind) => {
    setCredentialDialog({
      kind,
      username: '',
      password: '',
      email: '',
      phone: '',
      role: 'VIEWER',
    });
  };

  const submitCredentialDialog = async (event) => {
    event.preventDefault();
    if (!credentialDialog) return;
    const { kind, username, password, email, phone, role } = credentialDialog;
    if (password.length < 12 || /\s/.test(password) || new Set(password).size < 5) {
      setMsg('La contraseña debe tener al menos 12 caracteres variados y no contener espacios.');
      return;
    }
    try {
      const endpoint = kind === 'admin' ? '/admin/security/admins' : '/admin/team';
      await api.post(endpoint, {
        username: username.trim(),
        password,
        email: email.trim() || null,
        phone: phone.trim() || null,
        role,
      });
      setMsg(kind === 'admin' ? 'Administrador creado.' : 'Miembro añadido al equipo.');
      setCredentialDialog(null);
      if (kind === 'admin') loadAdmins(); else loadTeam();
    } catch (e) {
      setMsg(e.response?.data?.detail || 'No se pudo crear el acceso.');
    }
  };

  const toggleAdmin = async (a) => {
    try { await api.patch(`/admin/security/admins/${a.id}/status`, { is_active: !a.is_active }); setMsg(`Acceso ${a.is_active ? 'desactivado' : 'activado'}.`); loadAdmins(); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cambiar el acceso.'); }
  };

  const addTeam = async () => openCredentialDialog('team');
  const toggleTeam = async (a) => {
    try { await api.patch(`/admin/team/${a.id}/status`, { is_active: !a.is_active }); setMsg(`Acceso ${a.is_active ? 'desactivado' : 'activado'}.`); loadTeam(); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cambiar el acceso.'); }
  };

  const toggleUser = async (u) => {
    if (adminRole !== 'SUPER_ADMIN') return;
    try { await api.patch(`/admin/users/${u.id}/status`, { is_active: !u.is_active }); setMsg(`Cuenta ${u.is_active ? 'desactivada' : 'activada'}.`); loadUsers(); }
    catch (e) { setMsg(e.response?.data?.detail || 'No se pudo cambiar la cuenta.'); }
  };

  const decideRequest = async (r, approve) => {
    try {
      if (!approve) {
        const reason = window.prompt('Motivo (opcional):', 'Solicitud no aprobada') || 'Solicitud no aprobada';
        await api.post(`/admin/organizers/requests/${r.id}/reject`, { reason });
      } else await api.post(`/admin/organizers/requests/${r.id}/approve`, {});
      setMsg(approve ? `Organizador aprobado: ${r.desired_username}.` : 'Solicitud rechazada.');
      loadRequests();
    } catch (e) { setMsg(e.response?.data?.detail || 'No se pudo resolver la solicitud.'); }
  };

  if (edit !== undefined) {
    return <>
      <button className="link-btn" onClick={() => setEdit(undefined)}>← Volver al panel</button>
      <div className="page-title"><div><span className="eyebrow">RIFAS</span><h1>{edit ? 'Editar rifa' : 'Nueva rifa'}</h1></div></div>
      <RaffleEditor initial={edit || null} onCancel={() => setEdit(undefined)} onDone={() => { setEdit(undefined); setMsg('Rifa guardada.'); load(); refreshPublic(); }} />
    </>;
  }

  return <>
    <div className="admin-head">
      <div>
        <span className="small-badge">CENTRO DE CONTROL</span>
        <h1>{adminRole === 'VIEWER' ? 'Panel de consulta' : 'Administración'}</h1>
        <p>Gestiona las funciones disponibles para tu cuenta.</p>
      </div>
      {can(adminRole, 'raffle:write') && <button className="primary admin-create-button" onClick={() => setEdit(null)}>Nueva rifa</button>}
    </div>

    <Toast message={msg} onClose={() => setMsg('')} />

    {license && <div className={`license-banner ${license.active ? 'good' : 'warning'}`}>
      <b>{license.mode === 'TRIAL' ? 'Periodo de prueba' : license.mode === 'COMMERCIAL' ? 'Licencia comercial' : license.mode === 'EXPIRED' ? 'Licencia vencida' : 'Sin licencia'}</b>
      <span>{license.active ? license.days_remaining == null ? 'Operación habilitada' : `${license.days_remaining} días restantes` : 'Las operaciones nuevas que requieren licencia están bloqueadas.'}</span>
    </div>}

    <div className="admin-layout">
      <aside className="admin-menu" aria-label="Secciones de administración">
        <div className="admin-menu-title"><span className="eyebrow">NAVEGACIÓN</span><strong>Centro de control</strong></div>
        {visibleGroups.map((group) => {
          const expanded = openGroup === group.id;
          return <section className={`admin-menu-group ${expanded ? 'open' : ''}`} key={group.id}>
            <button className="admin-group-toggle" type="button" aria-expanded={expanded} onClick={() => setOpenGroup(expanded ? '' : group.id)}>
              <span className="admin-group-icon"><AdminIcon name={group.id} /></span>
              <span><b>{group.label}</b><small>{group.description}</small></span>
              <span className="admin-chevron" aria-hidden="true"><UiIcon name="chevronDown" size={16} className={expanded ? "admin-chevron-open" : ""} /></span>
            </button>
            {expanded && <div className="admin-submenu">
              {group.items.map(([id, title]) => <button key={id} type="button" className={tab === id ? "active" : ""} onClick={() => selectTab(id)}>{title}<UiIcon name="chevronRight" size={15} /></button>)}
            </div>}
          </section>;
        })}
      </aside>

      <section className="admin-workspace">
        <div className="admin-current-section">
          <span className="small-badge">{allowed.get(tab)?.title || 'Panel'}</span>
          <span className="admin-current-group">{visibleGroups.find((group) => group.id === openGroup)?.label || 'Centro de control'}</span>
        </div>

        {tab === 'dashboard' && summary && <div className="stats">{Object.entries({ Rifas: summary.raffles, Abiertas: summary.open_raffles, Clientes: summary.users, 'Boletos pagados': summary.paid_tickets, 'Pagos pendientes': summary.pending_payments }).map(([k, v]) => <div className="stat" key={k}><span>{k}</span><b>{v}</b></div>)}</div>}

        {tab === 'payments' && <div className="panel"><div className="section-title"><div><span className="eyebrow">OPERACIONES</span><h2>Pagos pendientes</h2></div><button onClick={load}>Actualizar</button></div><p className="muted">Confirma solo cuando hayas comprobado el pago recibido por el organizador.</p>{payments.length ? payments.map((r) => <div className="row" key={r.id}><div><b>{r.code}</b><span>{r.tickets.map((t) => `#${t.number}`).join(', ')}</span></div><div className="row-actions"><span className="small-badge">{r.status}</span>{can(adminRole, 'payment:write') && <><button className="primary" disabled={busy} onClick={() => pay(r.id, true)}>Confirmar</button><button disabled={busy} onClick={() => pay(r.id, false)}>Rechazar</button></>}</div></div>) : <div className="empty">No hay pagos pendientes.</div>}</div>}

        {tab === 'raffles' && <div className="panel"><div className="section-title"><div><span className="eyebrow">RIFAS</span><h2>Mis rifas</h2></div>{can(adminRole, 'raffle:write') && <button className="primary" onClick={() => setEdit(null)}>Nueva rifa</button>}</div>{raffles.length ? raffles.map((r) => <div className="row" key={r.id}><div><b className="safe-title">{r.title}</b><span>{statusLabel[r.status] || r.status} · {r.tickets_sold}/{r.total_tickets} vendidos</span></div><div className="row-actions">{can(adminRole, 'raffle:write') && <button onClick={() => setEdit(r)}>Editar</button>}{can(adminRole, 'raffle:write') && r.status === 'DRAFT' && <button className="primary" onClick={() => publish(r.id)}>Publicar</button>}{can(adminRole, 'raffle:write') && !['COMPLETED', 'CANCELLED'].includes(r.status) && <button onClick={() => cancel(r.id)}>Cancelar</button>}</div></div>) : <div className="empty">No hay rifas reales.</div>}</div>}

        {tab === 'draws' && <div className="panel"><div className="section-title"><div><span className="eyebrow">SORTEOS</span><h2>Centro de sorteos</h2></div></div><p className="muted">Las rifas reales requieren boletos pagados. El resultado es decidido por el servidor y la ruleta solo lo representa visualmente.</p>{raffles.map((r) => <div className="row" key={r.id}><div><b className="safe-title">{r.title}</b><span>{r.winner_count} ganador{r.winner_count !== 1 ? 'es' : ''} · {statusLabel[r.status] || r.status}</span></div><div className="row-actions">{can(adminRole, 'draw:write') && !['COMPLETED', 'CANCELLED', 'DRAWING'].includes(r.status) && Array.from({ length: r.winner_count }, (_, i) => i + 1).map((pos) => <button className="primary" key={pos} onClick={() => draw(r.id, pos)}>Sortear #{pos}</button>)}<button onClick={() => loadHistory(r.id)}>Historial</button></div></div>)}{history.length > 0 && <div className="history-list"><h3>Historial seleccionado</h3>{history.map((d) => <div className="audit-row" key={d.id}><div><b>Premio #{d.prize_position} · {d.status}</b><span>{d.completed_at ? new Date(d.completed_at).toLocaleString() : 'En proceso'} · {d.eligible_count ?? '—'} elegibles</span></div><code>{d.result_hash || 'Sin huella'}</code></div>)}</div>}</div>}

        {tab === 'users' && <div className="panel"><div className="section-title"><div><span className="eyebrow">CLIENTES</span><h2>Personas registradas</h2></div><button onClick={loadUsers}>Actualizar</button></div>{users.length ? users.map((u) => <div className="row" key={u.id}><div><b>{u.name}</b><span>{u.email || u.phone || 'Sin contacto'} · {u.is_active ? 'Activo' : 'Inactivo'}</span></div><div className="row-actions">{adminRole === 'SUPER_ADMIN' && <button onClick={() => toggleUser(u)}>{u.is_active ? 'Desactivar' : 'Activar'}</button>}</div></div>) : <div className="empty">No hay clientes registrados.</div>}</div>}

        {tab === 'team' && <div className="panel"><div className="section-title"><div><span className="eyebrow">EQUIPO</span><h2>Miembros con acceso</h2></div>{can(adminRole, 'team:manage') && <button className="primary" onClick={addTeam}>Añadir miembro</button>}</div><p className="muted">Cada persona tiene su propio acceso y solo recibe los permisos que necesita.</p>{team.length ? team.map((a) => <div className="row" key={a.id}><div><b>{a.username}</b><span>{a.role} · {a.email || 'Sin correo'} · {a.is_active ? 'Activo' : 'Inactivo'}</span></div><div className="row-actions">{can(adminRole, 'team:manage') && a.role !== 'SUPER_ADMIN' && <button onClick={() => toggleTeam(a)}>{a.is_active ? 'Desactivar' : 'Activar'}</button>}</div></div>) : <div className="empty">No hay otros miembros del equipo.</div>}</div>}

        {tab === 'admins' && adminRole === 'SUPER_ADMIN' && <div className="panel"><div className="section-title"><div><span className="eyebrow">SEGURIDAD</span><h2>Administradores</h2></div><button className="primary" onClick={() => openCredentialDialog('admin')}>Crear administrador</button></div><p className="muted">Solo el SUPER_ADMIN puede gestionar administradores generales.</p>{admins.map((a) => <div className="row" key={a.id}><div><b>{a.username}</b><span>{a.role} · {a.email || 'Sin correo'} · {a.is_active ? 'Activo' : 'Inactivo'}</span></div><div className="row-actions"><button onClick={() => toggleAdmin(a)}>{a.is_active ? 'Desactivar' : 'Activar'}</button></div></div>)}</div>}

        {tab === 'organizers' && adminRole === 'SUPER_ADMIN' && <div className="panel"><div className="section-title"><div><span className="eyebrow">ORGANIZADORES</span><h2>Solicitudes</h2></div><button onClick={loadRequests}>Actualizar</button></div><p className="muted">Revisa a las personas que quieren organizar sus propias rifas.</p>{requests.length ? requests.map((r) => <div className="row" key={r.id}><div><b>{r.applicant_name || 'Solicitante'} · {r.desired_username}</b><span>{r.business_name || 'Sin nombre comercial'} · {r.email || r.phone || 'Sin contacto'} · {r.status}</span>{r.notes && <span>{r.notes}</span>}</div><div className="row-actions">{r.status === 'PENDING' && <><button className="primary" onClick={() => decideRequest(r, true)}>Aprobar</button><button onClick={() => decideRequest(r, false)}>Rechazar</button></>}</div></div>) : <div className="empty">No hay solicitudes.</div>}</div>}

        {tab === 'sessions' && adminRole === 'SUPER_ADMIN' && <SessionManager />}

        {tab === 'audit' && <div className="panel"><div className="section-title"><div><span className="eyebrow">TRAZABILIDAD</span><h2>Registro de auditoría</h2></div><button onClick={loadAudits}>Actualizar</button></div>{audits.length ? audits.map((a) => <div className="audit-row" key={a.id}><div><b>{a.action}</b><span>{a.entity_type} #{a.entity_id || '—'} · {a.created_at ? new Date(a.created_at).toLocaleString() : '—'}</span></div><code>{JSON.stringify(a.new_value || a.details || {}, null, 0)}</code></div>) : <div className="empty">No hay eventos de auditoría.</div>}</div>}

        {tab === 'license' && <LicensePanel />}
      </section>
    </div>

    {credentialDialog && <div className="modal-backdrop">
      <div className="modal-card credential-modal" role="dialog" aria-modal="true" aria-labelledby="credential-dialog-title">
        <div className="section-title">
          <div>
            <span className="eyebrow">ACCESO</span>
            <h2 id="credential-dialog-title">{credentialDialog.kind === 'admin' ? 'Crear administrador' : 'Añadir miembro'}</h2>
          </div>
          <button type="button" onClick={() => setCredentialDialog(null)} aria-label="Cerrar">×</button>
        </div>
        <p className="muted">Cada persona debe tener credenciales propias. La contraseña no se muestra ni se guarda en el navegador.</p>
        <form className="credential-form" onSubmit={submitCredentialDialog}>
          <label className="stacked-field"><span>Nombre de acceso</span><input required minLength={3} maxLength={80} pattern="[A-Za-z0-9_.-]+" value={credentialDialog.username} onChange={e => setCredentialDialog({ ...credentialDialog, username: e.target.value })} autoComplete="off" /></label>
          <label className="stacked-field"><span>Contraseña temporal</span><input required type="password" minLength={12} maxLength={128} value={credentialDialog.password} onChange={e => setCredentialDialog({ ...credentialDialog, password: e.target.value })} autoComplete="new-password" /><small>Mínimo 12 caracteres, variados y sin espacios.</small></label>
          <label className="stacked-field"><span>Correo <small>Opcional</small></span><input type="email" maxLength={255} value={credentialDialog.email} onChange={e => setCredentialDialog({ ...credentialDialog, email: e.target.value })} /></label>
          <label className="stacked-field"><span>Teléfono <small>Opcional</small></span><input inputMode="tel" maxLength={40} value={credentialDialog.phone} onChange={e => setCredentialDialog({ ...credentialDialog, phone: e.target.value })} /></label>
          <label className="stacked-field"><span>Rol</span><select value={credentialDialog.role} onChange={e => setCredentialDialog({ ...credentialDialog, role: e.target.value })}>
            {(credentialDialog.kind === 'admin'
              ? ['ADMIN', 'OPERATOR', 'FINANCE', 'VIEWER']
              : adminRole === 'SUPER_ADMIN' ? ['ADMIN', 'OPERATOR', 'FINANCE', 'VIEWER'] : ['OPERATOR', 'FINANCE', 'VIEWER']
            ).map(role => <option key={role} value={role}>{role}</option>)}
          </select></label>
          <div className="editor-actions"><button type="button" onClick={() => setCredentialDialog(null)}>Cancelar</button><button className="primary" type="submit">Crear acceso</button></div>
        </form>
      </div>
    </div>}
    {roulette && <Roulette raffle={roulette} onClose={() => setRoulette(null)} />}
  </>;
}
