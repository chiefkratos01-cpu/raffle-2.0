import { useState } from 'react';

const sections = [
  ['platform', 'Reglas de la plataforma', [
    ['Cuentas', 'Cada persona debe utilizar su propia cuenta y mantener sus datos de acceso protegidos.'],
    ['Reservas', 'Una reserva aparta temporalmente los boletos según las condiciones de la rifa.'],
    ['Pagos', 'El pago se realiza siguiendo las instrucciones del organizador. Una reserva no se considera pagada hasta que el organizador la confirme.'],
    ['Cancelaciones', 'Las cancelaciones y liberación de boletos siguen el estado de la reserva y las condiciones mostradas.'],
    ['Comportamiento', 'No utilices la plataforma para engañar, suplantar a otra persona o interferir con una rifa.'],
    ['Privacidad y seguridad', 'Solo debes compartir la información necesaria para participar o gestionar una rifa. Nunca compartas contraseñas bancarias ni claves privadas.'],
  ]],
  ['raffles', 'Reglas generales de las rifas', [
    ['Participación', 'Antes de reservar, revisa el precio, la fecha del sorteo y las condiciones de la rifa.'],
    ['Boletos', 'Los números disponibles pueden cambiar mientras otras personas realizan reservas o pagos.'],
    ['Confirmación', 'El organizador es quien revisa y confirma los pagos de acuerdo con las condiciones de la rifa.'],
    ['Ganadores', 'Solo los boletos que cumplen las condiciones de la rifa pueden participar en el sorteo. El resultado se determina en el servidor.'],
    ['Premios', 'La descripción y las condiciones del premio son las que aparecen en la rifa publicada.'],
  ]],
  ['organizer', 'Reglas para organizadores', [
    ['Información clara', 'El organizador debe explicar precio, premios, fecha, forma de pago y condiciones de participación.'],
    ['Pagos', 'Debe revisar antes de confirmar un pago y conservar un trato claro con las personas participantes.'],
    ['Sorteos', 'Los sorteos deben realizarse mediante las herramientas de Raffle 2.0 y respetar las condiciones publicadas.'],
    ['Condiciones propias', 'Cada rifa puede añadir reglas particulares que aparecerán dentro de su página.'],
  ]],
];

export default function RulesPage() {
  const [open, setOpen] = useState('platform');
  return <div className="info-page"><div className="page-title"><div><span className="badge">GUÍA Y NORMAS</span><h1>Reglas de Raffle 2.0</h1><p className="muted">Una referencia sencilla para entender cómo funciona la plataforma.</p></div></div><div className="info-tabs">{sections.map(([id, title]) => <button key={id} className={open === id ? 'active' : ''} onClick={() => setOpen(id)}>{title}</button>)}</div><div className="info-content">{sections.filter(([id]) => id === open).map(([, title, items]) => <section className="panel rules-section" key={title}><h2>{title}</h2>{items.map(([h, text]) => <article key={h}><h3>{h}</h3><p>{text}</p></article>)}</section>)}<div className="callout"><b>Importante</b><span>Las reglas particulares de una rifa se muestran dentro de esa rifa y pueden complementar estas reglas generales.</span></div></div></div>;
}
