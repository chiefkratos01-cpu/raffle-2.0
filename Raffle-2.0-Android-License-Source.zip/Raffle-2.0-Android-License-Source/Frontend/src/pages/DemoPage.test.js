import fs from 'fs';
import path from 'path';

test('demo page is isolated and uses the supplied animated visual assets',()=>{
 const page=fs.readFileSync(path.resolve(__dirname,'DemoPage.js'),'utf8');
 expect(page).toContain('/demo/prepare');
 expect(page).toContain('/demo/draw');
 expect(page).toContain('/assets/demo/demo-winner.webp');
 expect(page).toContain('Entorno aislado');
});
