import { useEffect, useState } from 'react';
import api from '../services/api';
import Toast from '../components/Toast';
import Roulette from '../components/Roulette';

const scenes=[
  {key:'ticket',label:'Explora',image:'/assets/demo/demo-ticket.webp',title:'Una rifa lista para explorar',text:'Recorre una experiencia preparada para mostrar cómo se presenta una rifa real.'},
  {key:'prize',label:'Premio',image:'/assets/demo/demo-prize.webp',title:'Premios con presencia visual',text:'La demo utiliza contenido ficticio para que puedas ver el recorrido completo.'},
  {key:'winner',label:'Ganador',image:'/assets/demo/demo-winner.webp',title:'El momento del sorteo',text:'Prueba la selección del ganador y observa la animación de la ruleta.'},
  {key:'verified',label:'Verificación',image:'/assets/demo/demo-verified.webp',title:'Resultado verificable',text:'El recorrido termina mostrando cómo se consulta y comprueba el resultado.'},
];

export default function DemoPage({ onBack }){
 const [scene,setScene]=useState('ticket');
 const [state,setState]=useState(null);
 const [roulette,setRoulette]=useState(null);
 const [busy,setBusy]=useState(false);
 const [msg,setMsg]=useState('');
 const load=async()=>{try{const r=await api.get('/demo/state');setState(r.data)}catch(e){setMsg(e.response?.data?.detail||'No se pudo cargar la demo.')}};
 useEffect(()=>{load()},[]);
 const prepare=async()=>{try{setBusy(true);const r=await api.post('/demo/prepare');setState(r.data);setScene('ticket');setMsg('Datos de demostración preparados.')}catch(e){setMsg(e.response?.data?.detail||'No se pudo preparar la demo.')}finally{setBusy(false)}};
 const start=async()=>{try{setBusy(true);const r=await api.post('/demo/draw');setState(x=>x?{...x,draws:[...(x.draws||[]),r.data],ready:true}:x);setRoulette(state?.raffle||null);setScene('winner')}catch(e){setMsg(e.response?.data?.detail||'No se pudo iniciar el sorteo de demostración.')}finally{setBusy(false)}};
 const active=scenes.find(x=>x.key===scene)||scenes[0];
 return <div className="demo-page">
   <div className="demo-top"><button className="link-btn" onClick={onBack}>← Volver a Administración</button><span className="demo-badge">MODO DEMOSTRACIÓN</span></div>
   <section className="demo-hero">
     <div className="demo-copy"><span className="eyebrow">RAFFLE 2.0 · EXPERIENCIA INTERACTIVA</span><h1>Prueba cómo funciona la plataforma.</h1><p>Todo lo que ocurre aquí es ficticio. Puedes preparar participantes de prueba, iniciar el sorteo y ver la ruleta sin comprar boletos ni afectar ninguna rifa real.</p><div className="demo-actions"><button className="primary" disabled={busy} onClick={start}>Probar sorteo</button><button disabled={busy} onClick={prepare}>Reiniciar demo</button></div><div className="demo-stats"><div><b>{state?.eligible_count||0}</b><span>boletos de prueba</span></div><div><b>{state?.raffle?.winner_count||1}</b><span>ganador</span></div><div><b>100%</b><span>ficticio</span></div></div></div>
     <div className={`demo-scene demo-scene-${active.key}`}><div className="scene-glow"/><div className="scene-orbit orbit-a"/><div className="scene-orbit orbit-b"/><div className="scene-spark spark-a"/><div className="scene-spark spark-b"/><img src={active.image} alt=""/><div className="scene-caption">{active.label}</div></div>
   </section>
   <div className="demo-tabs">{scenes.map(x=><button key={x.key} className={scene===x.key?'active':''} onClick={()=>setScene(x.key)}>{x.label}</button>)}</div>
   <section className="demo-detail panel"><div><span className="eyebrow">{active.label.toUpperCase()}</span><h2>{active.title}</h2><p className="muted">{active.text}</p></div><div className="demo-ticket-preview">{state?.tickets?.slice(0,8).map(t=><span key={t.number}>#{String(t.number).padStart(2,'0')}</span>)}</div></section>
   <section className="demo-notice"><strong>Entorno aislado</strong><span>Los participantes, boletos, pagos y resultados de esta experiencia no entran en el funcionamiento de tus rifas reales.</span></section>
   <Toast message={msg} onClose={()=>setMsg('')}/>{roulette&&<Roulette raffle={roulette} onClose={()=>setRoulette(null)}/>}
 </div>
}
