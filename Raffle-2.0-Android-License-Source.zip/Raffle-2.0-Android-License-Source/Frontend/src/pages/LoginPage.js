import { useState } from 'react';
import api from '../services/api';
import Toast from '../components/Toast';
import { clearOfflineCache, setSecureItem } from '../services/secureStorage';

function PasswordIcon({ visible }) {
  return <svg className="password-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {visible
      ? <><path d="M3 3l18 18" /><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8" /><path d="M9.9 4.2A11.2 11.2 0 0 1 12 4c5.2 0 8.7 4.7 9.8 6a18 18 0 0 1-3.3 3.2" /><path d="M6.2 6.2C4.5 7.3 3.1 9 2.2 10c1.1 1.3 4.6 6 9.8 6 1 0 2-.2 2.9-.5" /></>
      : <><path d="M2.2 12s3.5-6 9.8-6 9.8 6 9.8 6-3.5 6-9.8 6-9.8-6-9.8-6Z" /><circle cx="12" cy="12" r="2.5" /></>}
  </svg>;
}

function PasswordField({ value, onChange, placeholder = 'Contraseña', minLength = 12 }) {
  const [visible, setVisible] = useState(false);
  return <label className="password-field">
    <span className="field-label">{placeholder}</span>
    <input type={visible ? 'text' : 'password'} minLength={minLength} required autoComplete="current-password" placeholder={placeholder} value={value} onChange={(event) => onChange(event.target.value)} />
    <button type="button" className="password-toggle" aria-label={visible ? 'Ocultar contraseña' : 'Mostrar contraseña'} onClick={() => setVisible((current) => !current)}>
      <PasswordIcon visible={visible} />
    </button>
  </label>;
}

function validEmail(value) {
  return !value || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());
}

function validPhone(value) {
  return !value || /^\+?[0-9][0-9 ()-]{6,19}$/.test(value.trim());
}

export default function LoginPage({ done, organizerIntent = false }) {
  const [registering, setRegistering] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', identifier: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setError('');
    if (registering && form.password !== form.confirm) {
      setError('Las contraseñas no coinciden.');
      return;
    }
    if (registering && form.password.length < 12) {
      setError('La contraseña debe tener al menos 12 caracteres.');
      return;
    }
    if (registering && (/\s/.test(form.password) || new Set(form.password).size < 5)) {
      setError('La contraseña debe tener al menos 12 caracteres variados y no contener espacios.');
      return;
    }
    if (registering && !validEmail(form.email)) {
      setError('Escribe un correo electrónico válido.');
      return;
    }
    if (registering && !validPhone(form.phone)) {
      setError('Escribe un número de teléfono válido.');
      return;
    }

    setBusy(true);
    try {
      const body = registering
        ? { name: form.name, email: form.email || null, phone: form.phone || null, password: form.password }
        : { identifier: form.identifier, password: form.password };
      const response = await api.post(registering ? '/auth/register' : '/auth/login', body);
      await clearOfflineCache();
      await setSecureItem('raffle_token', response.data.access_token);
      await setSecureItem('raffle_refresh_token', response.data.refresh_token);
      await done(organizerIntent ? 'organizer' : null);
    } catch (requestError) {
      setError(requestError.response?.data?.detail || 'No se pudo completar el acceso.');
    } finally {
      setBusy(false);
    }
  };

  return <div className="auth-card">
    <div className="auth-brand" aria-hidden="true">
      <img className="auth-logo auth-logo-light" src="/assets/logo-light.png" alt="" />
      <img className="auth-logo auth-logo-dark" src="/assets/logo-dark.png" alt="" />
    </div>
    <span className="badge">{organizerIntent ? 'ORGANIZADOR' : 'CUENTA'}</span>
    <h1>{registering ? 'Crear cuenta' : 'Entrar'}</h1>
    {organizerIntent && <p className="auth-note">Primero entra o crea tu cuenta. Después podrás solicitar acceso para organizar tus propias rifas.</p>}
    <Toast message={error} error onClose={() => setError('')} />
    <form onSubmit={submit}>
      {registering && <label className="stacked-field"><span>Nombre</span><input required minLength={2} maxLength={160} autoComplete="name" placeholder="Nombre" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></label>}
      <label className="stacked-field">
        <span>{registering ? 'Correo electrónico' : 'Correo, teléfono o usuario'}</span>
        <input required={!registering} autoCapitalize="none" autoComplete={registering ? 'email' : 'username'} inputMode={registering ? 'email' : 'text'} value={registering ? form.email : form.identifier} onChange={(event) => setForm({ ...form, [registering ? 'email' : 'identifier']: event.target.value })} />
        {registering && <small>Usaremos este dato para identificar tu cuenta.</small>}
      </label>
      {registering && <label className="stacked-field"><span>Teléfono</span><input inputMode="tel" autoComplete="tel" maxLength={40} value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /><small>Opcional. Puede ayudarte a identificarte al entrar.</small></label>}
      <PasswordField value={form.password} onChange={(value) => setForm({ ...form, password: value })} />
      {registering && <PasswordField value={form.confirm} onChange={(value) => setForm({ ...form, confirm: value })} placeholder="Repite tu contraseña" />}
      <button className="primary" type="submit" disabled={busy}>{busy ? 'Procesando…' : registering ? 'Registrarme' : 'Entrar'}</button>
    </form>
    <button className="link-btn" type="button" onClick={() => { setRegistering((value) => !value); setError(''); }}>
      {registering ? 'Ya tengo cuenta' : 'Crear una cuenta'}
    </button>
  </div>;
}

export { PasswordField };
