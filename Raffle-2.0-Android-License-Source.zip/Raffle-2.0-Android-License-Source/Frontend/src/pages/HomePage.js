import { assetUrl, money, statusLabel } from '../utils/format';
import UiIcon from '../components/UiIcon';

function HomePage({ raffles, open, auth, onOrganizer, catalogState = 'ready', reload }) {
  return <>
    <section className="hero-card">
      <div className="hero-copy">
        <span className="badge">RAFFLE 2.0</span>
        <p className="brand-line">Rifas que conectan oportunidades.</p>
        <h1 className="safe-title">Crea tu rifa.<br />Gestiona tus boletos.<br />Haz el sorteo.</h1>
        <div className="hero-actions"><button className="primary" onClick={() => document.getElementById('list').scrollIntoView({ behavior: 'smooth' })}><UiIcon name="search" size={18} /> Explorar rifas</button><button className="hero-secondary" onClick={onOrganizer}><UiIcon name="plus" size={18} /> Crear mi rifa</button></div>
      </div>
      <div className="hero-visual" aria-hidden="true">
  <div className="hero-glow glow-a" />
  <div className="hero-glow glow-b" />
  <img className="hero-illustration" src="/assets/home-illustration.webp" alt="" />
</div>
    </section>

    <section className="feature-strip"><article><span><UiIcon name="ticket" size={19} /></span><div><b>Elige tus números</b><small>Encuentra tus boletos de forma sencilla.</small></div></article><article><span><UiIcon name="payment" size={19} /></span><div><b>Reserva y confirma</b><small>Recibe avisos sobre el estado de tu reserva.</small></div></article><article><span><UiIcon name="draw" size={19} /></span><div><b>Vive el sorteo</b><small>La ruleta muestra el resultado en tiempo real.</small></div></article></section>

    <section id="list"><div className="section-title"><div><span className="eyebrow">CATÁLOGO</span><h2>Rifas disponibles</h2></div><span className="count-pill">{raffles.length}</span></div>{raffles.length ? <div className="raffle-list">{raffles.map(r => <article className="raffle-card" key={r.id}>{r.image ? <img src={assetUrl(r.image)} alt="Imagen de la rifa" /> : <div className="raffle-art"><span><UiIcon name="ticket" size={30} /></span><small>RIFA</small></div>}<div className="raffle-main"><span className="small-badge">{statusLabel[r.status] || r.status}</span><h3 className="safe-title">{r.title}</h3><p>{r.description || 'Conoce los detalles de esta rifa.'}</p><div className="progress"><span style={{ width: `${Math.min(100, (r.tickets_sold / r.total_tickets) * 100)}%` }} /></div><div className="meta">{r.tickets_sold.toLocaleString()}/{r.total_tickets.toLocaleString()} vendidos · {r.winner_count} ganador{r.winner_count !== 1 ? 'es' : ''}</div></div><aside><strong>{money(r.ticket_price, r.currency)}</strong><button className="primary" onClick={() => open(r)}>{auth ? 'Ver rifa' : 'Ver rifa'}</button></aside></article>)}</div> : catalogState === 'error' ? <div className="empty-state"><h3>No pudimos cargar las rifas</h3><p>Comprueba tu conexión e inténtalo de nuevo. Si el problema continúa, vuelve a intentarlo más tarde.</p><button className="hero-secondary" onClick={reload}>Intentar de nuevo</button></div> : catalogState === 'loading' ? <div className="empty-state catalog-loading" aria-live="polite"><span className="loading-orb" aria-hidden="true" /><h3>Cargando rifas</h3><p>Estamos preparando el catálogo.</p></div> : <div className="empty-state"><img className="empty-state-art" src="/assets/empty-raffle.webp" alt="" /><h3>Todavía no hay rifas disponibles</h3><p>Cuando haya una nueva rifa podrás encontrarla aquí.</p><button className="hero-secondary" onClick={onOrganizer}>¿Quieres organizar tus propias rifas?</button></div>}</section>
  </>;
}
export default HomePage;
