import { useEffect, useState } from 'react';
import api from '../services/api';
import Toast from '../components/Toast';
import { PasswordField } from './LoginPage';

export default function OrganizerRequestPage() {
  const [current, setCurrent] = useState(null);
  const [f, setF] = useState({ username: '', password: '', confirm: '', business: '', notes: '' });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  const load = async () => { try { const r = await api.get('/organizer/requests/mine'); setCurrent(r.data); } catch (e) { setErr(e.response?.data?.detail || 'No se pudo cargar la solicitud.'); } };
  useEffect(() => { load(); }, []);

  const submit = async e => {
    e.preventDefault(); setErr(''); setMsg('');
    if (f.password.length < 12 || /\s/.test(f.password) || new Set(f.password).size < 5) { setErr('La contraseña debe tener al menos 12 caracteres variados y no contener espacios.'); return; } if (f.password !== f.confirm) { setErr('Las contraseñas no coinciden.'); return; }
    try {
      const r = await api.post('/organizer/requests', { desired_username: f.username.trim(), password: f.password, business_name: f.business || null, notes: f.notes || null });
      setCurrent(r.data); setMsg('Solicitud enviada. Te avisaremos cuando sea revisada.');
    } catch (x) { setErr(x.response?.data?.detail || 'No se pudo enviar la solicitud.'); }
  };

  if (current?.status === 'APPROVED') return <div className="panel organizer-panel"><span className="badge">ORGANIZADOR</span><h1>Tu acceso fue aprobado</h1><p>Ya puedes entrar con el nombre de acceso <b>{current.desired_username}</b>. Al entrar encontrarás el modo demo para conocer Raffle 2.0 antes de activar una licencia.</p><div className="callout success"><b>Próximo paso</b><span>Entra con tu nuevo acceso de organizador y explora el modo demo.</span></div></div>;
  if (current?.status === 'PENDING') return <div className="panel organizer-panel"><span className="badge">SOLICITUD EN REVISIÓN</span><h1>Estamos revisando tu solicitud</h1><p>Tu solicitud para organizar rifas está pendiente de revisión. Mientras tanto puedes seguir usando tu cuenta como cliente.</p><div className="callout"><b>Nombre solicitado</b><span>{current.desired_username}</span></div></div>;
  if (current?.status === 'REJECTED') return <div className="panel organizer-panel"><span className="badge">NUEVA SOLICITUD</span><h1>Puedes volver a solicitar acceso</h1><p className="muted">La solicitud anterior no fue aprobada{current.rejection_reason ? `: ${current.rejection_reason}` : '.'}</p></div>;

  return <div className="auth-card organizer-panel"><span className="badge">QUIERO ORGANIZAR RIFAS</span><h1>Solicitar acceso como organizador</h1><p className="auth-note">Tu cuenta seguirá siendo normal hasta que el SUPER_ADMIN apruebe la solicitud. Si se aprueba, recibirás acceso de organizador y podrás probar el modo demo.</p><Toast message={err} error onClose={() => setErr('')} /><Toast message={msg} onClose={() => setMsg('')} />
    <form onSubmit={submit}>
      <label className="stacked-field"><span>Nombre de acceso</span><input required minLength="3" maxLength="80" pattern="[A-Za-z0-9_.-]+" value={f.username} onChange={e => setF({ ...f, username: e.target.value })} placeholder="Ej. miRifa" /><small>Será el nombre que usarás para entrar al panel de organizador.</small></label>
      <PasswordField value={f.password} onChange={value => setF({ ...f, password: value })} placeholder="Contraseña" minLength={12} />
      <PasswordField value={f.confirm} onChange={value => setF({ ...f, confirm: value })} placeholder="Repite tu contraseña" minLength={12} />
      <input placeholder="Nombre del negocio o proyecto (opcional)" maxLength="160" value={f.business} onChange={e => setF({ ...f, business: e.target.value })} />
      <textarea maxLength="2000" placeholder="Cuéntanos brevemente qué quieres hacer con Raffle 2.0 (opcional)" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} />
      <button className="primary" type="submit">Enviar solicitud</button>
    </form>
  </div>;
}
