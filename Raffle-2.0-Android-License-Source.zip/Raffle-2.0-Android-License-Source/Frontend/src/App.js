import { useEffect, useState } from 'react';
import { App as NativeApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';
import AccountPage from './pages/AccountPage';
import AdminPage from './pages/AdminPage';
import DemoPage from './pages/DemoPage';
import GuidePage from './pages/GuidePage';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import OrganizerRequestPage from './pages/OrganizerRequestPage';
import RaffleDetailPage from './pages/RaffleDetailPage';
import RulesPage from './pages/RulesPage';
import TicketVerifyPage from './pages/TicketVerifyPage';
import WinnerVerifyPage from './pages/WinnerVerifyPage';
import ThemeSelector from './components/ThemeSelector';
import NetworkStatus from './components/NetworkStatus';
import { useTheme } from './context/ThemeContext';
import { clearOfflineCache, getSecureItem, removeSecureItem } from './services/secureStorage';
import api from './services/api';

const routeMap = {
  '/demo': 'demo',
  '/guide': 'guide',
  '/rules': 'rules',
  '/account': 'mine',
  '/organizer': 'organizer',
  '/admin': 'admin',
  '/login': 'login',
  '/login-organizer': 'login-organizer',
};

function routeForPath(path) {
  if (/^\/raffle\/\d+$/.test(path)) return 'detail';
  if (/^\/verify\/(ticket|winner)\//.test(path)) return 'verify';
  return routeMap[path] || 'home';
}

function tokenClaim(token, claim) {
  try {
    if (!token) return null;
    const encoded = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = encoded + '='.repeat((4 - encoded.length % 4) % 4);
    return JSON.parse(atob(padded))[claim] || null;
  } catch {
    return null;
  }
}

function AppIcon({ name, size = 20 }) {
  const paths = {
    home: <path d="M3 10.5 10 4l7 6.5V17a1 1 0 0 1-1 1h-4v-5H8v5H4a1 1 0 0 1-1-1z" />,
    guide: <><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H16v15H6.5A2.5 2.5 0 0 0 4 19.5z" /><path d="M4 5v14M8 6h5M8 9h5" /></>,
    rules: <><path d="M5 3h10v18H5z" /><path d="M8 7h4M8 10h4M8 13h4M8 16h2" /></>,
    account: <><circle cx="10" cy="7" r="3" /><path d="M4 18a6 6 0 0 1 12 0" /></>,
    admin: <><path d="M10 2.8 16 5v4.5c0 3.7-2.4 6.4-6 7.7-3.6-1.3-6-4-6-7.7V5z" /><path d="m7.3 10 1.8 1.8 3.8-4" /></>,
  };
  return <svg className="ui-icon" width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export default function App() {
  const { mode } = useTheme();
  const initialPath = window.location.pathname;
  const initialRaffleMatch = initialPath.match(/^\/raffle\/(\d+)$/);
  const [view, setView] = useState(routeForPath(initialPath));
  const [raffles, setRaffles] = useState([]);
  const [selected, setSelected] = useState(null);
  const [catalogState, setCatalogState] = useState('loading');
  const [detailLoading, setDetailLoading] = useState(Boolean(initialRaffleMatch));
  const [auth, setAuth] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [adminRole, setAdminRole] = useState(null);
  const [, setRouteRevision] = useState(0);
  const panelRoles = ['SUPER_ADMIN', 'ADMIN', 'OPERATOR', 'FINANCE', 'VIEWER'];
  const initialRaffleId = initialRaffleMatch ? Number(initialRaffleMatch[1]) : null;

  const load = () => {
    setCatalogState('loading');
    return api.get('/raffles')
      .then((response) => { setRaffles(response.data); setCatalogState('ready'); })
      .catch(() => setCatalogState('error'));
  };

  const go = (next) => {
    setView(next);
    const paths = {
      home: '/', demo: '/demo', guide: '/guide', rules: '/rules', mine: '/account',
      organizer: '/organizer', admin: '/admin', login: '/login', 'login-organizer': '/login-organizer',
    };
    const path = paths[next];
    if (path && window.location.pathname !== path) {
      window.history.pushState({ view: next }, '', path);
    }
  };

  useEffect(() => {
    let active = true;
    getSecureItem('raffle_token')
      .then((token) => {
        if (!active) return;
        setAuth(Boolean(token));
        setAdmin(tokenClaim(token, 'role') === 'ADMIN');
        setAdminRole(tokenClaim(token, 'admin_role'));
      })
      .catch(() => {
        if (active) {
          setAuth(false);
          setAdmin(false);
          setAdminRole(null);
        }
      })
      .finally(() => { if (active) setAuthReady(true); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!initialRaffleId) return;
    setDetailLoading(true);
    api.get(`/raffles/${initialRaffleId}`)
      .then((response) => { setSelected(response.data); setDetailLoading(false); })
      .catch(() => {
        setDetailLoading(false);
        window.history.replaceState({}, '', '/');
        setView('home');
      });
  }, [initialRaffleId]);

  useEffect(() => {
    const onPopState = () => {
      const path = window.location.pathname;
      const nextView = routeForPath(path);
      setView(nextView);
      if (nextView === 'detail') {
        const match = path.match(/^\/raffle\/(\d+)$/);
        if (match) {
          setDetailLoading(true);
          api.get(`/raffles/${Number(match[1])}`)
            .then((response) => { setSelected(response.data); setDetailLoading(false); })
            .catch(() => {
              setSelected(null);
              setDetailLoading(false);
              setView('home');
              window.history.replaceState({}, '', '/');
            });
        }
      } else if (nextView !== 'verify') {
        setSelected(null);
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    load();
    if (!auth) {
      setAdmin(false);
      setAdminRole(null);
      return;
    }
    getSecureItem('raffle_token').then((token) => {
      if (tokenClaim(token, 'role') !== 'ADMIN') {
        setAdmin(false);
        setAdminRole(null);
        return;
      }
      api.get('/auth/admin/me')
        .then((response) => { setAdmin(true); setAdminRole(response.data.role); })
        .catch(() => { setAdmin(false); setAdminRole(null); });
    }).catch(() => { setAdmin(false); setAdminRole(null); });
  }, [auth]);

  useEffect(() => {
    if (!authReady) return;
    if (!auth && ['mine', 'organizer', 'admin', 'demo'].includes(view)) {
      go('login');
      return;
    }
    if (auth && admin && ['mine', 'organizer'].includes(view)) {
      go('admin');
      return;
    }
    if (view === 'admin' && auth && tokenClaimFromStoredRole(admin) !== 'ADMIN') go('home');
    if (view === 'admin' && auth && adminRole && !panelRoles.includes(adminRole)) go('home');
    if (view === 'demo' && adminRole && adminRole !== 'SUPER_ADMIN' && adminRole !== 'ADMIN') go('admin');
  }, [view, auth, authReady, admin, adminRole]);

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return undefined;
    let active = true;
    let backHandle;
    let deepLinkHandle;
    StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {});
    const isDark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    StatusBar.setBackgroundColor({ color: isDark ? '#080B1C' : '#F7F8FF' }).catch(() => {});
    StatusBar.setStyle({ style: isDark ? Style.Light : Style.Dark }).catch(() => {});

    NativeApp.addListener('backButton', () => {
      const beforeBack = new Event('raffle:before-back', { cancelable: true });
      window.dispatchEvent(beforeBack);
      if (beforeBack.defaultPrevented) return;
      if (window.history.state?.view) {
        window.history.back();
      } else if (view !== 'home' || window.location.pathname !== '/') {
        setView('home');
        setSelected(null);
        setDetailLoading(false);
        window.history.replaceState({ view: 'home' }, '', '/');
      } else {
        NativeApp.exitApp();
      }
    }).then((handle) => { if (active) backHandle = handle; else handle.remove(); });

    NativeApp.addListener('appUrlOpen', ({ url }) => {
      try {
        const incoming = new URL(url);
        const path = incoming.protocol === 'raffle:'
          ? incoming.hostname === 'verify' ? `/verify${incoming.pathname}` : incoming.hostname === 'raffle' ? `/raffle${incoming.pathname}` : ''
          : incoming.pathname;
        if (/^\/verify\/(ticket|winner)\//.test(path)) {
          window.history.pushState({ view: 'verify' }, '', path);
          setView('verify');
          setRouteRevision((revision) => revision + 1);
          return;
        }
        const raffleMatch = path.match(/^\/raffle\/(\d+)$/);
        if (!raffleMatch) return;
        const raffleId = Number(raffleMatch[1]);
        window.history.pushState({ view: 'detail', raffleId }, '', path);
        setView('detail');
        setDetailLoading(true);
        api.get(`/raffles/${raffleId}`).then((response) => {
          setSelected(response.data);
          setDetailLoading(false);
        }).catch(() => {
          setSelected(null);
          setDetailLoading(false);
          setView('home');
          window.history.replaceState({ view: 'home' }, '', '/');
        });
        setRouteRevision((revision) => revision + 1);
      } catch {
        // Ignore malformed external links without disturbing the current screen.
      }
    }).then((handle) => { if (active) deepLinkHandle = handle; else handle.remove(); });

    return () => {
      active = false;
      backHandle?.remove();
      deepLinkHandle?.remove();
    };
  }, [mode, view]);

  const handleAuthDone = async (intent) => {
    const token = await getSecureItem('raffle_token');
    setAuth(Boolean(token));
    setAdmin(tokenClaim(token, 'role') === 'ADMIN');
    setAdminRole(tokenClaim(token, 'admin_role'));
    if (intent === 'organizer') {
      go('organizer');
      return;
    }
    if (tokenClaim(token, 'role') === 'ADMIN') {
      try {
        const response = await api.get('/auth/admin/me');
        setAdmin(true);
        setAdminRole(response.data.role);
        go('admin');
        return;
      } catch {
        setAdmin(false);
        setAdminRole(null);
      }
    }
    go('mine');
  };

  const logout = async () => {
    try {
      if (await getSecureItem('raffle_token')) await api.post('/auth/logout', {});
    } catch {
      // Local logout still clears the secure session when the API is unavailable.
    } finally {
      await removeSecureItem('raffle_token').catch(() => {});
      await removeSecureItem('raffle_refresh_token').catch(() => {});
      await clearOfflineCache().catch(() => {});
      setAuth(false);
      setAdmin(false);
      setAdminRole(null);
      go('home');
      setSelected(null);
    }
  };

  const path = window.location.pathname;
  if (path.startsWith('/verify/ticket/')) {
    return <main className="shell"><div className="content"><TicketVerifyPage code={decodeURIComponent(path.slice('/verify/ticket/'.length))} /><ProductAttribution /></div></main>;
  }
  if (path.startsWith('/verify/winner/')) {
    return <main className="shell"><div className="content"><WinnerVerifyPage code={decodeURIComponent(path.slice('/verify/winner/'.length))} /><ProductAttribution /></div></main>;
  }

  const canPanel = admin && panelRoles.includes(adminRole);
  const canDemo = admin && (adminRole === 'SUPER_ADMIN' || adminRole === 'ADMIN');
  const isOwner = adminRole === 'SUPER_ADMIN';

  return <main className="shell">
    <header className="topbar">
      <button className="brand-btn" onClick={() => go('home')} aria-label="Ir al inicio">
        <span className="brand-logo-picture"><img className="brand-logo" src="/assets/logo-icon.webp" alt="" /></span>
        <span className="brand-wordmark"><b>Raffle 2.0</b><small>Rifas que conectan oportunidades.</small></span>
      </button>
      <nav>
        <button className="desktop-link" onClick={() => go('home')}>Rifas</button>
        <button className="desktop-link" onClick={() => go('guide')}>Guía</button>
        <button className="desktop-link" onClick={() => go('rules')}>Reglas</button>
        {auth && !admin && <button className="desktop-link" onClick={() => go('mine')}>Mi cuenta</button>}
        {canPanel && <button className="desktop-link nav-admin" onClick={() => go('admin')}>{isOwner || adminRole === 'ADMIN' ? 'Administración' : 'Panel'}</button>}
        <ThemeSelector />
        {auth ? <button className="logout-button" onClick={logout}>Salir</button> : <button className="primary login-button" onClick={() => go('login')}>Entrar</button>}
      </nav>
    </header>
    <NetworkStatus />
    <div className="content">
      {view === 'login' && <LoginPage done={handleAuthDone} />}
      {view === 'login-organizer' && <LoginPage organizerIntent done={handleAuthDone} />}
      {view === 'mine' && auth && !admin && <AccountPage />}
      {view === 'organizer' && auth && !admin && <OrganizerRequestPage />}
      {view === 'admin' && canPanel && <AdminPage refreshPublic={load} adminRole={adminRole} openDemo={() => go('demo')} />}
      {view === 'demo' && canDemo && <DemoPage onBack={() => go('admin')} />}
      {view === 'detail' && detailLoading && !selected && <div className="panel detail-loading"><span className="loading-orb" aria-hidden="true" /><h2>Cargando rifa</h2><p className="muted">Estamos preparando los detalles.</p></div>}
      {view === 'detail' && selected && <RaffleDetailPage r={selected} back={() => go('home')} logged={auth} onLogin={() => go('login')} />}
      {view === 'guide' && <GuidePage />}
      {view === 'rules' && <RulesPage />}
      {view === 'home' && <HomePage raffles={raffles} open={(raffle) => {
        setSelected(raffle);
        setView('detail');
        window.history.pushState({ view: 'detail', raffleId: raffle.id }, '', `/raffle/${raffle.id}`);
      }} auth={auth} onOrganizer={() => go(auth ? 'organizer' : 'login-organizer')} catalogState={catalogState} reload={load} />}
      <ProductAttribution />
    </div>
    <div className="mobile-nav">
      <button onClick={() => go('home')} className={view === 'home' ? 'active' : ''}><AppIcon name="home" /><span>Inicio</span></button>
      <button onClick={() => go('guide')} className={view === 'guide' ? 'active' : ''}><AppIcon name="guide" /><span>Guía</span></button>
      <button onClick={() => go('rules')} className={view === 'rules' ? 'active' : ''}><AppIcon name="rules" /><span>Reglas</span></button>
      {auth && (admin
        ? <button onClick={() => go('admin')} className={view === 'admin' ? 'active' : ''}><AppIcon name="admin" /><span>Panel</span></button>
        : <button onClick={() => go('mine')} className={view === 'mine' ? 'active' : ''}><AppIcon name="account" /><span>Cuenta</span></button>)}
    </div>
  </main>;
}

function tokenClaimFromStoredRole(isAdmin) {
  return isAdmin ? 'ADMIN' : null;
}

function ProductAttribution() {
  return <footer className="app-attribution"><span>© Codexia Systems</span><span>Developed by Carlos Alejandro Arcia Miranda</span></footer>;
}
