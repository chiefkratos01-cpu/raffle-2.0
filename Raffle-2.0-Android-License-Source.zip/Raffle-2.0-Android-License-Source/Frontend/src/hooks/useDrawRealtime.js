import { useEffect } from 'react';
import { subscribeToRaffle } from '../services/socket';
export default function useDrawRealtime(raffleId, onDrawResult) {
  useEffect(() => { let active = true; let unsubscribe; subscribeToRaffle(raffleId, { onDrawResult: (payload) => { if (active) onDrawResult(payload); } }).then((cleanup) => { if (active) unsubscribe = cleanup; else cleanup?.(); }).catch(() => {}); return () => { active = false; unsubscribe?.(); }; }, [raffleId, onDrawResult]);
}
