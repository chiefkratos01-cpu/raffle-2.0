import {useCallback,useEffect,useState} from 'react';
import {fetchRaffleAvailability} from '../services/raffles';
import {subscribeToRaffle} from '../services/socket';
export default function useRaffleAvailability(raffleId,start,limit=100){
 const[occupied,setOccupied]=useState(new Set()),[loading,setLoading]=useState(false),[error,setError]=useState('');
 const refresh=useCallback(()=>{let live=true;setLoading(true);setError('');fetchRaffleAvailability(raffleId,start,limit).then(({data})=>live&&setOccupied(new Set(data.occupied||[]))).catch(()=>live&&setError('No se pudo actualizar la disponibilidad. Intenta de nuevo.')).finally(()=>live&&setLoading(false));return()=>{live=false}},[raffleId,start,limit]);
 useEffect(()=>refresh(),[refresh]);
 useEffect(()=>{let active=true,cleanup;subscribeToRaffle(raffleId,{onRaffleUpdate:()=>{if(active)refresh()}}).then(c=>{if(active)cleanup=c;else c?.()}).catch(()=>{});return()=>{active=false;cleanup?.()}},[raffleId,refresh]);
 return{occupied,loading,error,refresh};
}
