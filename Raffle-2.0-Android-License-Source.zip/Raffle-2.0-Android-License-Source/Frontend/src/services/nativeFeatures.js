import { Capacitor } from '@capacitor/core';
import { AppLauncher } from '@capacitor/app-launcher';
import { Clipboard } from '@capacitor/clipboard';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { Share } from '@capacitor/share';

const publicWebUrl = (process.env.REACT_APP_PUBLIC_URL || '').replace(/\/$/, '');

export function verificationUrl(kind, code) {
  const safeCode = encodeURIComponent(code);
  const path = `/verify/${kind}/${safeCode}`;
  if (!Capacitor.isNativePlatform()) return `${window.location.origin}${path}`;
  if (publicWebUrl) return `${publicWebUrl}${path}`;
  return `raffle://verify/${kind}/${safeCode}`;
}

export function raffleShareUrl(raffleId) {
  const path = `/raffle/${encodeURIComponent(raffleId)}`;
  if (!Capacitor.isNativePlatform()) return `${window.location.origin}${path}`;
  if (publicWebUrl) return `${publicWebUrl}${path}`;
  return `raffle://raffle/${encodeURIComponent(raffleId)}`;
}

export async function shareContent({ title, text, url }) {
  if (Capacitor.isNativePlatform()) {
    await Share.share({ title, text, url, dialogTitle: 'Compartir' });
    return;
  }
  if (navigator.share) {
    await navigator.share({ title, text, url });
    return;
  }
  await copyText(url);
}

export async function openExternalUrl(url, event) {
  if (!Capacitor.isNativePlatform()) return;
  event?.preventDefault();
  try {
    const result = await AppLauncher.openUrl({ url });
    if (result?.completed) return;
  } catch {
    // Fall through to the WebView if Android cannot resolve the external intent.
  }
  window.location.assign(url);
}

export async function copyText(value) {
  if (Capacitor.isNativePlatform()) {
    await Clipboard.write({ string: value });
    return;
  }
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  throw new Error('El portapapeles no está disponible en este navegador.');
}

export async function selectionHaptic() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await Haptics.impact({ style: ImpactStyle.Light });
  } catch {
    // Haptic feedback is optional and must never block ticket selection.
  }
}
