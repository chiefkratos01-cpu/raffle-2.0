import { hasValidSignedQuotas } from './licenseClaims';

const validClaims = () => ({
  max_active_raffles: 10,
  max_tickets_per_raffle: 500,
  max_team_accounts: 5,
  max_organizers: 3,
});

test('accepts explicit configurable Commercial quota values', () => {
  expect(hasValidSignedQuotas(validClaims())).toBe(true);
});

test.each([null, -1, 1.5, true])('rejects invalid signed v2 quota value %p', (value) => {
  const claims = validClaims();
  claims.max_active_raffles = value;
  expect(hasValidSignedQuotas(claims)).toBe(false);
});

test('rejects a missing signed quota', () => {
  const claims = validClaims();
  delete claims.max_organizers;
  expect(hasValidSignedQuotas(claims)).toBe(false);
});
