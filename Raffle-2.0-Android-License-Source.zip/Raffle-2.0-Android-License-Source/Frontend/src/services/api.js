import axios from 'axios';
import { Capacitor } from '@capacitor/core';
import { API_URL } from '../config';
import { clearOfflineCache, getSecureItem, removeSecureItem, setSecureItem } from './secureStorage';

const api = axios.create({ baseURL: API_URL });
let refreshing = null;

function offlineCacheKey(config) {
  return `offline-cache:${(config.method || 'get').toLowerCase()}:${config.url || ''}`;
}

api.interceptors.request.use(async (config) => {
  const token = await getSecureItem('raffle_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(async (response) => {
  const method = (response.config?.method || '').toLowerCase();
  if (Capacitor.isNativePlatform() && method === 'get' && response.status >= 200 && response.status < 300) {
    try {
      const serialized = JSON.stringify(response.data);
      if (serialized.length <= 700_000) await setSecureItem(offlineCacheKey(response.config), serialized);
    } catch {
      // A successful online request must not fail because optional offline caching failed.
    }
  }
  return response;
}, async (error) => {
  const original = error.config;

  if (Capacitor.isNativePlatform() && original && (original.method || 'get').toLowerCase() === 'get' && !error.response) {
    try {
      const cached = await getSecureItem(offlineCacheKey(original));
      if (cached) {
        return {
          config: original,
          data: JSON.parse(cached),
          headers: { 'x-raffle-offline-cache': 'true' },
          status: 200,
          statusText: 'Offline cache',
        };
      }
    } catch {
      // Continue to normal error handling if the encrypted cache is unavailable.
    }
  }

  if (error.response?.status !== 401 || original?._retry || original?.url === '/auth/login' || original?.url === '/auth/refresh') throw error;
  const refresh = await getSecureItem('raffle_refresh_token');
  if (!refresh) {
    await removeSecureItem('raffle_token').catch(() => {});
    await clearOfflineCache().catch(() => {});
    throw error;
  }
  original._retry = true;
  try {
    refreshing ||= api.post('/auth/refresh', { refresh_token: refresh });
    const response = await refreshing;
    refreshing = null;
    await setSecureItem('raffle_token', response.data.access_token);
    await setSecureItem('raffle_refresh_token', response.data.refresh_token);
    original.headers.Authorization = `Bearer ${response.data.access_token}`;
    return api(original);
  } catch (refreshError) {
    refreshing = null;
    await removeSecureItem('raffle_token').catch(() => {});
    await removeSecureItem('raffle_refresh_token').catch(() => {});
    await clearOfflineCache().catch(() => {});
    throw refreshError;
  }
});

export default api;
