const SIGNED_QUOTA_FIELDS = [
  'max_active_raffles',
  'max_tickets_per_raffle',
  'max_team_accounts',
  'max_organizers',
];

export function hasValidSignedQuotas(payload) {
  return SIGNED_QUOTA_FIELDS.every((field) => Number.isSafeInteger(payload[field]) && payload[field] >= 0);
}
