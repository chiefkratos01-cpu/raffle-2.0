import { SOCKET_URL } from '../config';
import { getSecureItem } from './secureStorage';

let socketPromise;
const rooms = new Map();
let connectHandlerInstalled = false;

const getSocketUrl=()=>SOCKET_URL;

const installRecovery = (socket) => {
  if (connectHandlerInstalled) return;
  connectHandlerInstalled = true;
  socket.on('connect', () => {
    for (const raffleId of rooms.keys()) socket.emit('join_raffle', { raffle_id: raffleId });
  });
};

let notificationSubscribers=0;
let notificationHandlers=new Set();
let notificationListenerInstalled=false;

export const loadSocket=async()=>{
  if(!socketPromise){
    socketPromise=import('socket.io-client').then(async ({io})=>{
      const token=await getSecureItem('raffle_token');
      const socket=io(getSocketUrl(),{path:'/socket.io',transports:['websocket','polling'],auth: token ? {token} : {},autoConnect:true});
      installRecovery(socket);
      return socket;
    });
  }
  return socketPromise;
};

const syncSocketAuth = async (socket) => {
  const token = await getSecureItem('raffle_token') || null;
  const current = socket.auth?.token || null;
  if (current === token) return;
  socket.auth = token ? { token } : {};
  if (socket.connected) {
    socket.disconnect();
    socket.connect();
  }
};

const waitForConnection = (socket) => {
  if (socket.connected) return Promise.resolve();
  return new Promise((resolve,reject)=>{
    const t=setTimeout(()=>reject(new Error('socket timeout')),5000);
    const cleanup=()=>{clearTimeout(t);socket.off('connect',connected);socket.off('connect_error',failed)};
    const connected=()=>{cleanup();resolve()};
    const failed=(e)=>{cleanup();reject(e)};
    socket.once('connect',connected);
    socket.once('connect_error',failed);
  });
};

export const subscribeToRaffle=async(raffleId,{onDrawResult,onRaffleUpdate}={})=>{
  const socket=await loadSocket(); await syncSocketAuth(socket); await waitForConnection(socket);
  const key=String(raffleId); let room=rooms.get(key);
  if(!room){ room={count:0}; rooms.set(key,room); socket.emit('join_raffle',{raffle_id:raffleId}); }
  room.count+=1;
  const matches=p=>String(p?.raffle_id)===key;
  const drawHandler=p=>matches(p)&&onDrawResult?.(p);
  const updateHandler=p=>matches(p)&&onRaffleUpdate?.(p);
  socket.on('draw_result',drawHandler); socket.on('raffle_update',updateHandler);
  let done=false;
  return()=>{ if(done)return; done=true; socket.off('draw_result',drawHandler); socket.off('raffle_update',updateHandler); const current=rooms.get(key); if(!current)return; current.count-=1; if(current.count<=0){rooms.delete(key);if(socket.connected)socket.emit('leave_raffle',{raffle_id:raffleId});} };
};

export const subscribeToNotifications=async(onNotification)=>{
  const socket=await loadSocket(); await syncSocketAuth(socket); await waitForConnection(socket);
  if(!notificationListenerInstalled){
    notificationListenerInstalled=true;
    socket.on('notification',payload=>{ for(const handler of notificationHandlers) handler(payload); });
  }
  notificationSubscribers+=1;
  notificationHandlers.add(onNotification);
  let done=false;
  return()=>{ if(done)return; done=true; notificationSubscribers=Math.max(0,notificationSubscribers-1); notificationHandlers.delete(onNotification); };
};
