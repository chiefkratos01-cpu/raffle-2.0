import api from './api';
export const fetchRaffleAvailability = (raffleId, start, limit = 100) => api.get(`/raffles/${raffleId}/availability`, { params: { start, limit } });
export const fetchRaffleWinners = (raffleId) => api.get(`/draws/${raffleId}/winners`);
export const fetchLatestDraw = (raffleId) => api.get(`/draws/${raffleId}/latest`);
