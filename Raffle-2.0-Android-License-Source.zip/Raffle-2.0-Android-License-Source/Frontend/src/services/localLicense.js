import * as ed25519 from '@noble/ed25519';
import { LICENSE_PRODUCT, LICENSE_PUBLIC_KEY } from '../config';
import { hasValidSignedQuotas } from './licenseClaims';

function decodeBase64Url(value) {
  const base64 = value.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - base64.length % 4) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

export async function verifySignedLicense(token) {
  if (!LICENSE_PUBLIC_KEY) return { verified: false, reason: 'La clave pública de licencia no está configurada.' };
  if (typeof token !== 'string') return { verified: false, reason: 'No hay una licencia guardada para verificar.' };
  const [payloadPart, signaturePart, ...extra] = token.trim().split('.');
  if (!payloadPart || !signaturePart || extra.length) return { verified: false, reason: 'Formato de licencia no válido.' };
  try {
    const publicKey = decodeBase64Url(LICENSE_PUBLIC_KEY.trim());
    const signature = decodeBase64Url(signaturePart);
    const message = new TextEncoder().encode(payloadPart);
    const valid = await ed25519.verifyAsync(signature, message, publicKey);
    if (!valid) return { verified: false, reason: 'La firma Ed25519 de la licencia no es válida.' };
    const payload = JSON.parse(new TextDecoder().decode(decodeBase64Url(payloadPart)));
    if (payload.product !== LICENSE_PRODUCT) return { verified: false, reason: 'La licencia pertenece a otro producto.' };
    if (![1, 2].includes(payload.schema_version || 1)) return { verified: false, reason: 'La versión de licencia no es compatible.' };
    if ((payload.schema_version || 1) === 2) {
      const required = ['license_id', 'license_type', 'organization_id', 'issued_at', 'starts_at', 'expires_at', 'license_status', 'max_active_raffles', 'max_tickets_per_raffle', 'max_team_accounts', 'max_organizers', 'features'];
      if (required.some((field) => !Object.prototype.hasOwnProperty.call(payload, field))) return { verified: false, reason: 'La licencia firmada está incompleta.' };
      if (!hasValidSignedQuotas(payload)) return { verified: false, reason: 'Los límites firmados deben ser enteros no negativos.' };
      if (!['TRIAL', 'COMMERCIAL'].includes(payload.license_type) || !['ACTIVE', 'SUSPENDED', 'REVOKED'].includes(payload.license_status)) return { verified: false, reason: 'Los datos de tipo o estado de la licencia no son válidos.' };
    }
    return { verified: true, claims: payload };
  } catch {
    return { verified: false, reason: 'No se pudo verificar la firma Ed25519 de la licencia.' };
  }
}

export async function evaluateOfflineLicense(token, serverSnapshot, now = Date.now()) {
  const verification = await verifySignedLicense(token);
  if (!verification.verified) return { ...verification, mode: 'OFFLINE_UNVERIFIED', active: false, canViewExisting: true };

  const claims = verification.claims;
  if (serverSnapshot?.license_id && claims.license_id && String(serverSnapshot.license_id) !== String(claims.license_id)) {
    return { verified: false, reason: 'La licencia guardada no coincide con la última organización confirmada por el servidor.', mode: 'OFFLINE_UNVERIFIED', active: false, canViewExisting: true };
  }
  if (serverSnapshot?.organization_id && claims.organization_id && String(serverSnapshot.organization_id) !== String(claims.organization_id)) {
    return { verified: false, reason: 'La organización de la licencia guardada no coincide con el último estado del servidor.', mode: 'OFFLINE_UNVERIFIED', active: false, canViewExisting: true };
  }
  const signedExpiry = claims.expires_at ? Date.parse(claims.expires_at) : null;
  const serverExpiry = serverSnapshot?.expires_at ? Date.parse(serverSnapshot.expires_at) : null;
  const expiresAt = Number.isFinite(serverExpiry) ? serverExpiry : signedExpiry;
  const startsAt = claims.starts_at ? Date.parse(claims.starts_at) : null;
  const lastVerified = serverSnapshot?.last_verified_at ? Date.parse(serverSnapshot.last_verified_at) : NaN;
  const graceHours = serverSnapshot?.offline_grace_hours;
  const graceMs = Number.isFinite(Number(graceHours)) ? Math.max(0, Number(graceHours)) * 60 * 60 * 1000 : 0;
  const withinGrace = Number.isFinite(lastVerified) && now <= lastVerified + graceMs;
  const serverStatus = serverSnapshot?.license_status || claims.license_status || 'ACTIVE';

  if (serverStatus === 'REVOKED') {
    return { verified: true, claims, active: false, mode: 'REVOKED', license_status: 'REVOKED', canViewExisting: true };
  }
  if (serverStatus === 'EXPIRED' || serverSnapshot?.mode === 'EXPIRED') {
    return { verified: true, claims, active: false, mode: 'EXPIRED', license_status: 'EXPIRED', canViewExisting: true };
  }
  if ((Number.isFinite(startsAt) && startsAt > now) || serverSnapshot?.mode === 'NOT_STARTED') {
    return { verified: true, claims, active: false, mode: 'NOT_STARTED', license_status: 'NOT_STARTED', canViewExisting: true };
  }
  if (Number.isFinite(expiresAt) && expiresAt <= now) {
    return { verified: true, claims, active: false, mode: 'EXPIRED', license_status: 'EXPIRED', canViewExisting: true };
  }
  if (serverStatus === 'SUSPENDED') {
    return { verified: true, claims, active: false, mode: 'SUSPENDED', license_status: 'SUSPENDED', canViewExisting: true };
  }
  if (!withinGrace) {
    return { verified: true, claims, active: false, mode: 'OFFLINE_STALE', license_status: serverStatus, canViewExisting: true };
  }
  return {
    verified: true,
    claims,
    active: serverStatus === 'ACTIVE',
    mode: serverStatus === 'ACTIVE' ? 'OFFLINE_GRACE' : serverStatus,
    license_status: serverStatus,
    canViewExisting: true,
    offline_grace_remaining_ms: Math.max(0, lastVerified + graceMs - now),
  };
}
