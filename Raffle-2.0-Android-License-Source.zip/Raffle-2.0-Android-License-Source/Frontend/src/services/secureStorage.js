import { Capacitor, registerPlugin } from '@capacitor/core';

const NativeSecureStorage = registerPlugin('SecureStorage');

const isNative = () => Capacitor.isNativePlatform();

export async function getSecureItem(key) {
  if (!isNative()) return window.localStorage.getItem(key);
  const result = await NativeSecureStorage.get({ key });
  return result?.exists ? result.value : null;
}

export async function setSecureItem(key, value) {
  const normalized = String(value);
  if (!isNative()) {
    window.localStorage.setItem(key, normalized);
    return;
  }
  await NativeSecureStorage.set({ key, value: normalized });
}

export async function removeSecureItem(key) {
  if (!isNative()) {
    window.localStorage.removeItem(key);
    return;
  }
  await NativeSecureStorage.remove({ key });
}

export async function clearSecureItems() {
  if (!isNative()) {
    window.localStorage.removeItem('raffle_token');
    window.localStorage.removeItem('raffle_refresh_token');
    return;
  }
  await NativeSecureStorage.clear();
}

export async function clearOfflineCache() {
  if (!isNative()) {
    for (let index = window.localStorage.length - 1; index >= 0; index -= 1) {
      const key = window.localStorage.key(index);
      if (key?.startsWith('offline-cache:')) window.localStorage.removeItem(key);
    }
    return;
  }
  await NativeSecureStorage.clearCache();
}
