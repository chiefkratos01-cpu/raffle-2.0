# Raffle 2.0 · M36 progress

## M36 visual and responsive foundation

- Mobile theme/logout controls remain accessible with safe-area spacing.
- Fixed bottom navigation reserves content space and respects reduced-motion preferences.
- Long titles, rows, admin controls and raffle cards are contained on narrow screens.
- Administration navigation now uses grouped accordion sections instead of an endless tab strip.
- The roulette uses a server-authoritative result, multi-turn reveal, progressive easing, responsive sizing and reduced-motion handling.
- Public-facing UI now uses a consistent vector icon language instead of mixed emoji/glyph controls.
- The primary palette was refined from a high-saturation neon gradient toward a cleaner indigo/blue product palette while preserving the purple identity.

## Product and trust hardening added during the audit

- Public raffle endpoints now expose only genuinely public raffle states. Draft and cancelled raffles cannot be fetched by ID through the public catalog surface.
- Public draw endpoints use the same visibility boundary.
- Administrative create/update/cancel responses no longer depend on public visibility filtering.
- Cancelling a raffle with paid tickets is blocked until a refund workflow exists; unpaid reservations are released and pending payment reviews are rejected consistently.
- Image uploads validate both the declared MIME type and the file signature for JPG/PNG/WEBP.
- Fixed development credentials are no longer shipped in source. Development generates a temporary password when one is not supplied through configuration.
- Password validation is consistent for customer, organizer, team and administrator creation.
- Public verification contracts avoid exposing unnecessary internal ticket database IDs.
- Public raffle details have stable shareable URLs and a native-share/copy-link action.
- The catalog distinguishes loading, empty and network-error states so connectivity failures do not masquerade as an empty platform.

## External UX references considered

Current patterns reviewed from GalaBid and Raffall include:
- direct raffle links and QR/share-oriented discovery,
- clear raffle setup controls and separate operational dashboards,
- explicit winner/result presentation,
- ticket/result verification and transparency,
- live draw displays and synchronized winner reveals,
- professional branded campaign pages and consistent visual presentation.

These patterns were used as product references, not copied as branding or implementation.

## Remaining release gate

The source passes the static release gate and Python compilation. Full backend runtime tests and the frontend build/test suite still require an environment with the pinned dependencies installed. The current audit environment cannot reach package registries, so those runtime gates must be executed in the real development environment before commercial release.
